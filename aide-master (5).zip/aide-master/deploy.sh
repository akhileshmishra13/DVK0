#!/bin/bash
set -e

# Configuration
VERSION_FILE="backend/.env.local"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION=$(aws configure get region)
TIMESTAMP=$(date +%Y%m%d%H%M%S)
DEPLOY_DATE=$(date -u +%Y-%m-%dT%H:%M:%SZ)
LOGFILE="deploy-${TIMESTAMP}.log"
DEBUG=false
NO_FAIL=false
SKIP_BUILD=false
SKIP_PUSH=false
SKIP_DEPLOY=false
QUICK_DEPLOY=false
SKIP_SECRETS=false

# Enable debugging if needed
if [ "${DEBUG}" = "true" ]; then
  set -x
fi

# Display help information
function show_help {
  echo "AIDE Deployment Script v1.1.0"
  echo "Usage: $0 [options]"
  echo ""
  echo "Options:"
  echo "  --help          Show this help message"
  echo "  --restart       Only restart deployments (skip build/push)"
  echo "  --rollback      Rollback to previous deployment version"
  echo "  --no-fail       Continue on errors"
  echo "  --skip-build    Skip building Docker images"
  echo "  --skip-push     Skip pushing Docker images to ECR"
  echo "  --skip-deploy   Skip Kubernetes deployment steps"
  echo "  --skip-secrets  Skip generating/updating Kubernetes secrets"
  echo "  --debug         Enable debug mode (verbose output)"
  echo ""
  echo "Examples:"
  echo "  $0              Full deployment process"
  echo "  $0 --restart    Quick restart without rebuilding"
  echo "  $0 --rollback   Rollback to previous version"
  echo ""
}

# Parse command line arguments
while [[ "$#" -gt 0 ]]; do
  case $1 in
    --help) show_help; exit 0 ;;
    --restart) QUICK_DEPLOY=true; SKIP_BUILD=true; SKIP_PUSH=true ;;
    --rollback) 
      echo "Rolling back deployments..."
      kubectl rollout undo deployment/aide-backend -n aide
      kubectl rollout undo deployment/aide-frontend -n aide
      kubectl rollout status deployment/aide-backend -n aide --timeout=300s
      kubectl rollout status deployment/aide-frontend -n aide --timeout=300s
      exit $?
      ;;
    --no-fail) NO_FAIL=true; set +e ;;
    --skip-build) SKIP_BUILD=true ;;
    --skip-push) SKIP_PUSH=true ;;
    --skip-deploy) SKIP_DEPLOY=true ;;
    --skip-secrets) SKIP_SECRETS=true ;;
    --debug) DEBUG=true; set -x ;;
    *) echo "Unknown parameter: $1"; show_help; exit 1 ;;
  esac
  shift
done

# Start logging
exec > >(tee -a "${LOGFILE}") 2>&1

# Read version from .env.local
if [ -f "$VERSION_FILE" ]; then
  echo "Reading version from $VERSION_FILE..."
  VERSION=$(grep PROJECT_VERSION "$VERSION_FILE" | cut -d '=' -f2 | tr -d '[:space:]')
  echo "Found version: ${VERSION}"
else
  echo "Error: $VERSION_FILE not found"
  exit 1
fi

# Validate version
if [ -z "$VERSION" ] || [ "$VERSION" = " " ]; then
  echo "Error: Could not extract PROJECT_VERSION from $VERSION_FILE"
  exit 1
fi

BACKEND_REPO="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend"
FRONTEND_REPO="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend"

# Banner
echo "====================================================="
echo "  AIDE Deployment Script - v${VERSION}"
echo "====================================================="
echo "Account ID: ${ACCOUNT_ID}"
echo "Region: ${REGION}"
echo "Timestamp: ${TIMESTAMP}"
echo "Deployment Options:"
echo "  Skip Build: ${SKIP_BUILD}"
echo "  Skip Push: ${SKIP_PUSH}" 
echo "  Skip Deploy: ${SKIP_DEPLOY}"
echo "  Skip Secrets: ${SKIP_SECRETS}"
echo "  Quick Deploy: ${QUICK_DEPLOY}"
echo "====================================================="

# Login to ECR
if [ "$SKIP_PUSH" = "false" ]; then
  echo "Logging in to ECR..."
  aws ecr get-login-password --region ${REGION} | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com

  # Ensure repositories exist
  for repo in "aide-backend" "aide-frontend"; do
    aws ecr describe-repositories --repository-names ${repo} --region ${REGION} > /dev/null 2>&1 || \
    aws ecr create-repository --repository-name ${repo} --image-scanning-configuration scanOnPush=true --region ${REGION}
  done
fi

# Generate Kubernetes secrets
if [ "$SKIP_SECRETS" = "false" ]; then
  echo "Generating Kubernetes secrets..."
  cd deploy/k8s
  
  if [ -f "generate-secrets.sh" ]; then
    chmod +x generate-secrets.sh
    ./generate-secrets.sh --env-file "../../${VERSION_FILE}"
  else
    echo "Warning: generate-secrets.sh not found"
  fi
  
  cd ../../
fi

# Generate deployment files
if [ "$SKIP_DEPLOY" = "false" ]; then
  echo "Generating deployment files..."
  cd deploy/k8s
  
  if [ -f "generate-deployment.sh" ]; then
    chmod +x generate-deployment.sh
    ./generate-deployment.sh --env-file "../../${VERSION_FILE}"
  else
    echo "Warning: generate-deployment.sh not found, using legacy deployment approach"
    # Legacy deployment file update logic here
  fi
  
  cd ../../
fi

# Build and push backend
if [ "$SKIP_BUILD" = "false" ]; then
  echo "Building and pushing backend image..."
  cd backend
  
  # Build docker image
  echo "Building backend Docker image..."
  docker build -t aide-backend:${VERSION} .
  
  if [ "$SKIP_PUSH" = "false" ]; then
    echo "Tagging and pushing backend images..."
    docker tag aide-backend:${VERSION} ${BACKEND_REPO}:${VERSION}
    docker tag aide-backend:${VERSION} ${BACKEND_REPO}:latest
    docker push ${BACKEND_REPO}:${VERSION}
    docker push ${BACKEND_REPO}:latest
  fi
  
  # Return to root directory
  cd ..
fi

# Build and push frontend
if [ "$SKIP_BUILD" = "false" ]; then
  echo "Building and pushing frontend image..."
  cd frontend
  
  # Update version in package.json
  echo "Updating version in package.json..."
  sed -i "s/\"version\": \".*\"/\"version\": \"${VERSION}\"/g" package.json
  
  # Build React app
  echo "Building React application..."
  npm run build
  
  # Build docker image
  echo "Building frontend Docker image..."
  docker build -t aide-frontend:${VERSION} .
  
  if [ "$SKIP_PUSH" = "false" ]; then
    echo "Tagging and pushing frontend images..."
    docker tag aide-frontend:${VERSION} ${FRONTEND_REPO}:${VERSION}
    docker tag aide-frontend:${VERSION} ${FRONTEND_REPO}:latest
    docker push ${FRONTEND_REPO}:${VERSION}
    docker push ${FRONTEND_REPO}:latest
  fi
  
  # Return to root directory
  cd ..
fi

# Apply the deployment
if [ "$SKIP_DEPLOY" = "false" ]; then
  echo "Applying Kubernetes manifests..."
  kubectl apply -f deploy/k8s/backend-docdb-fixed.yaml
  kubectl apply -f deploy/k8s/frontend-deployment.yaml
  
  # Force rollout to ensure the new image is pulled
  echo "Forcing rollout restart to ensure updates are applied..."
  kubectl rollout restart deployment/aide-backend -n aide
  kubectl rollout restart deployment/aide-frontend -n aide
  
  # Get a snapshot of pods before rollout
  echo "Current pods before rollout:"
  kubectl get pods -n aide
  
  # Monitor backend pod status in background
  echo "Monitoring backend pod status..."
  kubectl get pods -n aide -l app=aide-backend -w &
  WATCH_PID=$!
  
  # Let it run for a few seconds
  sleep 10
  kill $WATCH_PID 2>/dev/null || true
  
  # Monitor rollout status
  echo "Monitoring backend rollout (timeout: 300s)..."
  kubectl rollout status deployment/aide-backend -n aide --timeout=300s || {
    echo "WARNING: Backend deployment timed out. Checking pod status..."
    kubectl get pods -n aide -l app=aide-backend
    
    # Check logs from new pods
    echo "Checking logs from problematic backend pods..."
    NEW_POD=$(kubectl get pods -n aide -l app=aide-backend,version="${VERSION}" -o jsonpath="{.items[0].metadata.name}" 2>/dev/null || echo "")
    if [ -n "$NEW_POD" ]; then
      echo "Logs from ${NEW_POD}:"
      kubectl logs ${NEW_POD} -n aide --tail=50
    fi
    
    echo "Would you like to roll back the backend deployment? (y/n)"
    read -r rollback_backend
    if [[ "$rollback_backend" == "y" ]]; then
      kubectl rollout undo deployment/aide-backend -n aide
      kubectl rollout status deployment/aide-backend -n aide --timeout=60s
    else
      echo "Continuing with frontend deployment, but backend may be in a broken state."
    fi
  }
  
  echo "Monitoring frontend rollout (timeout: 300s)..."
  kubectl rollout status deployment/aide-frontend -n aide --timeout=300s || {
    echo "WARNING: Frontend deployment timed out."
    
    echo "Would you like to roll back the frontend deployment? (y/n)"
    read -r rollback_frontend
    if [[ "$rollback_frontend" == "y" ]]; then
      kubectl rollout undo deployment/aide-frontend -n aide
      kubectl rollout status deployment/aide-frontend -n aide --timeout=60s
    fi
  }
  
  # Show final deployed pods
  echo "Deployed pods:"
  kubectl get pods -n aide
  
  # Check readiness status
  echo "Checking pod readiness status..."
  UNREADY_PODS=$(kubectl get pods -n aide -o jsonpath='{.items[?(@.status.containerStatuses[0].ready==false)].metadata.name}')
  if [ -n "$UNREADY_PODS" ]; then
    echo "WARNING: Some pods are not ready: $UNREADY_PODS"
    for pod in $UNREADY_PODS; do
      echo "Details for unready pod $pod:"
      kubectl describe pod $pod -n aide | grep -A 10 "Events:"
    done
  fi
fi

echo "====================================================="
echo "  Deployment Complete!"
echo "====================================================="
echo "Version: ${VERSION}"
echo "Timestamp: ${TIMESTAMP}"
echo "Deployment log: ${LOGFILE}"
echo ""
echo "Accessing the application:"
echo "- External URL: http://k8s-aide-aideingr-0bfaad4f3c-1930919656.ap-southeast-1.elb.amazonaws.com"
echo "====================================================="