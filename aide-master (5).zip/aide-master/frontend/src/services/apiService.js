// frontend/src/services/apiService.js
import axios from 'axios';
import authService from './authService';

// Set API URL based on environment
const API_URL = process.env.NODE_ENV === 'development' 
  ? 'http://localhost:8000'
  : '';

// Create standard axios instance
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Create upload instance without setting Content-Type
const uploadClient = axios.create({ baseURL: API_URL });

const addAuthToken = (config) => {
  authService.updateLastActivity();
  const token = authService.getAccessToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
};

apiClient.interceptors.request.use(addAuthToken, (error) => Promise.reject(error));
uploadClient.interceptors.request.use(addAuthToken, (error) => Promise.reject(error));

const handle401 = (error) => {
  if (error.response?.status === 401) {
    authService.logout();
    window.location.href = '/login';
  }
  return Promise.reject(error);
};

apiClient.interceptors.response.use((res) => res, handle401);
uploadClient.interceptors.response.use((res) => res, handle401);

// 🔍 Extract error details deeply
export const extractErrorMessage = (error) => {
  const defaultMsg = 'An unexpected error occurred';
  if (!error?.response?.data) return defaultMsg;

  const { data } = error.response;
  const top = data.message || data.detail || data.error;
  const metaDetail = data.metadata?.error?.detail;
  return metaDetail || top || defaultMsg;
};

// API endpoints
export const authApi = {
  login: (credentials) => apiClient.post('/auth/login/', credentials),
};

export const documentApi = {
  uploadDocument: (file) => {
    const formData = new FormData();
    formData.append('file', file);
    return uploadClient.post('/api/v1/document/upload', formData);
  },
  getDocuments: () => apiClient.get('/api/v1/document/'),
  getDocument: (id) => apiClient.get(`/api/v1/document/${id}`),
  deleteDocument: (id) => apiClient.delete(`/api/v1/document/${id}`),
};

export const extractionApi = {
  getDocumentText: (id) => apiClient.get(`/api/v1/extraction/${id}/text`),
  getDocumentMetadata: (id) => apiClient.get(`/api/v1/extraction/${id}/metadata`),
  getDocumentStructure: (id) => apiClient.get(`/api/v1/extraction/${id}/structure`),
  extractAll: (id) => apiClient.post(`/api/v1/extraction/${id}`),
};

export const completionApi = {
  createCompletion: (data) => apiClient.post('/api/v1/completion', data),
  getCompletion: (id) => apiClient.get(`/api/v1/completion/${id}`),
};

export const promptApi = {
  getCategories: () => apiClient.get('/api/v1/prompts/categories'),
  getTemplates: () => apiClient.get('/api/v1/prompts/templates'),
  getTemplate: (id) => apiClient.get(`/api/v1/prompts/templates/${id}`),
};

export const systemApi = {
  getStatus: () => apiClient.get('/api/v1/system/status'),
  getHealth: () => apiClient.get('/api/v1/system/health'),
};

export default apiClient;
