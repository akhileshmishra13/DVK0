// frontend/src/components/common/CompletionProgress.jsx
import React, { useState, useEffect } from 'react';
import { Box, LinearProgress, Typography, Fade, Paper, Button } from '@mui/material';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import DoneIcon from '@mui/icons-material/Done';
import CloseIcon from '@mui/icons-material/Close';
import PsychologyIcon from '@mui/icons-material/Psychology';

const CompletionProgress = ({ 
  percentage, 
  currentStep, 
  isComplete, 
  error, 
  expanded = true,
  onManualClose = null,
  isThinking = false,
  thinkingPhase = ''
}) => {
  const [showCloseOption, setShowCloseOption] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [elapsedTimeFormatted, setElapsedTimeFormatted] = useState('00:00');
  
  // Show close option after 30 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowCloseOption(true);
    }, 30000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Track elapsed time
  useEffect(() => {
    if (!isComplete && !error) {
      const timer = setInterval(() => {
        setElapsedTime(prev => {
          const newTime = prev + 1;
          // Format time as MM:SS
          const minutes = Math.floor(newTime / 60);
          const seconds = newTime % 60;
          setElapsedTimeFormatted(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
          return newTime;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [isComplete, error]);

  const getStatusIcon = () => {
    if (error) {
      return <ErrorOutlineIcon sx={{ color: 'error.main', mr: 1, fontSize: 16 }} />;
    }
    
    if (isComplete) {
      return <DoneIcon sx={{ color: 'success.main', mr: 1, fontSize: 16 }} />;
    }
    
    if (isThinking) {
      return <PsychologyIcon sx={{ color: 'primary.main', mr: 1, fontSize: 16 }} />;
    }
    
    return <AutoAwesomeIcon sx={{ color: 'primary.main', mr: 1, fontSize: 16 }} />;
  };
  
  const getStatusColor = () => {
    if (error) return 'error.main';
    if (isComplete) return 'success.main';
    return 'primary.main';
  };
  
  // Format thinking phase to be more descriptive
  const getThinkingPhaseText = () => {
    if (!thinkingPhase) return '';
    
    switch(thinkingPhase.toLowerCase()) {
      case 'analyzing': 
        return 'Analyzing documents in depth';
      case 'planning':
        return 'Planning response structure';
      case 'drafting':
        return 'Drafting detailed analysis';
      case 'refining':
        return 'Refining and polishing response';
      case 'finalizing':
        return 'Finalizing response with citations';
      default:
        return thinkingPhase;
    }
  };
  
  // Get dynamic description based on elapsed time
  const getLongRunningMessage = () => {
    if (elapsedTime > 300) { // Over 5 minutes
      return "Processing large documents with deep analysis - this can take 10+ minutes for thorough results.";
    } else if (elapsedTime > 120) { // Over 2 minutes
      return "Large document analysis in progress. Thinking models perform thorough analysis which takes time.";
    } else if (elapsedTime > 60) { // Over 1 minute
      return "Processing continues. Large documents require more time for thoughtful analysis.";
    }
    return null;
  };
  
  const longRunningMessage = getLongRunningMessage();
  
  return (
    <Fade in={true}>
      <Paper
        elevation={0}
        sx={{ 
          borderRadius: 0,
          overflow: 'hidden',
          backgroundColor: error 
            ? 'error.main'
            : isComplete 
              ? 'success.main'
              : 'primary.main',
          backgroundOpacity: 0.08,
          borderBottom: '1px solid',
          borderColor: error 
            ? 'error.main'
            : isComplete 
              ? 'success.main'
              : 'primary.main',
          borderOpacity: 0.2
        }}
      >
        <Box sx={{ 
          px: 3, 
          py: 1.5,
          position: 'relative'
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              {getStatusIcon()}
              <Typography variant="body2" sx={{ fontWeight: 500, color: getStatusColor() }}>
                {error 
                  ? "Error processing request" 
                  : isComplete 
                    ? "Processing complete" 
                    : isThinking && thinkingPhase
                      ? getThinkingPhaseText()
                      : currentStep || "Processing..."}
              </Typography>
              
              {/* Show elapsed time for long-running processes */}
              {!isComplete && !error && elapsedTime > 15 && (
                <Typography variant="caption" sx={{ ml: 2, fontFamily: 'monospace', color: 'rgba(255,255,255,0.6)' }}>
                  {elapsedTimeFormatted}
                </Typography>
              )}
            </Box>
            <Typography variant="body2" sx={{ fontWeight: 500 }}>
              {Math.round(percentage)}%
            </Typography>
          </Box>
          
          <LinearProgress 
            variant={isComplete ? "determinate" : isThinking ? "indeterminate" : "determinate"}
            value={percentage}
            sx={{ 
              height: 8, 
              borderRadius: 4,
              backgroundColor: 'rgba(0, 0, 0, 0.1)',
              '& .MuiLinearProgress-bar': {
                backgroundColor: getStatusColor(),
                borderRadius: 4
              }
            }} 
          />
          
          {/* Show long-running message for extended processing */}
          {longRunningMessage && !isComplete && !error && (
            <Typography 
              variant="caption" 
              sx={{ 
                display: 'block', 
                mt: 1,
                color: 'text.secondary',
                fontStyle: 'italic'
              }}
            >
              {longRunningMessage}
            </Typography>
          )}
          
          {/* Add manual close option that shows after delay */}
          {showCloseOption && onManualClose && !isComplete && (
            <Button
              size="small"
              startIcon={<CloseIcon />}
              onClick={onManualClose}
              sx={{ 
                mt: 1,
                fontSize: '0.7rem',
                textTransform: 'none',
                position: 'absolute',
                bottom: 8,
                right: 8
              }}
            >
              Close Progress
            </Button>
          )}
        </Box>
      </Paper>
    </Fade>
  );
};

export default CompletionProgress;