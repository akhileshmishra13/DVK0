// src/components/layout/Sidebar.js

import React, { useState, useEffect } from 'react';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Box,
  Typography,
  useTheme,
  LinearProgress,
  Avatar,
  Divider,
  Collapse,
  Tooltip,
  Chip,
  Fade,
  Badge,
  CircularProgress,
  alpha
} from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import BorderStyleIcon from '@mui/icons-material/BorderStyle';
import GrainIcon from '@mui/icons-material/Grain';
import LineStyleIcon from '@mui/icons-material/LineStyle';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import DescriptionIcon from '@mui/icons-material/Description';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import BarChartIcon from '@mui/icons-material/BarChart';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import DeveloperBoardIcon from '@mui/icons-material/DeveloperBoard';
import ErrorIcon from '@mui/icons-material/Error';
import PendingIcon from '@mui/icons-material/Pending';
import RefreshIcon from '@mui/icons-material/Refresh';
import ApiIcon from '@mui/icons-material/Api';
import StorageIcon from '@mui/icons-material/Storage';
import StorageTwoToneIcon from '@mui/icons-material/StorageTwoTone';
import MemoryIcon from '@mui/icons-material/Memory';
import LaptopIcon from '@mui/icons-material/Laptop';
import LogoutIcon from '@mui/icons-material/Logout';
import DatabaseIcon from '@mui/icons-material/Storage';
import apiClient from '../../services/apiService';
import { promptApi, systemApi } from '../../services/apiService';
import { logout } from '../../store/authSlice';

const drawerWidth = 280;

const menuItems = [
  { name: 'Document Library', icon: <BorderStyleIcon />, path: '/' },
  { name: 'Deal Evaluation', icon: <GrainIcon />, path: '/assistant' },
  { name: 'Prompt Gallery', icon: <LineStyleIcon />, path: '/prompts' },
];

const Sidebar = () => {
  const theme = useTheme();
  const location = useLocation();
  const dispatch = useDispatch();
  
  const [templatesOpen, setTemplatesOpen] = useState(true);
  const [systemStatusOpen, setSystemStatusOpen] = useState(false);
  const [serviceStatuses, setServiceStatuses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [promptTemplates, setPromptTemplates] = useState([]);
  const [isLoadingTemplates, setIsLoadingTemplates] = useState(false);
  const [dbInfo, setDbInfo] = useState(null);
  const [systemInfo, setSystemInfo] = useState(null);
  
  const isActive = (path) => location.pathname === path;
  const isAssistantPage = location.pathname === '/assistant';
  
  useEffect(() => {
    // Fetch service statuses when component mounts
    fetchServiceStatuses();
    
    // Set up polling every 15 seconds
    const intervalId = setInterval(fetchServiceStatuses, 15000);
    
    // Clear interval on unmount
    return () => clearInterval(intervalId);
  }, []);
  
  // Fetch deal templates when on the assistant page
  useEffect(() => {
    if (isAssistantPage) {
      fetchDealTemplates();
    }
  }, [isAssistantPage]);
  
  const fetchDealTemplates = async () => {
    try {
      setIsLoadingTemplates(true);
      const response = await promptApi.getCategories();
      
      if (response.data && response.data.status === 'success') {
        // Extract deal_evaluation templates
        const categories = response.data.data;
        if (categories && categories.deal_evaluation) {
          // Flatten all subcategories into a single array of templates
          const templates = [];
          Object.keys(categories.deal_evaluation).forEach(subcategory => {
            const subcategoryTemplates = categories.deal_evaluation[subcategory];
            subcategoryTemplates.forEach(template => {
              templates.push({
                id: template.template_id,
                name: template.display_name,
                description: template.description
              });
            });
          });
          setPromptTemplates(templates);
        }
      }
    } catch (err) {
      console.error("Error fetching deal templates:", err.message || err);
    } finally {
      setIsLoadingTemplates(false);
    }
  };
  
  const fetchServiceStatuses = async () => {
    try {
      setIsLoading(true);
      
      // Use the configured apiClient instead of direct axios
      const response = await systemApi.getStatus();
      
      if (response.data && response.data.status === 'success') {
        setServiceStatuses(response.data.data.services || []);
        // Store database info and system metadata
        setDbInfo(response.data.data.metadata?.database || null);
        setSystemInfo(response.data.data.metadata?.system || null);
        setError(null);
        setLastUpdated(new Date());
      } else {
        setError('Failed to load service status');
      }
    } catch (err) {
      console.error('Error fetching system status:', err);
      setError('Network Error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefreshStatus = (e) => {
    e.stopPropagation(); // Prevent clicking the refresh button from toggling the accordion
    fetchServiceStatuses();
  };
  
  // Handle template selection
  const handleSelectTemplate = async (templateId) => {
    try {
      // Fetch the full template
      const response = await promptApi.getTemplate(templateId);
      
      if (response.data && response.data.status === 'success') {
        const template = response.data.data;
        
        // Use the global handler if it exists
        if (window.handlePromptTemplateSelect) {
          window.handlePromptTemplateSelect(template.content);
        }
      }
    } catch (err) {
      console.error("Error loading template:", err);
    }
  };
  
  const getStatusIcon = (status) => {
    switch (status) {
      case 'running':
        return <CheckCircleIcon sx={{ color: theme.palette.success.main, fontSize: 14, mr: 0.5 }} />;
      case 'error':
        return <ErrorIcon sx={{ color: theme.palette.error.main, fontSize: 14, mr: 0.5 }} />;
      case 'initializing':
        return <PendingIcon sx={{ color: theme.palette.warning.main, fontSize: 14, mr: 0.5 }} />;
      default:
        return <PendingIcon sx={{ color: theme.palette.text.secondary, fontSize: 14, mr: 0.5 }} />;
    }
  };
  
  const getStatusColor = (status) => {
    switch (status) {
      case 'running':
        return theme.palette.success.main;
      case 'error':
        return theme.palette.error.main;
      case 'initializing':
        return theme.palette.warning.main;
      default:
        return theme.palette.text.secondary;
    }
  };

  const getServiceIcon = (name) => {
    if (name.includes('model') || name.includes('prompt')) {
      return <ApiIcon sx={{ fontSize: 14, color: theme.palette.primary.light }} />;
    } else if (name.includes('data') || name.includes('event')) {
      return <StorageIcon sx={{ fontSize: 14, color: theme.palette.secondary.light }} />;
    } else if (name.includes('system') || name.includes('service')) {
      return <MemoryIcon sx={{ fontSize: 14, color: theme.palette.info.light }} />;
    } else if (name.includes('extract') || name.includes('completion')) {
      return <LaptopIcon sx={{ fontSize: 14, color: theme.palette.warning.light }} />;
    } else if (name.includes('logging')) {
      return <DescriptionIcon sx={{ fontSize: 14, color: theme.palette.success.light }} />;
    }
    return <DeveloperBoardIcon sx={{ fontSize: 14, color: theme.palette.primary.light }} />;
  };

  // Get overall system health status
  const getSystemHealth = () => {
    if (serviceStatuses.length === 0) return 'unknown';
    
    const errorCount = serviceStatuses.filter(s => s.status === 'error').length;
    const initCount = serviceStatuses.filter(s => s.status === 'initializing').length;
    const runningCount = serviceStatuses.filter(s => s.status === 'running').length;
    
    if (errorCount > 0) return 'error';
    if (initCount > 0) return 'initializing';
    if (runningCount === serviceStatuses.length) return 'running';
    return 'degraded';
  };
  
  // Handle logout action
  const handleLogout = () => {
    dispatch(logout());
  };
  
  const systemHealth = getSystemHealth();
  
  return (
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
          borderRight: 'none',
          background: theme.palette.background.dark,
          color: 'white',
          overflowX: 'hidden'
        },
      }}
    >
      <Box sx={{ 
        overflow: 'auto', 
        px: 2, 
        py: 2,
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        overflowY: 'auto',
        position: 'relative'
      }}>
        {/* Logo and version section - previously in header */}
        <Box sx={{ 
          mb: 3, 
          display: 'flex', 
          flexDirection: 'column',
          alignItems: 'flex-start',
          px: 1
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <Typography 
              variant="h5" 
              component="div" 
              sx={{ 
                fontWeight: 700, 
                background: 'linear-gradient(90deg, #3A72F8 0%, #2DD4BF 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                letterSpacing: '0.02em'
              }}
            >
              KEPPEL AIDE
            </Typography>
          </Box>
          
          {/* Version indicator */}
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            mt: 1,
            px: 1.5,
            py: 0.5,
            borderRadius: 1.5,
            background: alpha(theme.palette.background.paper, 0.15),
            border: `1px solid ${alpha(theme.palette.divider, 0.1)}`
          }}>
            {isLoading && !systemInfo ? (
              <CircularProgress size={14} thickness={4} sx={{ mr: 0.5 }} />
            ) : (
              <Typography 
                variant="caption" 
                sx={{ 
                  fontSize: '0.7rem',
                  color: alpha(theme.palette.text.primary, 0.7),
                  fontWeight: 500,
                  letterSpacing: '0.05em'
                }}
              >
                v{systemInfo?.version || ""}
              </Typography>
            )}
            
            {systemInfo && (
              <Chip
                label={systemInfo.environment.toUpperCase()}
                size="small"
                sx={{
                  height: 16,
                  fontSize: '0.55rem',
                  ml: 0.7,
                  fontWeight: 700,
                  backgroundColor: systemInfo.environment === 'production'
                    ? alpha(theme.palette.success.main, 0.2)
                    : systemInfo.environment === 'development'
                      ? alpha(theme.palette.warning.main, 0.2)
                      : alpha(theme.palette.info.main, 0.2),
                  color: systemInfo.environment === 'production'
                    ? theme.palette.success.main
                    : systemInfo.environment === 'development'
                      ? theme.palette.warning.main
                      : theme.palette.info.main,
                  '& .MuiChip-label': {
                    px: 0.8,
                    py: 0
                  }
                }}
              />
            )}
          </Box>
        </Box>
        
        <Divider sx={{ my: 1, bgcolor: 'rgba(255,255,255,0.1)' }} />
      
        {/* Main content container */}
        <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
          <Typography 
            variant="subtitle2" 
            sx={{ px: 3, py: 1, color: 'rgba(255,255,255,0.5)', fontWeight: 700 }}
          >
            MAIN MENU
          </Typography>
          <List sx={{ mt: 1 }} component="nav">
            {menuItems.map((item) => (
              <ListItem 
                button 
                key={item.name} 
                component={RouterLink} 
                to={item.path}
                sx={{ 
                  borderRadius: '12px',
                  mb: 1,
                  background: isActive(item.path) ? 'rgba(255,255,255,0.1)' : 'transparent',
                  position: 'relative',
                  overflow: 'hidden',
                  '&:hover': {
                    background: 'rgba(255,255,255,0.08)',
                  },
                  '&::before': isActive(item.path) ? {
                    content: '""',
                    position: 'absolute',
                    left: 0,
                    top: '25%',
                    height: '50%',
                    width: '4px',
                    background: 'linear-gradient(180deg, #3A72F8 0%, #2DD4BF 100%)',
                    borderRadius: '0 4px 4px 0'
                  } : {}
                }}
              >
                <ListItemIcon sx={{ 
                  minWidth: 40, 
                  color: isActive(item.path) ? theme.palette.primary.light : 'rgba(255,255,255,0.7)' 
                }}>
                  {item.icon}
                </ListItemIcon>
                <ListItemText 
                  primary={item.name}
                  primaryTypographyProps={{ 
                    fontWeight: isActive(item.path) ? 600 : 400,
                    color: isActive(item.path) ? 'white' : 'rgba(255,255,255,0.7)'
                  }}
                />
              </ListItem>
            ))}
          </List>
          
          {/* Prompt templates section - only shown on assistant page */}
          {isAssistantPage && (
            <>
              <Divider sx={{ my: 2, bgcolor: 'rgba(255,255,255,0.1)' }} />
              
              <ListItem 
                button 
                onClick={() => setTemplatesOpen(!templatesOpen)}
                sx={{ 
                  px: 2,
                  color: 'rgba(255,255,255,0.7)',
                  mb: 1,
                  mt: 1
                }}
              >
                <ListItemText 
                  primary="PROMPT TEMPLATES" 
                  primaryTypographyProps={{ 
                    variant: 'subtitle2', 
                    fontWeight: 700,
                    fontSize: '0.7rem'
                  }} 
                />
                {templatesOpen ? <ExpandMoreIcon fontSize="small" /> : <ChevronRightIcon fontSize="small" />}
              </ListItem>
              
              <Collapse in={templatesOpen} timeout="auto" unmountOnExit>
                <List component="div" disablePadding>
                  {isLoadingTemplates ? (
                    <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
                      <CircularProgress size={24} />
                    </Box>
                  ) : promptTemplates.length > 0 ? (
                    promptTemplates.map((template, i) => (
                      <ListItem 
                        button
                        key={i}
                        onClick={() => handleSelectTemplate(template.id)}
                        sx={{ 
                          p: 1.5, 
                          mb: 1, 
                          bgcolor: 'rgba(0,0,0,0.2)', 
                          borderRadius: 2,
                          border: '1px solid rgba(255,255,255,0.05)',
                          transition: 'all 0.2s ease',
                          '&:hover': {
                            bgcolor: 'rgba(58,114,248,0.1)',
                            borderColor: 'rgba(58,114,248,0.3)',
                            transform: 'translateY(-2px)'
                          }
                        }}
                      >
                        <TipsAndUpdatesIcon sx={{ mr: 1.5, color: theme.palette.primary.main, fontSize: 18 }} />
                        <Box>
                          <Typography variant="body2" sx={{ fontSize: '0.85rem' }}>
                            {template.name}
                          </Typography>
                          {template.description && (
                            <Typography 
                              variant="caption" 
                              color="text.secondary" 
                              sx={{ 
                                fontSize: '0.7rem',
                                display: 'block',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                                maxWidth: '180px'
                              }}
                            >
                              {template.description}
                            </Typography>
                          )}
                        </Box>
                      </ListItem>
                    ))
                  ) : (
                    <Box sx={{ p: 2, textAlign: 'center' }}>
                      <Typography variant="caption" color="text.secondary">
                        No templates available
                      </Typography>
                    </Box>
                  )}
                </List>
              </Collapse>
            </>
          )}
        </Box>
        
        {/* System Status and Logout section */}
        <Box sx={{ 
          mt: 'auto',  // Push to the bottom
          pt: 2
        }}>
          {/* System Status section */}
          <ListItem 
            button 
            onClick={() => setSystemStatusOpen(!systemStatusOpen)}
            sx={{ 
              px: 2,
              color: 'rgba(255,255,255,0.7)',
              mb: 1,
              borderRadius: '12px',
              transition: 'all 0.2s ease',
              '&:hover': {
                background: 'rgba(255,255,255,0.05)',
              },
            }}
          >
            <Badge
              variant="dot"
              overlap="circular"
              color={
                systemHealth === 'error' ? 'error' :
                systemHealth === 'initializing' ? 'warning' :
                systemHealth === 'running' ? 'success' : 'default'
              }
              sx={{ 
                '& .MuiBadge-badge': {
                  right: 3,
                  top: 13,
                  border: `2px solid ${theme.palette.background.dark}`,
                  padding: '0 4px',
                }
              }}
            >
              <ListItemIcon sx={{ minWidth: 40, color: 'rgba(255,255,255,0.7)' }}>
                <DeveloperBoardIcon />
              </ListItemIcon>
            </Badge>
            <ListItemText 
              primary="System Status" 
              secondary={systemHealth === 'error' ? 'Issues detected' : 
                        systemHealth === 'initializing' ? 'Initializing' : 
                        systemHealth === 'running' ? 'All systems operational' : 
                        'Status unknown'}
              primaryTypographyProps={{ fontWeight: 500 }}
              secondaryTypographyProps={{ 
                color: getStatusColor(systemHealth),
                fontSize: '0.7rem' 
              }}
            />
            
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Tooltip title="Refresh status" placement="top">
                <Box 
                  component="span" 
                  onClick={handleRefreshStatus} 
                  sx={{ 
                    display: 'flex', 
                    mr: 1,
                    p: 0.5,
                    borderRadius: '50%',
                    '&:hover': { bgcolor: 'rgba(255,255,255,0.1)' },
                    cursor: 'pointer'
                  }}
                >
                  {isLoading ? (
                    <CircularProgress size={18} color="inherit" sx={{ opacity: 0.7 }} />
                  ) : (
                    <RefreshIcon fontSize="small" sx={{ opacity: 0.7 }} />
                  )}
                </Box>
              </Tooltip>
              
              {systemStatusOpen ? <ExpandMoreIcon fontSize="small" /> : <ChevronRightIcon fontSize="small" />}
            </Box>
          </ListItem>
          
          <Collapse 
            in={systemStatusOpen} 
            timeout="auto" 
            unmountOnExit
            sx={{ 
              // Added to make the system status scrollable independently
              maxHeight: 'calc(100vh - 500px)',
              overflowY: 'auto',
              '&::-webkit-scrollbar': {
                width: '4px',
              },
              '&::-webkit-scrollbar-thumb': {
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
                borderRadius: '4px',
              }
            }}
          >
            <Box 
              sx={{
                p: 2,
                borderRadius: 2,
                background: 'rgba(10, 16, 31, 0.6)',
                border: '1px solid rgba(99, 117, 149, 0.2)',
                mb: 2,
                mx: 1,
                backdropFilter: 'blur(8px)'
              }}
            >
              {isLoading && serviceStatuses.length === 0 ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
                  <CircularProgress size={24} />
                </Box>
              ) : error ? (
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <ErrorIcon color="error" sx={{ mr: 1, fontSize: 18 }} />
                    <Typography variant="caption" color="error.main">
                      {error}
                    </Typography>
                  </Box>
                  <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
                    The system status could not be retrieved. Please check the API endpoints and network connectivity.
                  </Typography>
                </Box>
              ) : serviceStatuses.length > 0 ? (
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Chip 
                        size="small" 
                        label={
                          systemHealth === 'running' ? 'All Systems Operational' :
                          systemHealth === 'initializing' ? 'Systems Initializing' :
                          systemHealth === 'error' ? 'System Issues Detected' :
                          'Status Unknown'
                        }
                        sx={{ 
                          bgcolor: `${getStatusColor(systemHealth)}20`,
                          color: getStatusColor(systemHealth),
                          fontWeight: 600,
                          fontSize: '0.7rem',
                          height: 20
                        }}
                      />

                      {systemInfo && systemInfo.environment !== 'production' && (
                        <Chip 
                          size="small" 
                          label={systemInfo.environment.toUpperCase()}
                          sx={{ 
                            height: 16,
                            fontSize: '0.55rem',
                            ml: 0.7,
                            fontWeight: 700,
                            backgroundColor: systemInfo.environment === 'development' 
                              ? alpha(theme.palette.warning.main, 0.2)
                              : alpha(theme.palette.info.main, 0.2),
                            color: systemInfo.environment === 'development'
                              ? theme.palette.warning.main
                              : theme.palette.info.main,
                            '& .MuiChip-label': {
                              px: 0.8,
                              py: 0
                            }
                          }}
                        />
                      )}
                    </Box>
                    
                    {lastUpdated && (
                      <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                        Updated: {lastUpdated.toLocaleTimeString()}
                      </Typography>
                    )}
                  </Box>
                  
                  {/* Database info section */}
                  {dbInfo && (
                    <Box 
                      sx={{
                        mt: 2,
                        mb: 2,
                        p: 1.5,
                        borderRadius: 1.5,
                        backgroundColor: alpha(theme.palette.primary.main, 0.08),
                        border: `1px solid ${alpha(theme.palette.primary.main, 0.15)}`,
                        display: 'flex',
                        alignItems: 'center',
                        flexDirection: 'column'
                      }}
                    >
                      <Box sx={{ display: 'flex', alignItems: 'center', width: '100%', mb: 1 }}>
                        <DatabaseIcon sx={{ 
                          color: theme.palette.primary.main, 
                          mr: 1, 
                          fontSize: 16 
                        }} />
                        <Typography variant="caption" sx={{ 
                          fontWeight: 600, 
                          color: theme.palette.primary.main,
                          fontSize: '0.7rem'
                        }}>
                          Database Connection
                        </Typography>
                      </Box>
                      
                      <Box sx={{ width: '100%' }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                            Type:
                          </Typography>
                          <Typography variant="caption" sx={{ 
                            fontWeight: 500, 
                            fontSize: '0.65rem',
                            display: 'flex',
                            alignItems: 'center' 
                          }}>
                            {/* Use the db_system field from the API */}
                            {dbInfo.db_system || (dbInfo.is_documentdb ? 'Amazon DocumentDB' : dbInfo.type)}
                            {dbInfo.is_documentdb && (
                              <Tooltip title="AWS-managed MongoDB-compatible database">
                                <Box component="span" sx={{ display: 'inline-flex', ml: 0.5 }}>
                                  <StorageTwoToneIcon sx={{ fontSize: 12, color: theme.palette.info.main }} />
                                </Box>
                              </Tooltip>
                            )}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                            Database:
                          </Typography>
                          <Typography variant="caption" sx={{ fontWeight: 500, fontSize: '0.65rem' }}>
                            {dbInfo.name}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                            Host:
                          </Typography>
                          <Typography variant="caption" sx={{ fontWeight: 500, fontSize: '0.65rem' }}>
                            {/* Apply masking only in production */}
                            {systemInfo && systemInfo.environment === 'production' 
                              ? dbInfo.host.includes('.') 
                                ? '*.'+dbInfo.host.split('.').slice(1).join('.') 
                                : dbInfo.host
                              : dbInfo.host}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                          <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.65rem' }}>
                            Documents:
                          </Typography>
                          <Typography variant="caption" sx={{ fontWeight: 500, fontSize: '0.65rem' }}>
                            {/* Use the document count from API */}
                            {dbInfo.document_count || 0}
                          </Typography>
                        </Box>
                      </Box>
                    </Box>
                  )}
                  
                  {serviceStatuses.map((service, index) => (
                    <Fade key={service.name} in={true} timeout={100 * (index + 1)}>
                      <Box key={service.name} sx={{ mb: index < serviceStatuses.length - 1 ? 2 : 0 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            {getServiceIcon(service.name)}
                            <Typography variant="caption" color="rgba(255,255,255,0.7)" sx={{ ml: 0.5 }}>
                              {service.name.replace(/_/g, ' ')}
                            </Typography>
                          </Box>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            {getStatusIcon(service.status)}
                            <Typography variant="caption" color={getStatusColor(service.status)}>
                              {service.status}
                            </Typography>
                          </Box>
                        </Box>
                        <LinearProgress 
                          variant={service.status === 'initializing' ? 'indeterminate' : 'determinate'}
                          value={service.status === 'running' ? 100 : service.status === 'initializing' ? 50 : 0} 
                          sx={{ 
                            height: 4, 
                            borderRadius: 2,
                            bgcolor: 'rgba(255, 255, 255, 0.1)',
                            '& .MuiLinearProgress-bar': {
                              bgcolor: getStatusColor(service.status),
                            }
                          }} 
                        />
                        {service.message && (
                          <Typography variant="caption" color="text.secondary" sx={{ mt: 0.5, display: 'block', fontSize: '0.7rem' }}>
                            {service.message}
                          </Typography>
                        )}
                      </Box>
                    </Fade>
                  ))}
                </Box>
              ) : (
                <Typography variant="caption" color="text.secondary">
                  No service information available. Waiting for system data...
                </Typography>
              )}
            </Box>
          </Collapse>
          
          {/* Logout Button */}
          <ListItem 
            button 
            onClick={handleLogout}
            sx={{ 
              px: 2,
              color: 'rgba(255,255,255,0.7)',
              mt: 1,
              mb: 1,
              borderRadius: '12px',
              transition: 'all 0.3s ease',
              background: 'rgba(239, 68, 68, 0.08)',
              borderLeft: '3px solid rgba(239, 68, 68, 0.3)',
              overflow: 'hidden',
              position: 'relative',
              '&:hover': {
                background: 'rgba(239, 68, 68, 0.15)',
                '& .hover-effect': {
                  left: '120%',
                }
              },
            }}
          >
            <Box 
              className="hover-effect"
              sx={{
                position: 'absolute',
                width: '30px',
                height: '100%',
                background: 'linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.2) 50%, rgba(255,255,255,0) 100%)',
                transform: 'skewX(-15deg)',
                left: '-100%',
                top: 0,
                transition: 'left 0.5s ease',
              }}
            />
            <ListItemIcon sx={{ minWidth: 40, color: theme.palette.error.light }}>
              <LogoutIcon />
            </ListItemIcon>
            <ListItemText 
              primary="Sign Out" 
              primaryTypographyProps={{ 
                fontWeight: 500,
                sx: {
                  transition: 'all 0.2s ease',
                }
              }}
            />
          </ListItem>
        </Box>
      </Box>
    </Drawer>
  );
};

export default Sidebar;