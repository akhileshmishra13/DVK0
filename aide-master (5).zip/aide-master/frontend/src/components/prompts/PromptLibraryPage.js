// frontend/src/components/prompts/PromptLibraryPage.js
import React from 'react';
import { Box, Typography, Paper } from '@mui/material';
import PromptLibrary from './PromptLibrary';

const PromptLibraryPage = () => {
  const handleSelectTemplate = (template) => {
    console.log("Selected template:", template);
    // Navigate to assistant page with template
    // This would be implemented based on your app's navigation needs
  };

  return (
    <Box>
      <Paper sx={{ p: 3, borderRadius: 2 }}>
        <PromptLibrary onSelectTemplate={handleSelectTemplate} />
      </Paper>
    </Box>
  );
};

export default PromptLibraryPage;