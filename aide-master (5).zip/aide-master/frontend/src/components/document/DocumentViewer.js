import React, { useState, useEffect } from 'react';
import { 
  Dialog, 
  DialogTitle, 
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Chip,
  IconButton,
  Grid,
  useTheme,
  LinearProgress,
  Tooltip
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import DownloadIcon from '@mui/icons-material/Download';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import SummarizeIcon from '@mui/icons-material/Summarize';
import DataObjectIcon from '@mui/icons-material/DataObject';
import TextSnippetIcon from '@mui/icons-material/TextSnippet';
import AssessmentIcon from '@mui/icons-material/Assessment';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import WarningIcon from '@mui/icons-material/Warning';

import { extractionApi } from '../../services/apiService';
import { estimateTokensFromText, UI } from '../../config/documentConfig';
import modelConfig from '../../config/modelConfig';

const DocumentViewer = ({ open, onClose, document }) => {
  const theme = useTheme();
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(true);
  const [documentContent, setDocumentContent] = useState('');
  const [documentMetadata, setDocumentMetadata] = useState(null);
  const [documentStructure, setDocumentStructure] = useState(null);
  const [aiInsights, setAiInsights] = useState(null);
  const [tokenInfo, setTokenInfo] = useState({
    estimated: 0,
    reported: 0
  });
  
  useEffect(() => {
    if (open && document) {
      fetchDocumentData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, document]);
  
  useEffect(() => {
    if (documentContent) {
      const estimatedTokens = estimateTokensFromText(documentContent);
      setTokenInfo(prev => ({
        ...prev,
        estimated: estimatedTokens,
        // Use reported token count if available
        reported: document.token_count || estimatedTokens
      }));
    }
  }, [documentContent, document]);
  
  const fetchDocumentData = async () => {
    setLoading(true);
    try {
      // Fetch document text
      const textResponse = await extractionApi.getDocumentText(document.document_id);
      if (textResponse.data && textResponse.data.status === 'success') {
        setDocumentContent(textResponse.data.data.text);
      }
      
      // Fetch document metadata
      const metadataResponse = await extractionApi.getDocumentMetadata(document.document_id);
      if (metadataResponse.data && metadataResponse.data.status === 'success') {
        setDocumentMetadata(metadataResponse.data.data.metadata);
      }
      
      // Fetch document structure
      const structureResponse = await extractionApi.getDocumentStructure(document.document_id);
      if (structureResponse.data && structureResponse.data.status === 'success') {
        setDocumentStructure(structureResponse.data.data.structure);
        
        // Generate AI insights based on the extracted data
        generateAiInsights(
          metadataResponse.data.data.metadata,
          structureResponse.data.data.structure
        );
      }
    } catch (error) {
      console.error("Error fetching document data:", error);
    } finally {
      setLoading(false);
    }
  };
  
  const generateAiInsights = (metadata, structure) => {
    // In a real application, this might come from the backend
    // Here we're generating sample insights based on available data
    const insights = {
      summary: "This document outlines the investment opportunity for Project " + 
        (metadata?.project_name || "Unknown") + " in the " + 
        (metadata?.industry_sector || "unspecified") + " sector.",
      keyPoints: structure?.key_points || [],
      financialHighlights: structure?.financial_metrics || {},
      investmentConsiderations: [
        "Consider the competitive landscape analysis on page 12",
        "Review regulatory considerations in section 5.2",
        "Conduct further due diligence on revenue projections"
      ],
      recommendations: [
        "Proceed to detailed financial analysis",
        "Schedule management interviews to validate assumptions",
        "Compare with similar deals in portfolio"
      ]
    };
    
    setAiInsights(insights);
  };
  
  const handleCopyText = () => {
    navigator.clipboard.writeText(documentContent);
    // Could add a snackbar notification here
  };
  
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  
  const renderTabContent = () => {
    if (loading) {
      return (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', py: 8 }}>
          <CircularProgress />
        </Box>
      );
    }
    
    switch (activeTab) {
      case 0: // Text Content
        return (
          <Box>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2, alignItems: 'center' }}>
              <Chip
                icon={<DataObjectIcon sx={{ fontSize: '0.75rem !important' }} />}
                label={`${tokenInfo.reported.toLocaleString()} tokens estimated`}
                size="small"
                sx={{ 
                  height: 24, 
                  fontSize: '0.7rem',
                  bgcolor: 'rgba(58, 114, 248, 0.1)',
                  color: theme.palette.primary.main
                }}
              />
              
              <Button 
                startIcon={<ContentCopyIcon />} 
                onClick={handleCopyText}
                size="small"
              >
                Copy Text
              </Button>
            </Box>
            
            {/* Model compatibility indicators */}
            <Box sx={{ mb: 2, display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {modelConfig.map(model => {
                if (model.type === 'primary' || model.type === 'ultra_context' || model.type === 'text_extract') {
                  const isCompatible = tokenInfo.reported <= model.contextWindow;
                  return (
                    <Chip
                      key={model.type}
                      size="small"
                      icon={React.cloneElement(model.icon, { style: { fontSize: '0.75rem' } })}
                      label={`${isCompatible ? 'Compatible with' : 'Exceeds'} ${model.displayName} (${(model.contextWindow/1000).toFixed(0)}K tokens)`}
                      sx={{ 
                        height: 24, 
                        fontSize: '0.7rem',
                        bgcolor: isCompatible ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)',
                        color: isCompatible ? theme.palette.success.main : theme.palette.error.main
                      }}
                    />
                  );
                }
                return null;
              })}
            </Box>
            
            {/* Token usage bars */}
            <Box sx={{ mb: 3 }}>
              {modelConfig.map(model => {
                if (model.type === 'primary' || model.type === 'ultra_context') {
                  const percentage = Math.min(100, (tokenInfo.reported / model.contextWindow) * 100);
                  return (
                    <Box key={model.type} sx={{ mb: 1 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
                        <Typography variant="caption" color="text.secondary">
                          {model.displayName}: {tokenInfo.reported.toLocaleString()} / {model.contextWindow.toLocaleString()} tokens
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {percentage.toFixed(1)}%
                        </Typography>
                      </Box>
                      <LinearProgress 
                        variant="determinate" 
                        value={percentage} 
                        sx={{ 
                          height: 4, 
                          borderRadius: 2,
                          bgcolor: 'rgba(255,255,255,0.05)',
                          '& .MuiLinearProgress-bar': {
                            bgcolor: percentage > 90 ? UI.COLORS.error : 
                                    percentage > 70 ? UI.COLORS.warning : 
                                    UI.COLORS.success
                          }
                        }}
                      />
                    </Box>
                  );
                }
                return null;
              })}
            </Box>
            
            <Paper 
              elevation={0}
              sx={{ 
                p: 3, 
                borderRadius: 2, 
                bgcolor: 'background.default',
                border: `1px solid ${theme.palette.divider}`,
                maxHeight: '60vh',
                overflow: 'auto'
              }}
            >
              <Typography
                component="pre"
                sx={{
                  whiteSpace: 'pre-wrap',
                  fontFamily: 'monospace',
                  fontSize: '0.875rem',
                  lineHeight: 1.7
                }}
              >
                {documentContent || 'No text content available'}
              </Typography>
            </Paper>
          </Box>
        );
        
      case 1: // Metadata
        return (
          <Box>
            {documentMetadata ? (
              <Paper 
                elevation={0}
                sx={{ 
                  borderRadius: 2, 
                  overflow: 'hidden',
                  border: `1px solid ${theme.palette.divider}`
                }}
              >
                <TableContainer>
                  <Table>
                    <TableHead sx={{ bgcolor: 'background.default' }}>
                      <TableRow>
                        <TableCell width="30%">Property</TableCell>
                        <TableCell>Value</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {Object.entries(documentMetadata).map(([key, value]) => (
                        <TableRow key={key}>
                          <TableCell 
                            component="th" 
                            scope="row"
                            sx={{ 
                              fontWeight: 600,
                              textTransform: 'capitalize'
                            }}
                          >
                            {key.replace(/_/g, ' ')}
                          </TableCell>
                          <TableCell>
                            {typeof value === 'object' ? 
                              JSON.stringify(value) : 
                              String(value)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              </Paper>
            ) : (
              <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
                No metadata available
              </Typography>
            )}
          </Box>
        );
        
      case 2: // Structure
        return (
          <Box>
            {documentStructure ? (
              <Box>
                {/* Sections */}
                {documentStructure.sections?.length > 0 && (
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                      Document Sections
                    </Typography>
                    <Paper 
                      elevation={0}
                      sx={{ 
                        borderRadius: 2, 
                        overflow: 'hidden',
                        border: `1px solid ${theme.palette.divider}`
                      }}
                    >
                      <TableContainer>
                        <Table>
                          <TableHead sx={{ bgcolor: 'background.default' }}>
                            <TableRow>
                              <TableCell>Level</TableCell>
                              <TableCell>Heading</TableCell>
                              <TableCell>Content Preview</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {documentStructure.sections.map((section, index) => (
                              <TableRow key={index}>
                                <TableCell>{section.level}</TableCell>
                                <TableCell sx={{ fontWeight: 600 }}>
                                  {section.heading}
                                </TableCell>
                                <TableCell>
                                  {section.content?.length > 100 ? 
                                    section.content.substring(0, 100) + '...' : 
                                    section.content}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </Paper>
                  </Box>
                )}
                
                {/* Tables */}
                {documentStructure.tables?.length > 0 && (
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                      Tables ({documentStructure.tables.length})
                    </Typography>
                    {documentStructure.tables.map((table, tableIndex) => (
                      <Paper 
                        key={tableIndex}
                        elevation={0}
                        sx={{ 
                          borderRadius: 2, 
                          overflow: 'hidden',
                          border: `1px solid ${theme.palette.divider}`,
                          mb: 3
                        }}
                      >
                        <Box sx={{ p: 2, bgcolor: 'background.default' }}>
                          <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                            {table.caption || `Table ${tableIndex + 1}`}
                          </Typography>
                        </Box>
                        <TableContainer>
                          <Table size="small">
                            <TableHead>
                              <TableRow>
                                {table.headers.map((header, headerIndex) => (
                                  <TableCell key={headerIndex} sx={{ fontWeight: 600 }}>
                                    {header}
                                  </TableCell>
                                ))}
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {table.data.map((row, rowIndex) => (
                                <TableRow key={rowIndex}>
                                  {row.map((cell, cellIndex) => (
                                    <TableCell key={cellIndex}>{cell}</TableCell>
                                  ))}
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </Paper>
                    ))}
                  </Box>
                )}
                
                {/* Financial Metrics */}
                {documentStructure.financial_metrics && 
                 Object.keys(documentStructure.financial_metrics).length > 0 && (
                  <Box sx={{ mb: 4 }}>
                    <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                      Financial Metrics
                    </Typography>
                    <Paper 
                      elevation={0}
                      sx={{ 
                        borderRadius: 2, 
                        overflow: 'hidden',
                        border: `1px solid ${theme.palette.divider}`
                      }}
                    >
                      <TableContainer>
                        <Table>
                          <TableHead sx={{ bgcolor: 'background.default' }}>
                            <TableRow>
                              <TableCell>Metric</TableCell>
                              <TableCell>Value</TableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {Object.entries(documentStructure.financial_metrics).map(([key, value]) => (
                              <TableRow key={key}>
                                <TableCell 
                                  sx={{ 
                                    fontWeight: 600,
                                    textTransform: 'capitalize'
                                  }}
                                >
                                  {key.replace(/_/g, ' ')}
                                </TableCell>
                                <TableCell>
                                  {typeof value === 'object' ? 
                                    JSON.stringify(value) : 
                                    String(value)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </Paper>
                  </Box>
                )}
                
                {/* Key Points */}
                {documentStructure.key_points?.length > 0 && (
                  <Box>
                    <Typography variant="h6" sx={{ mb: 2, fontWeight: 600 }}>
                      Key Points
                    </Typography>
                    <Paper 
                      elevation={0}
                      sx={{ 
                        p: 3, 
                        borderRadius: 2,
                        border: `1px solid ${theme.palette.divider}`
                      }}
                    >
                      <Box component="ul" sx={{ m: 0, pl: 2 }}>
                        {documentStructure.key_points.map((point, index) => (
                          <Typography 
                            component="li" 
                            variant="body2" 
                            key={index}
                            sx={{ mb: 1 }}
                          >
                            {point}
                          </Typography>
                        ))}
                      </Box>
                    </Paper>
                  </Box>
                )}
              </Box>
            ) : (
              <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
                No structure information available
              </Typography>
            )}
          </Box>
        );
        
      case 3: // AI Insights
        return (
          <Box>
            {aiInsights ? (
              <Grid container spacing={3}>
                {/* Summary */}
                <Grid item xs={12}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 3, 
                      borderRadius: 2,
                      border: `1px solid ${theme.palette.divider}`,
                      bgcolor: `${theme.palette.primary.main}05`
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 2 }}>
                      <AutoAwesomeIcon 
                        sx={{ 
                          color: theme.palette.primary.main,
                          mr: 1.5,
                          mt: 0.5
                        }}
                      />
                      <Typography variant="h6" sx={{ fontWeight: 600 }}>
                        AI Summary
                      </Typography>
                    </Box>
                    <Typography variant="body1">
                      {aiInsights.summary}
                    </Typography>
                  </Paper>
                </Grid>
                
                {/* Key Points */}
                <Grid item xs={12} md={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 3, 
                      borderRadius: 2,
                      border: `1px solid ${theme.palette.divider}`,
                      height: '100%'
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <SummarizeIcon 
                        sx={{ 
                          color: theme.palette.info.main,
                          mr: 1.5
                        }}
                      />
                      <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                        Key Points
                      </Typography>
                    </Box>
                    
                    {aiInsights.keyPoints.length > 0 ? (
                      <Box component="ul" sx={{ m: 0, pl: 2 }}>
                        {aiInsights.keyPoints.map((point, index) => (
                          <Typography 
                            component="li" 
                            variant="body2" 
                            key={index}
                            sx={{ mb: 1 }}
                          >
                            {point}
                          </Typography>
                        ))}
                      </Box>
                    ) : (
                      <Typography variant="body2" color="text.secondary">
                        No key points extracted
                      </Typography>
                    )}
                  </Paper>
                </Grid>
                
                {/* Financial Highlights */}
                <Grid item xs={12} md={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 3, 
                      borderRadius: 2,
                      border: `1px solid ${theme.palette.divider}`,
                      height: '100%'
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <AssessmentIcon 
                        sx={{ 
                          color: theme.palette.success.main,
                          mr: 1.5
                        }}
                      />
                      <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                        Financial Highlights
                      </Typography>
                    </Box>
                    
                    {Object.keys(aiInsights.financialHighlights).length > 0 ? (
                      <TableContainer>
                        <Table size="small">
                          <TableBody>
                            {Object.entries(aiInsights.financialHighlights).map(([key, value]) => (
                              <TableRow key={key}>
                                <TableCell 
                                  sx={{ 
                                    fontWeight: 600,
                                    textTransform: 'capitalize',
                                    borderBottom: `1px solid ${theme.palette.divider}`,
                                    py: 1
                                  }}
                                >
                                  {key.replace(/_/g, ' ')}
                                </TableCell>
                                <TableCell sx={{ borderBottom: `1px solid ${theme.palette.divider}`, py: 1 }}>
                                  {typeof value === 'object' ? 
                                    JSON.stringify(value) : 
                                    String(value)}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    ) : (
                      <Typography variant="body2" color="text.secondary">
                        No financial metrics extracted
                      </Typography>
                    )}
                  </Paper>
                </Grid>
                
                {/* Investment Considerations */}
                <Grid item xs={12} md={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 3, 
                      borderRadius: 2,
                      border: `1px solid ${theme.palette.divider}`,
                      height: '100%'
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <DataObjectIcon 
                        sx={{ 
                          color: theme.palette.warning.main,
                          mr: 1.5
                        }}
                      />
                      <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                        Investment Considerations
                      </Typography>
                    </Box>
                    
                    <Box component="ul" sx={{ m: 0, pl: 2 }}>
                      {aiInsights.investmentConsiderations.map((item, index) => (
                        <Typography 
                          component="li" 
                          variant="body2" 
                          key={index}
                          sx={{ mb: 1 }}
                        >
                          {item}
                        </Typography>
                      ))}
                    </Box>
                  </Paper>
                </Grid>
                
                {/* Recommendations */}
                <Grid item xs={12} md={6}>
                  <Paper 
                    elevation={0}
                    sx={{ 
                      p: 3, 
                      borderRadius: 2,
                      border: `1px solid ${theme.palette.divider}`,
                      height: '100%'
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <TipsAndUpdatesIcon 
                        sx={{ 
                          color: theme.palette.secondary.main,
                          mr: 1.5
                        }}
                      />
                      <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                        AI Recommendations
                      </Typography>
                    </Box>
                    
                    <Box component="ul" sx={{ m: 0, pl: 2 }}>
                      {aiInsights.recommendations.map((item, index) => (
                        <Typography 
                          component="li" 
                          variant="body2" 
                          key={index}
                          sx={{ mb: 1 }}
                        >
                          {item}
                        </Typography>
                      ))}
                    </Box>
                  </Paper>
                </Grid>
              </Grid>
            ) : (
              <Typography color="text.secondary" sx={{ py: 4, textAlign: 'center' }}>
                AI insights are not available for this document
              </Typography>
            )}
          </Box>
        );
        
      default:
        return null;
    }
  };
  
  if (!document) return null;
  
  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="lg"
      fullWidth
      PaperProps={{
        sx: {
          borderRadius: 3,
          maxHeight: '90vh'
        }
      }}
    >
      <DialogTitle sx={{ px: 3, py: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Typography variant="h6" component="div" sx={{ fontWeight: 600 }}>
            {document.filename}
          </Typography>
          
          {document.metadata?.extracted_metadata && (
            <Chip 
              icon={<AutoAwesomeIcon sx={{ fontSize: '0.8rem' }} />}
              label="AI Processed"
              size="small"
              sx={{ 
                ml: 2,
                fontSize: '0.7rem',
                bgcolor: theme.palette.success.main + '15',
                color: theme.palette.success.main,
                height: 24,
                '& .MuiChip-icon': {
                  color: theme.palette.success.main
                }
              }}
            />
          )}
          
          <Chip
            icon={<DataObjectIcon sx={{ fontSize: '0.7rem !important' }} />}
            label={tokenInfo.reported > 0 ? `~${tokenInfo.reported.toLocaleString()} tokens` : 'Calculating...'}
            size="small"
            sx={{ 
              ml: 1, 
              height: 22, 
              fontSize: '0.65rem',
              bgcolor: 'rgba(0, 0, 0, 0.2)'
            }}
          />
        </Box>
        
        <Box>
          <IconButton
            aria-label="close"
            onClick={onClose}
            size="small"
          >
            <CloseIcon />
          </IconButton>
        </Box>
      </DialogTitle>
      
      <Box sx={{ px: 3, borderBottom: `1px solid ${theme.palette.divider}` }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            '& .MuiTab-root': {
              minWidth: 'auto',
              px: 3,
              py: 2,
              textTransform: 'none',
              fontSize: '0.875rem',
              fontWeight: 500,
              minHeight: 48,
            }
          }}
        >
          <Tab 
            icon={<TextSnippetIcon fontSize="small" />} 
            iconPosition="start" 
            label="Text Content" 
          />
          <Tab 
            icon={<DataObjectIcon fontSize="small" />} 
            iconPosition="start" 
            label="Metadata" 
          />
          <Tab 
            icon={<AssessmentIcon fontSize="small" />} 
            iconPosition="start" 
            label="Structure" 
          />
          <Tab 
            icon={<AutoAwesomeIcon fontSize="small" />} 
            iconPosition="start" 
            label="AI Insights" 
          />
        </Tabs>
      </Box>
      
      <DialogContent sx={{ px: 3, py: 3 }}>
        {renderTabContent()}
      </DialogContent>
      
      <DialogActions sx={{ px: 3, py: 2, borderTop: `1px solid ${theme.palette.divider}` }}>
        <Button 
          startIcon={<DownloadIcon />}
          variant="outlined"
          sx={{ 
            borderRadius: 2,
            textTransform: 'none'
          }}
        >
          Download PDF
        </Button>
        
        <Button
          startIcon={<OpenInNewIcon />}
          variant="contained"
          sx={{ 
            borderRadius: 2,
            textTransform: 'none',
            background: UI.GRADIENTS.primary,
            ml: 2
          }}
        >
          Analyze in Deal Workbench
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DocumentViewer;