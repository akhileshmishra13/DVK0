// frontend/src/components/AIAssistantPage.jsx
import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Typography, 
  Box,
  Paper,
  Divider,
  IconButton,
  Button, 
  TextField,
  useTheme,
  CircularProgress,
  MenuItem,
  Chip,
  Switch,
  FormControlLabel,
  Menu,
  Avatar,
  Grid,
  Tooltip,
  Alert,
  Snackbar,
  Link,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Collapse,
  Card,
  CardContent,
  Badge,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  alpha,
  Container,
  useMediaQuery
} from '@mui/material';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import SettingsIcon from '@mui/icons-material/Settings';
import PublicIcon from '@mui/icons-material/Public';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import DoneIcon from '@mui/icons-material/Done';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import PersonIcon from '@mui/icons-material/Person';
import GrainIcon from '@mui/icons-material/Grain';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import LineStyleIcon from '@mui/icons-material/LineStyle';
import LinkIcon from '@mui/icons-material/Link';
import DescriptionIcon from '@mui/icons-material/Description';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import MemoryIcon from '@mui/icons-material/Memory';
import TerminalIcon from '@mui/icons-material/Terminal';
import DataObjectIcon from '@mui/icons-material/DataObject';
import AlternateEmailIcon from '@mui/icons-material/AlternateEmail';
import StorageIcon from '@mui/icons-material/Storage';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import EventNoteIcon from '@mui/icons-material/EventNote';
import PieChartIcon from '@mui/icons-material/PieChart';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import ShowChartIcon from '@mui/icons-material/ShowChart';
import EqualizerIcon from '@mui/icons-material/Equalizer';
import LanguageIcon from '@mui/icons-material/Language';
import RestartAltIcon from '@mui/icons-material/RestartAlt';
import AddIcon from '@mui/icons-material/Add';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import FilterNoneIcon from '@mui/icons-material/FilterNone';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import FolderOpenIcon from '@mui/icons-material/FolderOpen';
import PsychologyIcon from '@mui/icons-material/Psychology';
import CreateIcon from '@mui/icons-material/Create';
import CheckIcon from '@mui/icons-material/Check';

// Markdown rendering
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import rehypeHighlight from 'rehype-highlight';
import 'highlight.js/styles/github-dark.css';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';

import { promptApi } from '../../services/apiService';
import { createCompletion, getCompletionStatus, clearResponses, updateElapsedTime, updateThinkingPhase } from '../../store/aiSlice';
import { addSelectedDocument, removeSelectedDocument, clearSelectedDocuments, fetchDocuments } from '../../store/documentSlice';
import CompletionProgress from '../common/CompletionProgress';
import modelConfig from '../../config/modelConfig';
import DocumentSelector from '../document/DocumentSelector';

// Component for professional document source attribution display with page citations
const DocumentSourceAttribution = ({ selectedDocuments }) => {
  const theme = useTheme();
  
  if (!selectedDocuments || selectedDocuments.length === 0) {
    return null;
  }
  
  return (
    <Box sx={{ mt: 4, pt: 2, borderTop: `1px solid ${alpha(theme.palette.divider, 0.2)}` }}>
      <Typography variant="subtitle2" sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        color: theme.palette.warning.main,
        mb: 2,
        fontWeight: 600,
        textTransform: 'uppercase',
        fontSize: '0.75rem',
        letterSpacing: '0.05em'
      }}>
        <DescriptionIcon sx={{ mr: 0.75, fontSize: 16 }} />
        Document Sources
      </Typography>
      
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
        {selectedDocuments.map((doc, index) => {
          // Extract citation information if available
          const citations = doc.citations || [];
          const hasPageCitations = citations.length > 0;
          
          return (
            <Paper
              key={index}
              elevation={0}
              sx={{
                p: 1.5,
                borderRadius: 2,
                bgcolor: alpha(theme.palette.warning.main, 0.05),
                border: `1px solid ${alpha(theme.palette.warning.main, 0.1)}`
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5, alignItems: 'center' }}>
                <Typography variant="body2" sx={{ fontWeight: 600, display: 'flex', alignItems: 'center', fontSize: '0.8rem' }}>
                  <InsertDriveFileIcon sx={{ fontSize: 14, mr: 0.75, color: theme.palette.warning.main }} />
                  {doc.filename}
                </Typography>
                {doc.metadata?.extracted_metadata?.document_type && (
                  <Chip
                    size="small"
                    label={doc.metadata.extracted_metadata.document_type}
                    sx={{
                      height: 18,
                      fontSize: '0.65rem',
                      bgcolor: theme.palette.warning.main + '15',
                      color: theme.palette.warning.main,
                      fontWeight: 500
                    }}
                  />
                )}
              </Box>
              
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5, fontSize: '0.7rem' }}>
                {doc.metadata?.extracted_metadata?.author_source || ""}
                {doc.metadata?.extracted_metadata?.date && ` • ${doc.metadata.extracted_metadata.date}`}
                {doc.length && ` • ${(doc.length / 1024 / 1024).toFixed(2)} MB`}
              </Typography>
              
              {/* Page citations section */}
              {hasPageCitations && (
                <Box sx={{ mt: 1 }}>
                  <Typography variant="caption" sx={{ fontWeight: 500, color: theme.palette.text.secondary, fontSize: '0.7rem' }}>
                    Referenced pages:
                  </Typography>
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 0.5 }}>
                    {citations.map((citation, i) => (
                      <Chip
                        key={i}
                        label={`Page ${citation.page}`}
                        size="small"
                        sx={{ 
                          height: 16, 
                          fontSize: '0.6rem',
                          bgcolor: alpha(theme.palette.warning.main, 0.15),
                          color: theme.palette.warning.main,
                          '& .MuiChip-label': { px: 0.75 }
                        }}
                      />
                    ))}
                  </Box>
                </Box>
              )}
              
              {doc.metadata?.extracted_metadata?.key_topics && (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mt: 1 }}>
                  {doc.metadata.extracted_metadata.key_topics.slice(0, 3).map((topic, i) => (
                    <Chip
                      key={i}
                      label={topic}
                      size="small"
                      variant="outlined"
                      sx={{ 
                        height: 16, 
                        fontSize: '0.6rem',
                        '& .MuiChip-label': { px: 0.75 }
                      }}
                    />
                  ))}
                </Box>
              )}
            </Paper>
          );
        })}
      </Box>
    </Box>
  );
};

// Component for professional grounding display 
const GroundingDisplay = ({ groundingData, responseText }) => {
  const theme = useTheme();

  // Extract citation numbers from text using regex
  const extractCitationNumbers = () => {
    if (!responseText) return [];
    
    const regex = /\[(\d+(?:,\s*\d+)*)\]/g;
    const citationSet = new Set();
    let match;
    
    while ((match = regex.exec(responseText)) !== null) {
      // Handle both single numbers [1] and multiple numbers [1, 2, 3]
      const numbers = match[1].split(',').map(num => parseInt(num.trim()));
      numbers.forEach(num => {
        if (!isNaN(num)) citationSet.add(num);
      });
    }
    
    return Array.from(citationSet).sort((a, b) => a - b);
  };
  
  const citationNumbers = extractCitationNumbers();
  const hasCitations = citationNumbers.length > 0;
  
  // Case 1: Citations in text but no attributions
  if (hasCitations && (!groundingData?.grounding_attributions || groundingData?.grounding_attributions.length === 0)) {
    return (
      <Box sx={{ mt: 4, pt: 2, borderTop: `1px solid ${alpha(theme.palette.divider, 0.2)}` }}>
        <Typography variant="subtitle2" sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          color: theme.palette.primary.main,
          mb: 2,
          fontWeight: 600,
          textTransform: 'uppercase',
          fontSize: '0.75rem',
          letterSpacing: '0.05em'
        }}>
          <PublicIcon sx={{ mr: 0.75, fontSize: 16 }} />
          Citation Information
        </Typography>
        
        <Paper
          elevation={0}
          sx={{
            p: 2,
            borderRadius: 2,
            bgcolor: alpha(theme.palette.primary.main, 0.05),
            border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
          }}
        >
          <Typography variant="body2" sx={{ fontWeight: 500, color: theme.palette.primary.main, mb: 1.5 }}>
            This response was grounded with Google Search and contains {citationNumbers.length} citation references.
          </Typography>
          
          <Typography variant="body2" sx={{ mb: 1.5 }}>
            Citation numbers found in text: {citationNumbers.map(num => 
              <Chip 
                key={num} 
                label={`[${num}]`}
                size="small"
                sx={{ 
                  ml: 0.5, 
                  mr: 0.5,
                  height: 20,
                  fontSize: '0.7rem',
                  bgcolor: alpha(theme.palette.primary.main, 0.15),
                  color: theme.palette.primary.main
                }}
              />
            )}
          </Typography>
          
          <Alert severity="info" sx={{ 
            fontSize: '0.8rem', 
            mb: 1.5, 
            '& .MuiAlert-icon': { fontSize: '1rem' }
          }}>
            According to Google's documentation, citations may appear in the text without providing URL metadata when the information is general knowledge or from sources with low relevance scores.
          </Alert>
          
          <Box sx={{ 
            p: 1.5, 
            bgcolor: alpha(theme.palette.background.paper, 0.2),
            borderRadius: 1,
            fontSize: '0.8rem',
            color: alpha('#fff', 0.7)
          }}>
            <Typography variant="body2" sx={{ mb: 0.5, fontStyle: 'italic' }}>
              From Google's documentation:
            </Typography>
            <Typography variant="body2" sx={{ fontStyle: 'italic', fontSize: '0.75rem' }}>
              "If your model prompt successfully grounds to Google Search, responses include metadata with source links. 
              However, there are several reasons this metadata might not be provided, including low source relevance or incomplete information."
            </Typography>
          </Box>
        </Paper>
      </Box>
    );
  }
  
  // Case 2: Regular grounding with attributions
  if (groundingData && groundingData.grounding_attributions && groundingData.grounding_attributions.length > 0) {
    return (
      <Box sx={{ mt: 4, pt: 2, borderTop: `1px solid ${alpha(theme.palette.divider, 0.2)}` }}>
        <Typography variant="subtitle2" sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          color: theme.palette.primary.main,
          mb: 2,
          fontWeight: 600,
          textTransform: 'uppercase',
          fontSize: '0.75rem',
          letterSpacing: '0.05em'
        }}>
          <PublicIcon sx={{ mr: 0.75, fontSize: 16 }} />
          External Sources
        </Typography>
        
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          {groundingData.grounding_attributions.map((attribution, index) => (
            <Paper
              key={index}
              elevation={0}
              sx={{
                p: 1.5,
                borderRadius: 2,
                bgcolor: alpha(theme.palette.primary.main, 0.05),
                border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
              }}
            >
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5, alignItems: 'center' }}>
                <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '0.8rem' }}>
                  {attribution.source_id?.web?.title || 'Source ' + (index + 1)}
                </Typography>
                <Chip
                  size="small"
                  label={`[${index + 1}]`}
                  sx={{
                    height: 20,
                    fontSize: '0.7rem',
                    bgcolor: alpha(theme.palette.primary.main, 0.15),
                    color: theme.palette.primary.main,
                    fontWeight: 500
                  }}
                />
              </Box>
              
              <Typography variant="caption" color="text.secondary" sx={{ display: 'flex', alignItems: 'center', mb: 0.75, fontSize: '0.7rem' }}>
                <LinkIcon sx={{ fontSize: 12, mr: 0.5, color: theme.palette.primary.main }} />
                <Link href={attribution.source_id?.web?.uri} target="_blank" sx={{ color: 'inherit', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {attribution.source_id?.web?.uri || '#'}
                </Link>
              </Typography>
              
              <Paper
                elevation={0}
                sx={{
                  p: 1.25,
                  borderRadius: 1.5,
                  bgcolor: alpha(theme.palette.background.paper, 0.2),
                  fontSize: '0.7rem',
                  fontStyle: 'italic',
                  color: 'text.secondary'
                }}
              >
                "{attribution.segment?.text || 'Referenced content'}"
              </Paper>
            </Paper>
          ))}
        </Box>
      </Box>
    );
  }
  
  // Case 3: Grounded but no attributions and no citations in text
  if (groundingData && (!groundingData.grounding_attributions || groundingData.grounding_attributions.length === 0)) {
    return (
      <Box sx={{ mt: 4, pt: 2, borderTop: `1px solid ${alpha(theme.palette.divider, 0.2)}` }}>
        <Typography variant="subtitle2" sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          color: theme.palette.primary.main,
          mb: 2,
          fontWeight: 600,
          textTransform: 'uppercase',
          fontSize: '0.75rem',
          letterSpacing: '0.05em'
        }}>
          <PublicIcon sx={{ mr: 0.75, fontSize: 16 }} />
          Grounding Information
        </Typography>
        
        <Paper
          elevation={0}
          sx={{
            p: 2,
            borderRadius: 2,
            bgcolor: alpha(theme.palette.primary.main, 0.05),
            border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
          }}
        >
          <Typography variant="body2">
            This response was generated with grounding using Google Search, but the model didn't need to cite specific external sources.
          </Typography>
          <Typography variant="body2" sx={{ mt: 1, color: 'text.secondary', fontSize: '0.8rem' }}>
            For specific citations, try asking about current events, specific facts, or details that would require external references.
          </Typography>
          
          <Box sx={{ mt: 2, bgcolor: alpha(theme.palette.primary.main, 0.08), p: 1.5, borderRadius: 1.5 }}>
            <Typography variant="caption" sx={{ fontWeight: 500, color: theme.palette.primary.main, display: 'flex', alignItems: 'center' }}>
              <InfoOutlinedIcon sx={{ fontSize: 14, mr: 0.5 }} />
              Example grounding queries:
            </Typography>
            <Box component="ul" sx={{ m: 0, mt: 0.5, pl: 2 }}>
              <Typography component="li" variant="caption" color="text.secondary">
                "What are the latest stock prices for MSFT, GOOGL, and META?"
              </Typography>
              <Typography component="li" variant="caption" color="text.secondary">
                "What are the main news events from yesterday?"
              </Typography>
              <Typography component="li" variant="caption" color="text.secondary">
                "What is the current interest rate set by the Federal Reserve?"
              </Typography>
            </Box>
          </Box>
        </Paper>
      </Box>
    );
  }
  
  // Case 4: No grounding at all
  return null;
};

// SOTA Thinking Visual Component
const ThinkingVisualizer = ({ thinkingPhase, elapsedTime }) => {
  const theme = useTheme();
  
  if (!thinkingPhase) return null;
  
  // Full descriptions for each phase
  const getPhaseDescription = (phase) => {
    switch(phase.toLowerCase()) {
      case 'analyzing':
        return "Conducting deep analysis of document content, identifying key information and critical data points";
      case 'planning':
        return "Planning comprehensive response structure with logical sections for optimized information delivery";
      case 'drafting':
        return "Drafting detailed analysis with supporting evidence and insights based on document content";
      case 'refining':
        return "Refining analysis, ensuring accuracy, coherence and logical flow between sections";
      case 'finalizing':
        return "Finalizing response with citations, summary insights and structured conclusions";
      default:
        return "Processing information and generating response";
    }
  };
  
  // Icons for each phase
  const getPhaseIcon = (phase) => {
    switch(phase.toLowerCase()) {
      case 'analyzing': return <DataObjectIcon />;
      case 'planning': return <EventNoteIcon />;
      case 'drafting': return <CreateIcon />;
      case 'refining': return <AutoAwesomeIcon />;
      case 'finalizing': return <CheckCircleIcon />;
      default: return <PsychologyIcon />;
    }
  };
  
  return (
    <Box sx={{ p: 3 }}>
      <Paper
        elevation={0}
        sx={{
          p: 2.5,
          borderRadius: 2,
          bgcolor: alpha(theme.palette.primary.main, 0.05),
          border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <PsychologyIcon sx={{ color: theme.palette.primary.main, mr: 1.5 }} />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            AI Thinking Process
          </Typography>
          {elapsedTime > 10 && (
            <Typography variant="caption" sx={{ ml: 2, fontFamily: 'monospace' }}>
              {Math.floor(elapsedTime / 60)}:{(elapsedTime % 60).toString().padStart(2, '0')} elapsed
            </Typography>
          )}
        </Box>
        
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5 }}>
          {['analyzing', 'planning', 'drafting', 'refining', 'finalizing'].map((phase, index) => {
            const isActive = thinkingPhase.toLowerCase() === phase;
            const isCompleted = ['analyzing', 'planning', 'drafting', 'refining', 'finalizing'].indexOf(thinkingPhase.toLowerCase()) > index;
            
            return (
              <Box 
                key={phase}
                sx={{
                  display: 'flex',
                  p: 1.5,
                  borderRadius: 1.5,
                  bgcolor: isActive 
                    ? alpha(theme.palette.primary.main, 0.1)
                    : isCompleted
                      ? alpha(theme.palette.success.main, 0.05)
                      : 'transparent',
                  border: `1px solid ${
                    isActive 
                      ? alpha(theme.palette.primary.main, 0.2)
                      : isCompleted
                        ? alpha(theme.palette.success.main, 0.1)
                        : 'transparent'
                  }`,
                  opacity: !isActive && !isCompleted ? 0.5 : 1
                }}
              >
                <Box 
                  sx={{ 
                    minWidth: 40, 
                    height: 40, 
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mr: 2,
                    bgcolor: isActive 
                      ? alpha(theme.palette.primary.main, 0.15)
                      : isCompleted
                        ? alpha(theme.palette.success.main, 0.15)
                        : alpha(theme.palette.text.secondary, 0.1),
                    color: isActive 
                      ? theme.palette.primary.main
                      : isCompleted
                        ? theme.palette.success.main
                        : theme.palette.text.secondary
                  }}
                >
                  {isCompleted && !isActive ? <CheckIcon /> : getPhaseIcon(phase)}
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography 
                    variant="subtitle1" 
                    sx={{ 
                      fontWeight: 600, 
                      mb: 0.5,
                      color: isActive 
                        ? theme.palette.primary.main
                        : isCompleted
                          ? theme.palette.success.main
                          : theme.palette.text.primary,
                      display: 'flex',
                      alignItems: 'center'
                    }}
                  >
                    {phase.charAt(0).toUpperCase() + phase.slice(1)}
                    {isActive && (
                      <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', ml: 1 }}>
                        <Box
                          component="span"
                          sx={{
                            height: 6,
                            width: 6,
                            bgcolor: theme.palette.primary.main,
                            borderRadius: '50%',
                            mr: 0.5,
                            animation: 'pulse 1.5s infinite ease-in-out'
                          }}
                        />
                        <Box
                          component="span"
                          sx={{
                            height: 6,
                            width: 6,
                            bgcolor: theme.palette.primary.main,
                            borderRadius: '50%',
                            mr: 0.5,
                            animation: 'pulse 1.5s infinite ease-in-out',
                            animationDelay: '0.5s'
                          }}
                        />
                        <Box
                          component="span"
                          sx={{
                            height: 6,
                            width: 6,
                            bgcolor: theme.palette.primary.main,
                            borderRadius: '50%',
                            animation: 'pulse 1.5s infinite ease-in-out',
                            animationDelay: '1s'
                          }}
                        />
                        <style>
                          {`
                            @keyframes pulse {
                              0% { opacity: 0.3; transform: scale(0.8); }
                              50% { opacity: 1; transform: scale(1.2); }
                              100% { opacity: 0.3; transform: scale(0.8); }
                            }
                          `}
                        </style>
                      </Box>
                    )}
                  </Typography>
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      color: isActive 
                        ? theme.palette.text.primary 
                        : theme.palette.text.secondary,
                      fontSize: '0.85rem'
                    }}
                  >
                    {isActive ? getPhaseDescription(phase) : `${phase.charAt(0).toUpperCase() + phase.slice(1)} phase ${isCompleted ? 'completed' : 'pending'}`}
                  </Typography>
                </Box>
              </Box>
            );
          })}
        </Box>
      </Paper>
    </Box>
  );
};

// Enhanced Progress Logs component for real-time processing details with SOTA visualization
const ProcessingLogs = ({ logs, thinkingPhase, elapsedTime }) => {
  const theme = useTheme();
  const logsEndRef = useRef(null);
  
  // Scroll to bottom whenever logs change
  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);
  
  const getIconForLogType = (type) => {
    switch (type) {
      case 'model':
        return <MemoryIcon sx={{ color: theme.palette.primary.main }} />;
      case 'prompt':
        return <TerminalIcon sx={{ color: theme.palette.info.main }} />;
      case 'extract':
        return <DataObjectIcon sx={{ color: theme.palette.warning.main }} />;
      case 'ground':
        return <LanguageIcon sx={{ color: theme.palette.secondary.main }} />;
      case 'analyze':
        return <AlternateEmailIcon sx={{ color: theme.palette.success.main }} />;
      case 'error':
        return <ErrorOutlineIcon sx={{ color: theme.palette.error.main }} />;
      case 'success':
        return <DoneIcon sx={{ color: theme.palette.success.main }} />;
      default:
        return <InfoOutlinedIcon sx={{ color: '#94A3B8' }} />;
    }
  };
  
  if (!logs || logs.length === 0) {
    return (
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column',
        alignItems: 'center', 
        justifyContent: 'center', 
        height: '100%', 
        p: 4
      }}>
        <CircularProgress size={50} thickness={4} sx={{ mb: 3 }} />
        <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
          Initializing AI Processing
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center' }}>
          Preparing to analyze your documents and prompt...
        </Typography>
      </Box>
    );
  }
  
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h6" sx={{ mb: 3, fontWeight: 600, display: 'flex', alignItems: 'center' }}>
        <AutoAwesomeIcon sx={{ mr: 1.5, color: theme.palette.primary.main }} />
        AI Processing Status
      </Typography>
      
      {/* Add SOTA Thinking Visualizer */}
      {thinkingPhase && <ThinkingVisualizer thinkingPhase={thinkingPhase} elapsedTime={elapsedTime} />}
      
      <Box sx={{ 
        maxHeight: thinkingPhase ? 'calc(100vh - 550px)' : 'calc(100vh - 300px)', 
        overflowY: 'auto',
        mb: 2,
        mt: thinkingPhase ? 3 : 0,
        pr: 1,
        '&::-webkit-scrollbar': {
          width: '6px',
        },
        '&::-webkit-scrollbar-thumb': {
          backgroundColor: alpha(theme.palette.divider, 0.3),
          borderRadius: '3px',
        }
      }}>
        <List>
          {logs.map((log, index) => (
            <ListItem
              key={index}
              sx={{ 
                py: 1.5,
                px: 2,
                mb: 1.5,
                borderRadius: 2,
                bgcolor: alpha(theme.palette.background.paper, 0.1),
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                display: 'flex',
                alignItems: 'flex-start',
              }}
            >
              <ListItemIcon sx={{ minWidth: 36, mt: 0.5 }}>
                {getIconForLogType(log.type)}
              </ListItemIcon>
              <ListItemText
                primary={log.message}
                secondary={log.timestamp}
                primaryTypographyProps={{ 
                  variant: 'body2', 
                  sx: { fontWeight: 500, wordBreak: 'break-word' } 
                }}
                secondaryTypographyProps={{ 
                  variant: 'caption', 
                  sx: { fontSize: '0.65rem', color: 'text.secondary' } 
                }}
              />
            </ListItem>
          ))}
          {/* Reference element for auto-scrolling */}
          <div ref={logsEndRef} />
        </List>
      </Box>
      
      {/* Enhanced progress indicator with elapsed time */}
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        mt: 2,
        p: 2,
        borderRadius: 2,
        bgcolor: alpha(theme.palette.primary.main, 0.05),
        border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
      }}>
        <CircularProgress size={20} sx={{ mr: 2 }} />
        <Typography variant="body2">
          Processing your request
          {elapsedTime > 30 && (
            <Typography component="span" variant="caption" sx={{ ml: 1, fontFamily: 'monospace' }}>
              ({Math.floor(elapsedTime / 60)}:{(elapsedTime % 60).toString().padStart(2, '0')} elapsed)
            </Typography>
          )}
        </Typography>
      </Box>
      
      {/* Add hints for long-running processes */}
      {elapsedTime > 60 && (
        <Box sx={{ mt: 2, p: 2, borderRadius: 2, bgcolor: alpha(theme.palette.background.paper, 0.1) }}>
          <Typography variant="caption" sx={{ display: 'flex', alignItems: 'center', color: theme.palette.warning.main }}>
            <InfoOutlinedIcon sx={{ fontSize: 14, mr: 0.5 }} /> 
            {elapsedTime > 300 
              ? "Analysis of large documents can take 10+ minutes for thorough results." 
              : elapsedTime > 180
                ? "SOTA thinking models perform deep analysis which takes time for better results."
                : "Large document analysis in progress. Thanks for your patience."}
          </Typography>
        </Box>
      )}
    </Box>
  );
};

// Enhanced financial analysis display component
const EnhancedResponse = ({ response, theme }) => {
  const [showReasoning, setShowReasoning] = useState(false);
  
  if (!response || !response.text) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="body1" color="error">
          No response content available. Please try running the analysis again.
        </Typography>
      </Box>
    );
  }
  
  // Check if reasoning is available
  const hasReasoning = response.reasoning || (response.provider === "bedrock" && response.model?.includes("claude-3-7"));
  
  // Find financial metrics in text using regex - for demonstration purpose
  const findMetrics = () => {
    const roiMatch = response.text.match(/ROI\D*(\d+(\.\d+)?%?)/i);
    const irrMatch = response.text.match(/IRR\D*(\d+(\.\d+)?%?)/i);
    const paybackMatch = response.text.match(/payback\D*(\d+(\.\d+)?\s*(year|yr|month|mo)s?)/i);
    const revenueMatch = response.text.match(/revenue\D*(\$\d+(\.\d+)?\s*(million|m|billion|b))/i);
    
    return {
      roi: roiMatch ? roiMatch[1] : null,
      irr: irrMatch ? irrMatch[1] : null,
      payback: paybackMatch ? paybackMatch[1] : null,
      revenue: revenueMatch ? revenueMatch[1] : null
    };
  };
  
  // Extract metrics if this contains financial information
  const metrics = findMetrics();
  const showMetricsPanel = metrics && (metrics.roi || metrics.irr || metrics.payback || metrics.revenue);
  
  // Format section numbers - improve numbered headers to match the reference style
  const processedText = response.text.replace(
    /^## (.*?)$/gm, 
    (match, section) => {
      // Extract any numbering at start of section
      const numberMatch = section.match(/^(\d+\.)\s*(.*)/);
      if (numberMatch) {
        return `## ${numberMatch[1]} ${numberMatch[2]}`;
      }
      return match;
    }
  );
  
  // Custom rendering components that make the output look more sophisticated
  const components = {
    h1: ({node, ...props}) => (
      <Typography
        variant="h4" 
        gutterBottom 
        {...props} 
        sx={{ 
          fontWeight: 700, 
          mt: 4, 
          mb: 2,
          fontSize: '1.5rem',
          letterSpacing: '-0.02em'
        }} 
      />
    ),
    h2: ({node, ...props}) => {
      // Check if props.children contains a numbering pattern like "1. Something"
      let heading = props.children;
      if (heading && typeof heading === 'string') {
        heading = heading;
      } else if (Array.isArray(heading)) {
        heading = heading.join('');
      }
      
      const numberMatch = heading && heading.toString().match(/^(\d+\.)\s*(.*)/);
      if (numberMatch) {
        // Use a more sophisticated display for numbered headings
        return (
          <Box sx={{ display: 'flex', alignItems: 'flex-start', mt: 3.5, mb: 2 }}>
            <Box sx={{ 
              borderRadius: '3px',
              color: theme.palette.primary.main,
              fontWeight: 700,
              fontSize: '1.15rem',
              letterSpacing: '-0.02em',
              mr: 1,
            }}>
              {numberMatch[1]}
            </Box>
            <Typography
              variant="h5"
              sx={{ 
                fontWeight: 700, 
                fontSize: '1.15rem',
                letterSpacing: '-0.02em',
                color: '#f8fafc'
              }}
            >
              {numberMatch[2]}
            </Typography>
          </Box>
        );
      }
      
      // Regular h2 for non-numbered headings
      return (
        <Typography
          variant="h5"
          gutterBottom
          {...props}
          sx={{ 
            fontWeight: 700, 
            mt: 3.5, 
            mb: 2,
            fontSize: '1.15rem',
            letterSpacing: '-0.02em'
          }}
        />
      );
    },
    h3: ({node, ...props}) => {
      // Check for sub-numbering like "2a) Something"
      let heading = props.children;
      if (heading && typeof heading === 'string') {
        heading = heading;
      } else if (Array.isArray(heading)) {
        heading = heading.join('');
      }
      
      const subNumberMatch = heading && heading.toString().match(/^(\d+[a-z]\))\s*(.*)/);
      if (subNumberMatch) {
        return (
          <Box sx={{ display: 'flex', alignItems: 'center', mt: 2.5, mb: 1.5 }}>
            <Typography
              variant="subtitle1"
              component="span"
              sx={{ 
                fontWeight: 600, 
                color: theme.palette.primary.main,
                fontSize: '0.95rem',
                mr: 1
              }}
            >
              {subNumberMatch[1]}
            </Typography>
            <Typography
              variant="subtitle1"
              component="span"
              sx={{ 
                fontWeight: 600, 
                fontSize: '0.95rem',
              }}
            >
              {subNumberMatch[2]}
            </Typography>
          </Box>
        );
      }
      
      // Regular h3
      return (
        <Typography
          variant="h6"
          gutterBottom
          {...props}
          sx={{ 
            fontWeight: 600, 
            mt: 2.5, 
            mb: 1.5,
            fontSize: '0.95rem'
          }}
        />
      );
    },
    p: ({node, ...props}) => (
      <Typography 
        variant="body2" 
        paragraph 
        {...props} 
        sx={{ 
          mb: 1.5, 
          lineHeight: 1.7,
          color: alpha('#fff', 0.85),
          fontSize: '0.875rem'
        }} 
      />
    ),
    ul: ({node, ...props}) => (
      <Box component="ul" sx={{ pl: 0, mb: 2, listStyleType: 'none' }} {...props} />
    ),
    ol: ({node, ...props}) => (
      <Box component="ol" sx={{ pl: 0, mb: 2, listStyleType: 'none' }} {...props} />
    ),
    li: ({node, ...props}) => {
      // Extract the children content
      let content = props.children;
      
      // Check if this is a bullet point
      if (content && content.toString().startsWith('• ')) {
        return (
          <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 1 }}>
            <Typography variant="body2" component="span" sx={{ mr: 1, color: theme.palette.primary.main }}>
              •
            </Typography>
            <Typography variant="body2" component="span" sx={{ fontSize: '0.875rem', color: alpha('#fff', 0.85) }}>
              {content.toString().replace('• ', '')}
            </Typography>
          </Box>
        );
      }
      
      // Check if this is a dash
      if (content && content.toString().startsWith('- ')) {
        return (
          <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 1, ml: 1.5 }}>
            <ArrowRightIcon sx={{ fontSize: 16, mr: 0.5, mt: 0.3, color: theme.palette.primary.main }} />
            <Typography variant="body2" component="span" sx={{ fontSize: '0.875rem', color: alpha('#fff', 0.85) }}>
              {content.toString().replace('- ', '')}
            </Typography>
          </Box>
        );
      }
      
      // Default li rendering
      return (
        <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 1 }}>
          <ArrowRightIcon sx={{ fontSize: 16, mr: 0.5, mt: 0.3, color: theme.palette.primary.main }} />
          <Typography 
            component="span" 
            variant="body2" 
            sx={{ fontSize: '0.875rem', color: alpha('#fff', 0.85) }}
            {...props} 
          />
        </Box>
      );
    },
    blockquote: ({node, ...props}) => (
      <Box sx={{ 
        borderLeft: `3px solid ${theme.palette.primary.main}`,
        pl: 2,
        py: 0.5,
        my: 2,
        bgcolor: alpha(theme.palette.primary.main, 0.05)
      }} {...props} />
    ),
    code({node, inline, className, children, ...props}) {
      const match = /language-(\w+)/.exec(className || '');
      return !inline && match ? (
        <Box sx={{ mb: 2 }}>
          <SyntaxHighlighter
            style={vscDarkPlus}
            language={match[1]}
            PreTag="div"
            {...props}
          >
            {String(children).replace(/\n$/, '')}
          </SyntaxHighlighter>
        </Box>
      ) : (
        <code 
          className={className} 
          style={{
            backgroundColor: alpha('#000', 0.3),
            padding: '0.2em 0.4em',
            borderRadius: '0.2em',
            fontSize: '85%',
            fontFamily: 'monospace'
          }} 
          {...props}
        >
          {children}
        </code>
      );
    },
    table: ({node, ...props}) => (
      <Box sx={{ overflow: 'auto', mb: 2 }}>
        <table 
          style={{ 
            borderCollapse: 'collapse', 
            width: '100%',
            border: `1px solid ${theme.palette.divider}`,
            fontSize: '0.8rem'
          }}
          {...props} 
        />
      </Box>
    ),
    th: ({node, ...props}) => (
      <th 
        style={{ 
          borderBottom: `2px solid ${theme.palette.divider}`,
          padding: '8px 16px',
          backgroundColor: alpha('#000', 0.3),
          textAlign: 'left',
          fontWeight: 600,
          fontSize: '0.75rem',
          textTransform: 'uppercase',
          letterSpacing: '0.03em'
        }}
        {...props} 
      />
    ),
    td: ({node, ...props}) => (
      <td 
        style={{ 
          borderBottom: `1px solid ${theme.palette.divider}`,
          padding: '8px 16px',
          fontSize: '0.8rem'
        }}
        {...props} 
      />
    ),
    // Add special handling for text to highlight citations
    text: ({children}) => {
      if (typeof children !== 'string') return <>{children}</>;
      
      // Regular expression to find citation patterns like [1] or [3, 6]
      const citationRegex = /\[(\d+(?:,\s*\d+)*)\]/g;
      const parts = [];
      
      let lastIndex = 0;
      let match;
      
      // Find all citation patterns
      while ((match = citationRegex.exec(children)) !== null) {
        // Add text before the citation
        if (match.index > lastIndex) {
          parts.push(
            <React.Fragment key={`text-${lastIndex}`}>
              {children.substring(lastIndex, match.index)}
            </React.Fragment>
          );
        }
        
        // Add highlighted citation
        parts.push(
          <Box
            key={`citation-${match.index}`}
            component="span"
            sx={{
              color: theme.palette.primary.main,
              backgroundColor: alpha(theme.palette.primary.main, 0.1),
              padding: '0.1em 0.3em',
              borderRadius: '0.2em',
              fontWeight: 600,
              fontSize: '0.9em'
            }}
            title="Citation reference"
          >
            {match[0]}
          </Box>
        );
        
        // Update last processed index
        lastIndex = match.index + match[0].length;
      }
      
      // Add remaining text after last citation
      if (lastIndex < children.length) {
        parts.push(
          <React.Fragment key={`text-${lastIndex}`}>
            {children.substring(lastIndex)}
          </React.Fragment>
        );
      }
      
      return parts.length > 0 ? <>{parts}</> : <>{children}</>;
    }
  };
  
  return (
    <Box sx={{ px: 0 }}>
      {/* Claude's reasoning panel if available */}
      {hasReasoning && response.reasoning && (
        <Box sx={{ mb: 3, mx: 2.5 }}>
          <Paper
            elevation={0}
            sx={{
              p: 2,
              borderRadius: 2,
              bgcolor: alpha(theme.palette.primary.main, 0.05),
              border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <PsychologyIcon sx={{ color: theme.palette.primary.main, mr: 1 }} />
                <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                  Claude's Reasoning Process Available
                </Typography>
              </Box>
              <Button
                size="small"
                variant="outlined"
                onClick={() => setShowReasoning(!showReasoning)}
                startIcon={showReasoning ? <ExpandMoreIcon /> : <ChevronRightIcon />}
                sx={{ borderRadius: 2 }}
              >
                {showReasoning ? 'Hide Reasoning' : 'Show Reasoning'}
              </Button>
            </Box>
            
            <Collapse in={showReasoning}>
              <Box sx={{ 
                mt: 2, 
                p: 2, 
                bgcolor: alpha(theme.palette.background.paper, 0.2),
                borderRadius: 1,
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`
              }}>
                <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600, display: 'flex', alignItems: 'center' }}>
                  <AutoAwesomeIcon sx={{ mr: 1, fontSize: 16, color: theme.palette.warning.main }} />
                  Step-by-Step Thinking
                </Typography>
                
                <Box sx={{ 
                  whiteSpace: 'pre-wrap', 
                  fontFamily: 'monospace', 
                  fontSize: '0.8rem',
                  color: alpha('#fff', 0.8),
                  p: 1,
                  maxHeight: '400px',
                  overflowY: 'auto',
                  bgcolor: alpha('#000', 0.2),
                  borderRadius: 1
                }}>
                  {response.reasoning}
                </Box>
              </Box>
            </Collapse>
          </Paper>
        </Box>
      )}

      {/* Key Financial Metrics Panel */}
      {showMetricsPanel && (
        <Box sx={{ mb: 3, mx: 2.5 }}>
          <Grid container spacing={2}>
            {metrics.roi && (
              <Grid item xs={6} md={3}>
                <Card sx={{ 
                  borderRadius: 2, 
                  bgcolor: alpha(theme.palette.primary.main, 0.05),
                  border: `1px solid ${alpha(theme.palette.primary.main, 0.1)}`,
                  height: '100%'
                }}>
                  <CardContent sx={{ p: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <Avatar sx={{ 
                        width: 28, 
                        height: 28, 
                        bgcolor: alpha(theme.palette.primary.main, 0.1),
                        mr: 1
                      }}>
                        <PieChartIcon sx={{ color: theme.palette.primary.main, fontSize: 16 }} />
                      </Avatar>
                      <Typography variant="caption" color="text.secondary" fontSize="0.7rem" fontWeight={500}>ROI</Typography>
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 700, mb: 0, fontSize: '1.3rem' }}>
                      {metrics.roi}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            )}
            
            {metrics.irr && (
              <Grid item xs={6} md={3}>
                <Card sx={{ 
                  borderRadius: 2, 
                  bgcolor: alpha(theme.palette.secondary.main, 0.05),
                  border: `1px solid ${alpha(theme.palette.secondary.main, 0.1)}`,
                  height: '100%'
                }}>
                  <CardContent sx={{ p: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <Avatar sx={{ 
                        width: 28, 
                        height: 28, 
                        bgcolor: alpha(theme.palette.secondary.main, 0.1),
                        mr: 1
                      }}>
                        <ShowChartIcon sx={{ color: theme.palette.secondary.main, fontSize: 16 }} />
                      </Avatar>
                      <Typography variant="caption" color="text.secondary" fontSize="0.7rem" fontWeight={500}>IRR</Typography>
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 700, mb: 0, fontSize: '1.3rem' }}>
                      {metrics.irr}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            )}
            
            {metrics.payback && (
              <Grid item xs={6} md={3}>
                <Card sx={{ 
                  borderRadius: 2, 
                  bgcolor: alpha(theme.palette.warning.main, 0.05),
                  border: `1px solid ${alpha(theme.palette.warning.main, 0.1)}`,
                  height: '100%'
                }}>
                  <CardContent sx={{ p: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <Avatar sx={{ 
                        width: 28, 
                        height: 28, 
                        bgcolor: alpha(theme.palette.warning.main, 0.1),
                        mr: 1
                      }}>
                        <EqualizerIcon sx={{ color: theme.palette.warning.main, fontSize: 16 }} />
                      </Avatar>
                      <Typography variant="caption" color="text.secondary" fontSize="0.7rem" fontWeight={500}>Payback</Typography>
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 700, mb: 0, fontSize: '1.3rem' }}>
                      {metrics.payback}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            )}
            
            {metrics.revenue && (
              <Grid item xs={6} md={3}>
                <Card sx={{ 
                  borderRadius: 2, 
                  bgcolor: alpha(theme.palette.success.main, 0.05),
                  border: `1px solid ${alpha(theme.palette.success.main, 0.1)}`,
                  height: '100%'
                }}>
                  <CardContent sx={{ p: 1.5 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                      <Avatar sx={{ 
                        width: 28, 
                        height: 28, 
                        bgcolor: alpha(theme.palette.success.main, 0.1),
                        mr: 1
                      }}>
                        <AttachMoneyIcon sx={{ color: theme.palette.success.main, fontSize: 16 }} />
                      </Avatar>
                      <Typography variant="caption" color="text.secondary" fontSize="0.7rem" fontWeight={500}>Revenue</Typography>
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 700, mb: 0, fontSize: '1.3rem' }}>
                      {metrics.revenue}
                    </Typography>
                  </CardContent>
                </Card>
              </Grid>
            )}
          </Grid>
        </Box>
      )}
      
      {/* Original response text */}
      <Box sx={{ px: 2.5, mb: 3 }}>
        <ReactMarkdown 
          remarkPlugins={[remarkGfm]}
          rehypePlugins={[rehypeRaw, rehypeHighlight]}
          components={components}
        >
          {processedText}
        </ReactMarkdown>
      </Box>
    </Box>
  );
};

const AIAssistantPage = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const isSmallScreen = useMediaQuery(theme.breakpoints.down('md'));
  
  // Get Redux state
  const { isLoading, responses, error, progressStatus } = useSelector((state) => state.ai);
  const { selectedDocuments } = useSelector((state) => state.documents);
  
  // Local state
  const [promptInput, setPromptInput] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [groundingEnabled, setGroundingEnabled] = useState(false);
  const [selectedModel, setSelectedModel] = useState('primary'); // primary, ultra_context, etc.
  const [modelMenuAnchorEl, setModelMenuAnchorEl] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
  const [showDealContext, setShowDealContext] = useState(true);
  const [completionResult, setCompletionResult] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [formatAsMarkdown, setFormatAsMarkdown] = useState(true);
  const responseContainerRef = useRef(null);
  const [processLogs, setProcessLogs] = useState([]);
  
  // Document selector modal state
  const [docSelectorOpen, setDocSelectorOpen] = useState(false);
  
  // Track already added document IDs for deduplication
  const documentIdsMap = useRef(new Set());
  
  // Reset confirmation dialog
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  
  // Handle document selection from selector
  const handleSelectDocuments = (docs) => {
    // Add each selected document
    docs.forEach(doc => {
      const docId = doc.id || doc.document_id;
      if (!documentIdsMap.current.has(docId)) {
        documentIdsMap.current.add(docId);
        dispatch(addSelectedDocument(doc));
      }
    });
  };
  
  // Add log entry with timestamps and type
  const addProcessLog = (type, message) => {
    setProcessLogs(prev => [
      ...prev, 
      {
        type,
        message,
        timestamp: new Date().toLocaleTimeString()
      }
    ]);
  };
  
  // Watch grounding toggle changes to update the model selection
  useEffect(() => {
    if (groundingEnabled) {
      // When grounding is enabled, force the model to be grounding_model
      setSelectedModel('grounding_model');
    } else if (selectedModel === 'grounding_model') {
      // If disabling grounding and current model is grounding_model, switch to primary
      setSelectedModel('primary');
    }
  }, [groundingEnabled]);

  // Enhanced polling logic for long-running processes
  useEffect(() => {
    let intervalId;
    let pollCount = 0;
    
    if (progressStatus.processId && !progressStatus.isComplete) {
      // Set up adaptive polling for status updates
      const poll = () => {
        pollCount++;
        
        // Add logs for very long-running processes to inform user
        if (pollCount === 60) { // After ~2 minutes
          addProcessLog('info', 'This is taking longer than usual. Large documents or complex analysis may take several minutes.');
        } else if (pollCount === 150) { // After ~5 minutes
          addProcessLog('info', 'Still processing. SOTA AI models can take 10+ minutes for thorough analysis of large documents.');
        } else if (pollCount % 90 === 0 && pollCount > 150) { // Every 3 minutes after that
          addProcessLog('info', `Processing continues. ${Math.floor(pollCount/30)} minutes elapsed.`);
        }
        
        // Update thinking phases for SOTA experience
        if (pollCount === 30) { // After ~1 minute
          addProcessLog('model', 'Planning response structure for comprehensive analysis');
        } else if (pollCount === 90) { // After ~3 minutes
          addProcessLog('model', 'Drafting detailed analysis with supporting evidence');
        } else if (pollCount === 180) { // After ~6 minutes
          addProcessLog('model', 'Refining analysis and formulating conclusions');
        }
        
        // Calculate adaptive polling interval - slower polling for longer processes
        let interval = 2000; // Start with 2 second intervals
        if (pollCount > 60) {
          interval = 3000; // After 2 minutes, poll every 3 seconds
        }
        if (pollCount > 150) {
          interval = 5000; // After 5 minutes, poll every 5 seconds
        }
        if (pollCount > 300) {
          interval = 10000; // After 10 minutes, poll every 10 seconds
        }
        
        // Dispatch the polling action
        dispatch(getCompletionStatus(progressStatus.processId));
        
        // Also update the elapsed time counter for a smoother experience
        dispatch(updateElapsedTime());
        
        // Schedule next poll
        intervalId = setTimeout(poll, interval);
      };
      
      // Start polling
      poll();
    }
    
    return () => {
      if (intervalId) clearTimeout(intervalId);
    };
  }, [progressStatus.processId, progressStatus.isComplete, dispatch]);
  
  // Update logs based on progress status
  useEffect(() => {
    if (progressStatus.currentStep && isProcessing) {
      // Determine log type based on step content
      let logType = 'info';
      const step = progressStatus.currentStep.toLowerCase();
      
      if (step.includes('model') || step.includes('token')) logType = 'model';
      if (step.includes('prompt') || step.includes('generating')) logType = 'prompt';
      if (step.includes('extract')) logType = 'extract';
      if (step.includes('ground')) logType = 'ground';
      if (step.includes('analyz') || step.includes('process')) logType = 'analyze';
      if (step.includes('error') || step.includes('fail')) logType = 'error';
      if (step.includes('complet') && progressStatus.isComplete) logType = 'success';
      
      // Add log entry if it's a new step (avoid duplicates)
      const lastLog = processLogs[processLogs.length - 1];
      if (!lastLog || lastLog.message !== progressStatus.currentStep) {
        addProcessLog(logType, progressStatus.currentStep);
      }
    }
  }, [progressStatus, isProcessing, processLogs]);
  
  // Handle document passed from Document Library - FIXED TO PREVENT DUPLICATES
  useEffect(() => {
    if (location.state?.document) {
      const document = location.state.document;
      // Get the document ID consistently
      const docId = document.id || document.document_id;
      
      // Only add if it's not already in our Set of document IDs
      if (docId && !documentIdsMap.current.has(docId)) {
        // Add to our Set of document IDs
        documentIdsMap.current.add(docId);
        
        // Add the document to Redux store
        dispatch(addSelectedDocument(document));
        
        // Set a prompt based on document type if available
        if (document.metadata?.extracted_metadata?.document_type) {
          const docType = document.metadata.extracted_metadata.document_type;
          setPromptInput(`Analyze this ${docType} and provide a comprehensive assessment for deal evaluation.`);
        }
      }
      
      // Clear location state to avoid duplicate handling on navigation
      window.history.replaceState({}, document.title);
    }
  }, [location.state, dispatch]);
  
  // Update documentIdsMap when selectedDocuments changes
  useEffect(() => {
    // Clear the Set and rebuild it from the current selectedDocuments
    documentIdsMap.current.clear();
    selectedDocuments.forEach(doc => {
      const docId = doc.id || doc.document_id;
      if (docId) {
        documentIdsMap.current.add(docId);
      }
    });
  }, [selectedDocuments]);
  
  // Initialize models from latest responses
  useEffect(() => {
    if (responses && responses.length > 0) {
      setCompletionResult(responses[responses.length - 1]);
      
      // If processing is complete, add a final success log
      if (isProcessing && progressStatus.isComplete) {
        addProcessLog('success', 'Analysis complete');
        setIsProcessing(false);
      }
    }
  }, [responses, isProcessing, progressStatus.isComplete]);
  
  // Handle model menu
  const handleModelMenuOpen = (event) => {
    setModelMenuAnchorEl(event.currentTarget);
  };
  
  const handleModelMenuClose = () => {
    setModelMenuAnchorEl(null);
  };
  
  const handleModelSelect = (modelType) => {
    // If selecting a non-grounding model while grounding is enabled, disable grounding
    if (modelType !== 'grounding_model' && groundingEnabled) {
      setGroundingEnabled(false);
    }
    
    setSelectedModel(modelType);
    handleModelMenuClose();
  };
  
  // Function to be passed to Sidebar for handling template selection
  const handleTemplateSelect = (templateText) => {
    setPromptInput(templateText);
  };
  
  // Make this function available globally for the Sidebar to use
  useEffect(() => {
    window.handlePromptTemplateSelect = handleTemplateSelect;
    
    return () => {
      // Clean up when component unmounts
      delete window.handlePromptTemplateSelect;
    };
  }, []);
  
  // Function to process the template and load its content
  const loadTemplateContent = async (templateId) => {
    try {
      const response = await promptApi.getTemplate(templateId);
      if (response.data && response.data.status === 'success') {
        setSelectedTemplate(response.data.data);
        // Populate the prompt input with the template content
        setPromptInput(response.data.data.content);
      }
    } catch (error) {
      console.error("Error loading template:", error);
      setSnackbar({
        open: true,
        message: "Failed to load template: " + error.message,
        severity: "error"
      });
    }
  };
  
  // Reset function - clears everything for a new analysis
  const handleReset = () => {
    setPromptInput('');
    setSelectedTemplate(null);
    dispatch(clearResponses());
    dispatch(clearSelectedDocuments());
    setCompletionResult(null);
    setProcessLogs([]);
    documentIdsMap.current.clear();
    setIsProcessing(false);
    setResetConfirmOpen(false);
    
    setSnackbar({
      open: true,
      message: "Workspace reset for new analysis",
      severity: "success"
    });
  };

  // Updated handleRunPrompt function
  const handleRunPrompt = () => {
    if (!promptInput.trim() && selectedDocuments.length === 0) {
      setSnackbar({
        open: true,
        message: "Please enter a prompt or select a document to analyze",
        severity: "warning"
      });
      return;
    }
    
    // Start processing state
    setIsProcessing(true);
    
    // Clear previous responses and logs
    dispatch(clearResponses());
    setProcessLogs([]);
    
    // Initial log entry
    addProcessLog('info', 'Starting AI analysis');
    
    // Use grounding model if grounding is enabled
    const effectiveModel = groundingEnabled ? 'grounding_model' : selectedModel;
    
    // Enable reasoning for Claude models
    const useReasoning = effectiveModel === 'primary' && 
                        modelConfig.find(m => m.type === 'primary')?.actualModelName.includes('claude');
    
    // Log model selection
    const modelInfo = modelConfig.find(m => m.type === effectiveModel);
    addProcessLog('model', `Selected model: ${modelInfo?.actualModelName || modelInfo?.displayName}`);
    addProcessLog('model', `Context window: ${modelInfo?.contextWindow.toLocaleString()} tokens`);
    
    // Get model-specific max tokens
    const maxTokens = modelInfo?.maxOutputTokens || 4000; 
    addProcessLog('model', `Max output tokens: ${maxTokens.toLocaleString()}`);
    
    if (groundingEnabled) {
      addProcessLog('ground', 'Grounding enabled: Using real-time data sources');
    }
    
    if (useReasoning) {
      addProcessLog('model', 'Reasoning enabled: Claude will show step-by-step thinking');
    }
    
    // Log document context if present
    if (selectedDocuments.length > 0) {
      addProcessLog('info', `Using ${selectedDocuments.length} document(s) for context`);
      selectedDocuments.forEach(doc => {
        addProcessLog('extract', `Document: ${doc.filename}`);
      });
    }
    
    // If we have a selected template, use it
    if (selectedTemplate) {
      addProcessLog('prompt', `Using template: ${selectedTemplate.display_name}`);
      
      // Create variables for template - FIXED: properly defined
      const templateVariables = {};
      
      // Only add non-document variables if the template has required variables
      if (selectedTemplate.required_variables && selectedTemplate.required_variables.length > 0) {
        // Add user input as a generic variable if available
        if (promptInput.trim()) {
          templateVariables.user_input = promptInput;
        }
        
        // For any template variables that need specific values, add them here
        selectedTemplate.required_variables.forEach(varName => {
          // Skip document-related variables as they'll be handled by the backend
          if (!['deal_details', 'document_content', 'financial_statements'].includes(varName)) {
            templateVariables[varName] = promptInput || '';
          }
        });
      }
      
      dispatch(createCompletion({
        template_id: selectedTemplate.template_id,
        template_vars: templateVariables,
        model_type: effectiveModel,
        documents: selectedDocuments.map(doc => doc.document_id || doc.id),
        use_reasoning: useReasoning,
        max_tokens: maxTokens
      })).catch(err => {
        addProcessLog('error', `Error: ${err.message || 'Unknown error'}`);
        setIsProcessing(false);
      });
    } else {
      // Direct prompt approach
      addProcessLog('prompt', 'Processing custom prompt');
      addProcessLog('model', 'Generating response...');
      
      dispatch(createCompletion({
        prompt: promptInput,
        model_type: effectiveModel,
        documents: selectedDocuments.map(doc => doc.document_id || doc.id),
        use_reasoning: useReasoning,
        max_tokens: maxTokens
      })).catch(err => {
        addProcessLog('error', `Error: ${err.message || 'Unknown error'}`);
        setIsProcessing(false);
      });
    }
  };
  
  // Handle document removal - FIXED
  const handleRemoveDocument = (documentId) => {
    if (documentId) {
      // Remove from our Set of document IDs
      documentIdsMap.current.delete(documentId);
      
      // Dispatch removal action
      dispatch(removeSelectedDocument(documentId));
    }
  };
  
  // Handle copy completion
  const handleCopyCompletion = () => {
    if (completionResult?.text) {
      navigator.clipboard.writeText(completionResult.text);
      setSnackbar({
        open: true,
        message: "Copied to clipboard",
        severity: "success"
      });
    }
  };
  
  // Handle clear completion
  const handleClearCompletion = () => {
    dispatch(clearResponses());
    setCompletionResult(null);
    setProcessLogs([]);
  };
  
  // Get the model display name
  const getModelDisplayName = (modelType) => {
    const modelInfo = modelConfig.find(m => m.type === modelType);
    return modelInfo ? modelInfo.displayName : modelType;
  };
  
  // Get model menu items
  const renderModelMenuItems = () => {
    return modelConfig.map(model => (
      <MenuItem 
        key={model.type} 
        value={model.type}
        onClick={() => handleModelSelect(model.type)}
        selected={selectedModel === model.type}
        disabled={groundingEnabled && model.type !== 'grounding_model'}
        sx={{ 
          display: 'flex', 
          alignItems: 'flex-start',
          gap: 1.5,
          px: 2,
          py: 1.5,
          borderRadius: 1,
          opacity: (groundingEnabled && model.type !== 'grounding_model') ? 0.5 : 1
        }}
      >
        <Box sx={{ 
          width: 36, 
          height: 36, 
          borderRadius: '50%', 
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          bgcolor: model.type === selectedModel 
            ? `${model.color}30` 
            : alpha(theme.palette.background.paper, 0.2),
          color: model.color,
          flexShrink: 0,
          mt: 0.5
        }}>
          {model.icon}
        </Box>
        <Box>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>
              {model.displayName}
            </Typography>
            {model.recommended && (
              <Chip 
                label="Recommended" 
                size="small" 
                sx={{ 
                  ml: 1,
                  height: 18,
                  fontSize: '0.6rem',
                  backgroundColor: model.color + '20',
                  color: model.color,
                  fontWeight: 600
                }}
              />
            )}
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
            {model.actualModelName || model.displayName}
          </Typography>
          <Box sx={{ display: 'flex', mt: 0.5, alignItems: 'center', gap: 2 }}>
            <Typography variant="caption" sx={{ color: 'text.secondary', fontSize: '0.65rem' }}>
              Context: {(model.contextWindow/1000).toFixed(0)}K
            </Typography>
            <Typography variant="caption" sx={{ color: 'text.secondary', fontSize: '0.65rem' }}>
              Output: {(model.maxOutputTokens/1000).toFixed(0)}K
            </Typography>
            <Typography variant="caption" sx={{ color: 'text.secondary', fontSize: '0.65rem' }}>
              {model.provider}
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 0.5, mt: 0.5, flexWrap: 'wrap' }}>
            {model.features && model.features.map((feature, index) => (
              <Chip
                key={index}
                label={feature}
                size="small"
                sx={{ 
                  height: 18, 
                  fontSize: '0.6rem',
                  bgcolor: alpha(theme.palette.background.paper, 0.2),
                  '& .MuiChip-label': { px: 0.8 }
                }}
              />
            ))}
          </Box>
        </Box>
        {model.type === selectedModel && (
          <DoneIcon sx={{ ml: 'auto', color: model.color }} />
        )}
      </MenuItem>
    ));
  };
  
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Header with Title */}
      <Box sx={{ 
        mb: 3, 
        borderRadius: '0 0 24px 24px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <Box sx={{ 
          p: 3, 
          background: `linear-gradient(135deg, ${alpha('#3A72F8', 0.15)} 0%, ${alpha('#2DD4BF', 0.15)} 100%)`,
          borderRadius: '0 0 24px 24px',
          border: `1px solid ${alpha('#ffffff', 0.1)}`,
          backdropFilter: 'blur(5px)'
        }}>
          <Container maxWidth="xl" sx={{ px: { xs: 0, sm: 2 } }}>
            <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, justifyContent: 'space-between', alignItems: { xs: 'flex-start', md: 'center' }, gap: 2 }}>
              <Box>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <GrainIcon sx={{ mr: 1.5, color: theme.palette.primary.main, fontSize: 32 }} />
                  <Typography variant="h4" sx={{ fontWeight: 600 }}>
                    Deal Evaluation Workbench
                  </Typography>
                </Box>
                {selectedTemplate && (
                  <Typography variant="body2" color="text.secondary">
                    Template: <Box component="span" sx={{ color: theme.palette.primary.main, fontWeight: 500 }}>{selectedTemplate.display_name}</Box>
                  </Typography>
                )}
              </Box>
              
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
                {/* Reset Button */}
                <Tooltip title="New Analysis">
                  <Button
                    variant="outlined"
                    size="small"
                    startIcon={<RestartAltIcon />}
                    onClick={() => setResetConfirmOpen(true)}
                    sx={{
                      borderRadius: 2,
                      textTransform: 'none',
                      borderColor: alpha(theme.palette.divider, 0.3),
                      color: theme.palette.text.primary
                    }}
                  >
                    Reset
                  </Button>
                </Tooltip>
                
                {/* Model Selection Menu */}
                <Button
                  variant="outlined"
                  size="small"
                  onClick={handleModelMenuOpen}
                  endIcon={<KeyboardArrowDownIcon />}
                  startIcon={
                    <AutoAwesomeIcon 
                      sx={{ 
                        color: modelConfig.find(m => m.type === selectedModel)?.color || theme.palette.primary.main 
                      }} 
                    />
                  }
                  sx={{ 
                    borderRadius: 2,
                    px: 2,
                    py: 0.75,
                    textTransform: 'none',
                    borderColor: alpha(theme.palette.divider, 0.3),
                    color: theme.palette.text.primary
                  }}
                >
                  {modelConfig.find(m => m.type === selectedModel)?.displayName || getModelDisplayName(selectedModel)}
                </Button>
                
                <Menu
                  anchorEl={modelMenuAnchorEl}
                  open={Boolean(modelMenuAnchorEl)}
                  onClose={handleModelMenuClose}
                  sx={{ 
                    '& .MuiPaper-root': { 
                      width: 280, 
                      borderRadius: 3,
                      p: 1,
                      mt: 1,
                      bgcolor: alpha(theme.palette.background.paper, 0.95),
                      backdropFilter: 'blur(8px)',
                      boxShadow: '0 8px 32px rgba(0,0,0,0.2)',
                      border: `1px solid ${alpha(theme.palette.divider, 0.1)}`
                    }
                  }}
                  anchorOrigin={{
                    vertical: 'bottom',
                    horizontal: 'right',
                  }}
                  transformOrigin={{
                    vertical: 'top',
                    horizontal: 'right',
                  }}
                >
                  {renderModelMenuItems()}
                </Menu>
                
                {/* Grounding Toggle */}
                <FormControlLabel
                  control={
                    <Switch 
                      checked={groundingEnabled}
                      onChange={(e) => setGroundingEnabled(e.target.checked)}
                      size="small"
                      color="primary"
                    />
                  }
                  label={
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <PublicIcon fontSize="small" sx={{ mr: 0.5, color: groundingEnabled ? theme.palette.primary.main : 'inherit' }} />
                      <Typography variant="body2">Grounding</Typography>
                    </Box>
                  }
                  sx={{ 
                    mx: 0.5, 
                    '& .MuiTypography-root': {
                      fontSize: '0.815rem',
                      color: groundingEnabled ? theme.palette.primary.main : 'inherit'
                    },
                    '& .MuiSwitch-root': {
                      mr: 0.5
                    }
                  }}
                />
                
                <Button
                  variant="contained"
                  endIcon={isProcessing ? <CircularProgress size={16} color="inherit" /> : <PlayArrowIcon />}
                  disabled={isProcessing}
                  onClick={handleRunPrompt}
                  sx={{ 
                    borderRadius: 2,
                    px: 3,
                    py: 1,
                    background: 'linear-gradient(45deg, #3A72F8 30%, #2DD4BF 90%)',
                    '&:hover': {
                      background: 'linear-gradient(45deg, #2851D8 30%, #00A99D 90%)',
                    }
                  }}
                >
                  {isProcessing ? 'Processing...' : 'Run Analysis'}
                </Button>
                
                <IconButton 
                  size="small" 
                  sx={{ color: alpha(theme.palette.text.primary, 0.7) }}
                  onClick={() => setShowSettings(!showSettings)}
                >
                  <SettingsIcon fontSize="small" />
                </IconButton>
              </Box>
            </Box>
          </Container>
        </Box>
      </Box>
      
      {/* Settings Panel - conditionally rendered */}
      <Collapse in={showSettings}>
        <Container maxWidth="xl" sx={{ px: { xs: 2, sm: 4 }, mb: 3 }}>
          <Paper 
            sx={{ 
              p: 2, 
              borderRadius: 3,
              background: alpha(theme.palette.background.paper, 0.2),
              backdropFilter: 'blur(10px)',
              border: `1px solid ${alpha(theme.palette.divider, 0.2)}`
            }}
          >
            <Grid container spacing={2} alignItems="center">
              <Grid item>
                <FormControlLabel
                  control={
                    <Switch 
                      checked={formatAsMarkdown}
                      onChange={(e) => setFormatAsMarkdown(e.target.checked)}
                      size="small"
                    />
                  }
                  label="Format as Markdown"
                />
              </Grid>
              <Grid item>
                <FormControlLabel
                  control={
                    <Switch 
                      checked={showDealContext}
                      onChange={(e) => setShowDealContext(e.target.checked)}
                      size="small"
                    />
                  }
                  label="Show Deal Context"
                />
              </Grid>
            </Grid>
          </Paper>
        </Container>
      </Collapse>
      
      {/* Progress Bar - shown when processing */}
      {isProcessing && (
        <Container maxWidth="xl" sx={{ px: { xs: 2, sm: 4 }, mb: 3 }}>
          <CompletionProgress 
            percentage={progressStatus.percentage} 
            currentStep={progressStatus.currentStep}
            isComplete={progressStatus.isComplete}
            error={error}
            expanded={true}
            isThinking={progressStatus.thinkingPhase !== null}
            thinkingPhase={progressStatus.thinkingPhase}
          />
        </Container>
      )}
      
      {/* Main Content Area */}
      <Container maxWidth="xl" sx={{ px: { xs: 2, sm: 4 }, mb: 4, flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
        <Paper 
          elevation={0} 
          sx={{ 
            borderRadius: 3,
            background: alpha(theme.palette.background.paper, 0.2),
            backdropFilter: 'blur(10px)',
            border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
            overflow: 'hidden',
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
            flexGrow: 1
          }}
        >
          {/* Split Layout for Prompt and Response */}
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'row', 
            flex: 1,
            height: 'calc(100vh - 300px)', // Adjust based on other elements
            position: 'relative',
            overflow: 'hidden'
          }}>
            {/* Left Side - Prompt Editor */}
            <Box sx={{ 
              width: '50%', 
              borderRight: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
              display: 'flex',
              flexDirection: 'column',
              height: '100%'
            }}>
              <Box sx={{ 
                p: 1.5, 
                borderBottom: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                bgcolor: alpha(theme.palette.background.paper, 0.1)
              }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Avatar 
                    sx={{ 
                      width: 24, 
                      height: 24, 
                      bgcolor: alpha(theme.palette.primary.main, 0.2),
                      mr: 1 
                    }}
                  >
                    <PersonIcon sx={{ fontSize: 16, color: theme.palette.primary.main }} />
                  </Avatar>
                  <Typography variant="caption" sx={{ fontWeight: 500 }}>
                    Analyst Prompt
                  </Typography>
                </Box>
                
                <Tooltip title="Browse prompt templates">
                  <IconButton 
                    size="small" 
                    onClick={() => navigate('/prompts')}
                    sx={{ color: alpha(theme.palette.text.primary, 0.7) }}
                  >
                    <LineStyleIcon fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Box>
              
              {/* Deal Context Section */}
              {showDealContext && (
                <Box sx={{ 
                  p: 2, 
                  borderBottom: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                  bgcolor: alpha(theme.palette.background.paper, 0.05)
                }}>
                  <Box sx={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    alignItems: 'center',
                    mb: 1 
                  }}>
                    <Typography variant="caption" sx={{ 
                      color: alpha(theme.palette.text.primary, 0.7),
                      fontWeight: 500
                    }}>
                      DEAL CONTEXT
                    </Typography>
                    
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button
                        size="small"
                        variant="text"
                        startIcon={<FolderOpenIcon sx={{ fontSize: 16 }} />}
                        onClick={() => setDocSelectorOpen(true)}
                        sx={{ 
                          fontSize: '0.75rem', 
                          textTransform: 'none',
                          color: alpha(theme.palette.text.primary, 0.7)
                        }}
                      >
                        Select Documents
                      </Button>
                      
                      {selectedDocuments.length >= 2 && (
                        <Button
                          size="small"
                          variant="text"
                          startIcon={<CompareArrowsIcon sx={{ fontSize: 16 }} />}
                          onClick={() => {
                            // Load the multi-deal comparison template
                            promptApi.getTemplate('deal_comparison')
                              .then(response => {
                                if (response.data && response.data.status === 'success') {
                                  const template = response.data.data;
                                  setSelectedTemplate(template);
                                  
                                  // Auto-populate the prompt with document names as placeholders
                                  let promptText = `Deal Comparison Template\n\nDeal 1: ${selectedDocuments[0]?.filename || 'First Deal'}\nDeal 2: ${selectedDocuments[1]?.filename || 'Second Deal'}`;
                                  
                                  if (selectedDocuments.length > 2) {
                                    promptText += `\nAdditional Deal: ${selectedDocuments[2]?.filename || 'Additional Deal'}`;
                                  }
                                  
                                  setPromptInput(promptText);
                                }
                              })
                              .catch(error => {
                                console.error("Error loading deal comparison template:", error);
                                setSnackbar({
                                  open: true,
                                  message: "Failed to load deal comparison template",
                                  severity: "error"
                                });
                              });
                          }}
                          sx={{ 
                            fontSize: '0.75rem', 
                            textTransform: 'none',
                            color: theme.palette.primary.main
                          }}
                        >
                          Compare Deals
                        </Button>
                      )}
                    </Box>
                  </Box>
                  
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                    {selectedDocuments.length > 0 ? (
                      selectedDocuments.map(doc => {
                        const docId = doc.id || doc.document_id;
                        
                        return (
                          <Chip
                            key={docId}
                            avatar={
                              <Avatar sx={{ 
                                bgcolor: alpha(theme.palette.warning.main, 0.2),
                                color: theme.palette.warning.main
                              }}>
                                <InsertDriveFileIcon sx={{ fontSize: 14 }} />
                              </Avatar>
                            }
                            label={doc.filename}
                            onDelete={() => handleRemoveDocument(docId)}
                            sx={{
                              bgcolor: alpha(theme.palette.warning.main, 0.05),
                              border: `1px solid ${alpha(theme.palette.warning.main, 0.1)}`,
                              borderRadius: 6,
                              '& .MuiChip-label': {
                                px: 1,
                                fontSize: '0.75rem'
                              },
                              '& .MuiChip-deleteIcon': {
                                color: alpha(theme.palette.warning.main, 0.8),
                                '&:hover': {
                                  color: theme.palette.warning.main
                                }
                              }
                            }}
                          />
                        );
                      })
                    ) : (
                      <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic', fontSize: '0.85rem' }}>
                        No documents selected. Add documents from the Document Library or click "Select Documents".
                      </Typography>
                    )}
                  </Box>
                </Box>
              )}
              
              <Box sx={{ 
                flex: 1, 
                overflowY: 'auto',
                backgroundColor: alpha(theme.palette.background.dark, 0.4),
                p: 2,
                position: 'relative'
              }}>
                <TextField
                  multiline
                  fullWidth
                  placeholder="Enter your deal evaluation prompt here or select a template from the prompt gallery..."
                  value={promptInput}
                  onChange={(e) => setPromptInput(e.target.value)}
                  variant="standard"
                  minRows={15}
                  maxRows={30}
                  sx={{
                    '& .MuiInputBase-root': {
                      fontFamily: 'monospace',
                      fontSize: '0.9rem',
                      color: theme.palette.text.primary,
                      lineHeight: 1.6,
                    },
                    '& .MuiInput-underline:before': {
                      borderBottom: 'none'
                    },
                    '& .MuiInput-underline:after': {
                      borderBottom: 'none'
                    },
                    '& .MuiInput-underline:hover:not(.Mui-disabled):before': {
                      borderBottom: 'none'
                    }
                  }}
                  InputProps={{
                    disableUnderline: true,
                  }}
                />
                
                {/* Professional information panel */}
                {!promptInput && selectedDocuments.length === 0 && (
                  <Paper
                    elevation={0}
                    sx={{ 
                      position: 'absolute',
                      bottom: 16,
                      left: 16,
                      right: 16,
                      p: 2,
                      borderRadius: 2,
                      border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                      bgcolor: alpha(theme.palette.background.paper, 0.2),
                      backdropFilter: 'blur(10px)'
                    }}
                  >
                    <Typography variant="subtitle2" sx={{ display: 'flex', alignItems: 'center', mb: 1.5 }}>
                      <InfoOutlinedIcon sx={{ mr: 1, fontSize: 18, color: theme.palette.info.main }} />
                      Instructions
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2, fontSize: '0.85rem' }}>
                      Enter a prompt for investment analysis or select documents from the library to provide context.
                      Use templates from the prompt gallery for structured evaluations.
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 1 }}>
                      <Button
                        size="small"
                        variant="outlined"
                        startIcon={<LineStyleIcon />}
                        onClick={() => navigate('/prompts')}
                        sx={{ 
                          textTransform: 'none',
                          borderRadius: 1.5,
                          px: 2,
                          py: 0.75,
                          fontSize: '0.8rem',
                          borderColor: alpha(theme.palette.divider, 0.3)
                        }}
                      >
                        Prompt Gallery
                      </Button>
                      <Button
                        size="small"
                        variant="outlined"
                        startIcon={<StorageIcon />}
                        onClick={() => navigate('/')}
                        sx={{ 
                          textTransform: 'none',
                          borderRadius: 1.5,
                          px: 2,
                          py: 0.75,
                          fontSize: '0.8rem',
                          borderColor: alpha(theme.palette.divider, 0.3)
                        }}
                      >
                        Add Documents
                      </Button>
                    </Box>
                  </Paper>
                )}
              </Box>
            </Box>
            
            {/* Right Side - Response Viewer */}
            <Box 
              sx={{ 
                width: '50%', 
                display: 'flex',
                flexDirection: 'column',
              }}
              ref={responseContainerRef}
            >
              <Box sx={{ 
                p: 1.5, 
                borderBottom: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                bgcolor: alpha(theme.palette.background.paper, 0.1)
              }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Avatar 
                    sx={{ 
                      width: 24, 
                      height: 24, 
                      background: 'linear-gradient(45deg, #3A72F8 30%, #2DD4BF 90%)',
                      mr: 1 
                    }}
                  >
                    <GrainIcon sx={{ fontSize: 16 }} />
                  </Avatar>
                  <Typography variant="caption" sx={{ fontWeight: 500 }}>
                    AIDE Response
                  </Typography>
                  {completionResult?.model && (
                    <Chip 
                      label={completionResult.model}
                      size="small"
                      sx={{ 
                        ml: 1, 
                        height: 18, 
                        fontSize: '0.65rem',
                        bgcolor: alpha(theme.palette.background.paper, 0.2),
                        '& .MuiChip-label': { px: 1 }
                      }}
                    />
                  )}
                  {completionResult?.grounding && (
                    <Chip 
                      icon={<PublicIcon sx={{ fontSize: '0.7rem !important' }} />}
                      label="Grounded"
                      size="small"
                      sx={{ 
                        ml: 1, 
                        height: 18, 
                        fontSize: '0.65rem',
                        bgcolor: alpha(theme.palette.primary.main, 0.2),
                        color: theme.palette.primary.main,
                        '& .MuiChip-label': { px: 1 },
                        '& .MuiChip-icon': { fontSize: '0.7rem', color: theme.palette.primary.main }
                      }}
                    />
                  )}
                  {completionResult?.reasoning && (
                    <Chip 
                      icon={<PsychologyIcon sx={{ fontSize: '0.7rem !important' }} />}
                      label="Reasoning"
                      size="small"
                      sx={{ 
                        ml: 1, 
                        height: 18, 
                        fontSize: '0.65rem',
                        bgcolor: alpha(theme.palette.primary.main, 0.2),
                        color: theme.palette.primary.main,
                        '& .MuiChip-label': { px: 1 },
                        '& .MuiChip-icon': { fontSize: '0.7rem', color: theme.palette.primary.main }
                      }}
                    />
                  )}
                </Box>
                
                <Box sx={{ display: 'flex' }}>
                  {completionResult && (
                    <>
                      <Tooltip title="Copy response">
                        <IconButton size="small" onClick={handleCopyCompletion}>
                          <ContentCopyIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Clear response">
                        <IconButton size="small" onClick={handleClearCompletion}>
                          <DeleteOutlineIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </>
                  )}
                  <Button 
                    size="small" 
                    variant="text" 
                    sx={{ 
                      color: formatAsMarkdown ? theme.palette.primary.main : alpha(theme.palette.text.primary, 0.5),
                      textTransform: 'none',
                      fontSize: '0.75rem',
                      minWidth: 'auto',
                      px: 1
                    }}
                    onClick={() => setFormatAsMarkdown(true)}
                  >
                    Preview
                  </Button>
                  <Button 
                    size="small" 
                    variant="text" 
                    sx={{ 
                      color: !formatAsMarkdown ? theme.palette.primary.main : alpha(theme.palette.text.primary, 0.5),
                      textTransform: 'none',
                      fontSize: '0.75rem',
                      minWidth: 'auto',
                      px: 1
                    }}
                    onClick={() => setFormatAsMarkdown(false)}
                  >
                    Text
                  </Button>
                </Box>
              </Box>
              
              <Box sx={{ 
                flex: 1, 
                overflowY: 'auto',
                p: 0,
                bgcolor: alpha(theme.palette.background.paper, 0.1),
                display: 'flex',
                flexDirection: 'column',
                '&::-webkit-scrollbar': {
                  width: '6px',
                },
                '&::-webkit-scrollbar-thumb': {
                  backgroundColor: alpha(theme.palette.divider, 0.3),
                  borderRadius: '3px',
                }
              }}>
                {error ? (
                  <Box sx={{ p: 3 }}>
                    <Alert 
                      severity="error" 
                      variant="outlined"
                      sx={{ 
                        borderColor: alpha(theme.palette.error.main, 0.5),
                        backgroundColor: alpha(theme.palette.error.main, 0.05)
                      }}
                    >
                      <Typography variant="body2">
                        {error}
                      </Typography>
                    </Alert>
                  </Box>
                ) : isProcessing ? (
                  // ENHANCED PROGRESS UI: Shows thinking process and progress logs together
                  <ProcessingLogs 
                    logs={processLogs} 
                    thinkingPhase={progressStatus.thinkingPhase}
                    elapsedTime={progressStatus.elapsedTime}
                  />
                ) : !completionResult ? (
                  // Empty state with simple instructions
                  <Box 
                    sx={{ 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center', 
                      flexDirection: 'column',
                      height: '100%',
                      p: 3
                    }}
                  >
                    <Box 
                      sx={{ 
                        width: 80, 
                        height: 80,
                        display: 'flex', 
                        alignItems: 'center', 
                        justifyContent: 'center',
                        borderRadius: '50%',
                        background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.1)} 0%, ${alpha(theme.palette.secondary.main, 0.1)} 100%)`,
                        mb: 3,
                        border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`
                      }}
                    >
                      <GrainIcon sx={{ fontSize: 36, color: theme.palette.primary.main }} />
                    </Box>
                    
                    <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
                      Ready for Analysis
                    </Typography>
                    
                    <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', maxWidth: 450, mb: 3 }}>
                      Results will appear here after you run your analysis.
                    </Typography>
                    
                    <Box sx={{ 
                      p: 2, 
                      borderRadius: 2, 
                      border: `1px dashed ${alpha(theme.palette.divider, 0.3)}`,
                      bgcolor: alpha(theme.palette.background.paper, 0.1),
                      display: 'flex',
                      alignItems: 'center',
                      maxWidth: 400
                    }}>
                      <LightbulbIcon sx={{ color: theme.palette.warning.main, mr: 1.5, fontSize: 20 }} />
                      <Typography variant="body2" color="text.secondary">
                        For best results, add documents from the library and enable grounding for real-time data.
                      </Typography>
                    </Box>
                  </Box>
                ) : (
                  <Box sx={{ 
                    overflowY: 'auto', 
                    height: '100%'
                  }}>
                    {/* ENHANCED PROFESSIONAL RESPONSE FORMAT */}
                    <EnhancedResponse response={completionResult} theme={theme} />
                    
                    {/* Document Source Attribution */}
                    <DocumentSourceAttribution selectedDocuments={selectedDocuments} />
                    
                    {/* Grounding Display - pass full response text to enable citation detection */}
                    {completionResult && completionResult.grounding && (
                      <GroundingDisplay 
                        groundingData={completionResult.grounding_metadata} 
                        responseText={completionResult.text}
                      />
                    )}
                    
                    {/* Professional metrics and feedback section */}
                    <Box sx={{ 
                      mt: 4, 
                      mb: 2,
                      mx: 2.5,
                      pt: 2, 
                      borderTop: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}>
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                        <Tooltip title="Copy to clipboard">
                          <IconButton 
                            size="small" 
                            onClick={handleCopyCompletion}
                            sx={{
                              border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
                              bgcolor: alpha(theme.palette.background.paper, 0.1)
                            }}
                          >
                            <FilterNoneIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        
                        <Chip
                          label={`Model: ${completionResult.model}`}
                          size="small"
                          sx={{ 
                            bgcolor: alpha(theme.palette.background.paper, 0.15),
                            border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                            fontSize: '0.7rem',
                            height: 24
                          }}
                        />
                        
                        {completionResult.tokens?.total && (
                          <Chip
                            icon={<DataObjectIcon sx={{ fontSize: '0.7rem !important' }} />}
                            label={`${completionResult.tokens.total.toLocaleString()} tokens`}
                            size="small"
                            sx={{ 
                              bgcolor: alpha(theme.palette.background.paper, 0.15),
                              border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                              fontSize: '0.7rem',
                              height: 24,
                              '& .MuiChip-icon': {
                                color: theme.palette.info.light
                              }
                            }}
                          />
                        )}
                      </Box>
                      
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <Tooltip title="Helpful">
                          <IconButton size="small" sx={{ 
                            color: theme.palette.success.main, 
                            border: `1px solid ${alpha(theme.palette.success.main, 0.2)}`,
                            '&:hover': { bgcolor: alpha(theme.palette.success.main, 0.1) },
                            width: 28,
                            height: 28
                          }}>
                            <ThumbUpIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Not helpful">
                          <IconButton size="small" sx={{ 
                            color: theme.palette.error.main,
                            border: `1px solid ${alpha(theme.palette.error.main, 0.2)}`,
                            '&:hover': { bgcolor: alpha(theme.palette.error.main, 0.1) },
                            width: 28,
                            height: 28
                          }}>
                            <ThumbDownIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </Box>
                  </Box>
                )}
              </Box>
            </Box>
          </Box>
        </Paper>
      </Container>
      
      {/* Document Selector Dialog */}
      <DocumentSelector
        open={docSelectorOpen}
        onClose={() => setDocSelectorOpen(false)}
        onSelectDocuments={handleSelectDocuments}
        initialSelectedIds={Array.from(documentIdsMap.current)}
      />
      
      {/* Reset Confirmation Dialog */}
      <Dialog
        open={resetConfirmOpen}
        onClose={() => setResetConfirmOpen(false)}
        maxWidth="xs"
        fullWidth
        PaperProps={{
          sx: { borderRadius: 3 }
        }}
      >
        <DialogTitle sx={{ pt: 3 }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Reset Workspace
          </Typography>
        </DialogTitle>
        <DialogContent>
          <Typography variant="body1">
            This will clear your prompt, documents, and any analysis results. Are you sure you want to start a new analysis?
          </Typography>
        </DialogContent>
        <DialogActions sx={{ pb: 3, px: 3 }}>
          <Button 
            onClick={() => setResetConfirmOpen(false)}
            variant="outlined"
            sx={{ borderRadius: 2 }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleReset}
            variant="contained"
            sx={{ 
              borderRadius: 2, 
              ml: 2,
              background: 'linear-gradient(45deg, #3A72F8 30%, #2DD4BF 90%)'
            }}
            startIcon={<AddIcon />}
          >
            New Analysis
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Snackbar for messages */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          variant="filled"
          sx={{ 
            borderRadius: 2,
            boxShadow: '0 8px 16px rgba(0,0,0,0.2)'
          }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AIAssistantPage;