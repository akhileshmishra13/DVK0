// src/App.js 

import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import CssBaseline from '@mui/material/CssBaseline';
import { ThemeProvider } from '@mui/material/styles';
import { useDispatch, useSelector } from 'react-redux';
import theme from './theme';
import { checkAuthState } from './store/authSlice';
import authService from './services/authService';

import MainLayout from './components/layout/MainLayout';
import DocumentLibraryPage from './components/document/DocumentLibraryPage';
import AIAssistantPage from './components/ai/AIAssistantPage';
import LoginPage from './components/auth/LoginPage';
import ProtectedRoute from './components/auth/ProtectedRoute';
import PromptLibraryPage from './components/prompts/PromptLibraryPage';

function AppContent() {
  const dispatch = useDispatch();
  const { isAuthenticated } = useSelector((state) => state.auth);

  useEffect(() => {
    // Check authentication state on app load
    dispatch(checkAuthState());
    
    // Set up activity monitoring
    const activityEvents = ['mousedown', 'keydown', 'mousemove', 'scroll', 'touchstart'];
    const updateActivity = () => {
      if (isAuthenticated) {
        authService.updateLastActivity();
      }
    };
    
    // Add event listeners
    activityEvents.forEach(event => {
      window.addEventListener(event, updateActivity);
    });
    
    // Check session periodically (every minute)
    const intervalId = setInterval(() => {
      if (isAuthenticated) {
        dispatch(checkAuthState());
      }
    }, 60000);
    
    // Clean up
    return () => {
      activityEvents.forEach(event => {
        window.removeEventListener(event, updateActivity);
      });
      clearInterval(intervalId);
    };
  }, [dispatch, isAuthenticated]);

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={<LoginPage />} />

      {/* Protected Routes */}
      <Route path="/" element={
        <ProtectedRoute>
          <MainLayout />
        </ProtectedRoute>
      }>
        {/* Make DocumentLibraryPage the default route */}
        <Route index element={<DocumentLibraryPage />} />
        <Route path="documents" element={<DocumentLibraryPage />} />
        <Route path="assistant" element={<AIAssistantPage />} />
        <Route path="prompts" element={<PromptLibraryPage />} />
      </Route>

      {/* Redirect any unknown paths to home */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <AppContent />
      </Router>
    </ThemeProvider>
  );
}

export default App;