// frontend/src/store/aiSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { completionApi } from '../services/apiService';
import modelConfig from '../config/modelConfig';

// Async thunks
export const createCompletion = createAsyncThunk(
  'ai/createCompletion',
  async (data, { rejectWithValue }) => {
    try {
      // Get model-specific token limits from modelConfig
      const modelType = data.model_type || 'primary';
      const selectedModel = modelConfig.find(m => m.type === modelType);
      
      // Use model-specific token values, NEVER HARDCODE THESE VALUES
      const requestData = {
        prompt: data.prompt,
        template_id: data.template_id,
        template_vars: data.template_vars,
        max_tokens: data.max_tokens || selectedModel?.maxOutputTokens || 4000,
        model_type: modelType,
        documents: data.documents || [],
        use_reasoning: data.use_reasoning || false
      };
      
      const response = await completionApi.createCompletion(requestData);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to create completion');
    }
  }
);

export const getCompletionStatus = createAsyncThunk(
  'ai/getCompletionStatus',
  async (processId, { rejectWithValue, getState }) => {
    try {
      // Access the current state to check for existing errors or processing status
      const aiState = getState().ai;
      
      // If there's already an error, don't keep polling
      if (aiState.error) {
        return null;
      }
      
      const response = await completionApi.getCompletion(processId);
      return response.data.data;
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || 'Failed to get completion status');
    }
  }
);

const initialState = {
  isLoading: false,
  responses: [],
  error: null,
  progressStatus: {
    processId: null,
    percentage: 0,
    currentStep: '',
    isComplete: false,
    startTime: null,
    thinkingPhase: null, // For tracking thinking phases (analyzing, planning, drafting, etc.)
    elapsedTime: 0
  }
};

const aiSlice = createSlice({
  name: 'ai',
  initialState,
  reducers: {
    setLoading: (state, action) => {
      state.isLoading = action.payload;
    },
    addResponse: (state, action) => {
      state.responses.push(action.payload);
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
    updateProgress: (state, action) => {
      state.progressStatus = {
        ...state.progressStatus,
        ...action.payload
      };
    },
    updateThinkingPhase: (state, action) => {
      state.progressStatus.thinkingPhase = action.payload;
    },
    updateElapsedTime: (state) => {
      if (state.progressStatus.startTime && !state.progressStatus.isComplete) {
        const now = new Date().getTime();
        state.progressStatus.elapsedTime = Math.floor((now - state.progressStatus.startTime) / 1000);
      }
    },
    clearResponses: (state) => {
      state.responses = [];
      state.error = null;
      state.progressStatus = {
        ...initialState.progressStatus,
        startTime: new Date().getTime() // Record start time when clearing for new request
      };
    }
  },
  extraReducers: (builder) => {
    builder
      // createCompletion
      .addCase(createCompletion.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createCompletion.fulfilled, (state, action) => {
        state.isLoading = false;
        state.progressStatus.processId = action.payload.process_id;
        state.progressStatus.percentage = 0;
        state.progressStatus.currentStep = 'Processing started';
        state.progressStatus.isComplete = false;
        state.progressStatus.startTime = new Date().getTime();
        state.progressStatus.elapsedTime = 0;
        
        // Initialize thinking phase for SOTA experience
        state.progressStatus.thinkingPhase = 'analyzing';
      })
      .addCase(createCompletion.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // getCompletionStatus
      .addCase(getCompletionStatus.fulfilled, (state, action) => {
        // Skip updating if this is a null response (due to existing errors)
        if (!action.payload) return;
        
        const process = action.payload;
        state.progressStatus.percentage = process.percentage || 0;
        state.progressStatus.currentStep = process.current_step || '';
        
        // SOTA Thinking phase simulation based on percentage
        if (process.percentage < 25) {
          state.progressStatus.thinkingPhase = 'analyzing';
        } else if (process.percentage < 50) {
          state.progressStatus.thinkingPhase = 'planning';
        } else if (process.percentage < 75) {
          state.progressStatus.thinkingPhase = 'drafting';
        } else if (process.percentage < 95) {
          state.progressStatus.thinkingPhase = 'refining';
        } else {
          state.progressStatus.thinkingPhase = 'finalizing';
        }
        
        // Calculate elapsed time
        if (state.progressStatus.startTime) {
          const now = new Date().getTime();
          state.progressStatus.elapsedTime = Math.floor((now - state.progressStatus.startTime) / 1000);
        }
        
        if (process.status === 'completed') {
          state.progressStatus.isComplete = true;
          state.progressStatus.thinkingPhase = null;
          
          // Add completion info to update UI
          if (process.metadata?.completion) {
            state.responses.push(process.metadata.completion);
            
            // Log completion time for performance tracking
            console.log(`Completion finished in ${state.progressStatus.elapsedTime} seconds`);
          }
        }
        
        if (process.status === 'failed') {
          state.error = process.current_step || 'Process failed';
          state.progressStatus.thinkingPhase = null;
        }
      })
      .addCase(getCompletionStatus.rejected, (state, action) => {
        state.error = action.payload;
      });
  }
});

export const { 
  setLoading, 
  addResponse, 
  setError, 
  updateProgress, 
  updateThinkingPhase,
  updateElapsedTime,
  clearResponses 
} = aiSlice.actions;

export default aiSlice.reducer;