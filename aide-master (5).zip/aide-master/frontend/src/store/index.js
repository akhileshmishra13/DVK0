// frontend/src/store/index.js

import { configureStore } from '@reduxjs/toolkit';
import aiReducer from './aiSlice';
import documentReducer from './documentSlice';
import authReducer from './authSlice';

export const store = configureStore({
  reducer: {
    ai: aiReducer,
    documents: documentReducer,
    auth: authReducer
  },
});
