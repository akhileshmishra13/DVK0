//frontend/src/config/modelConfig.js
import React from 'react';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import FlashOnIcon from '@mui/icons-material/FlashOn';
import TerminalIcon from '@mui/icons-material/Terminal';
import AssessmentIcon from '@mui/icons-material/Assessment';
import BarChartIcon from '@mui/icons-material/BarChart';
import PublicIcon from '@mui/icons-material/Public';
import PsychologyIcon from '@mui/icons-material/Psychology';

const modelConfig = [
  {
    type: 'primary',
    displayName: 'Claude 3.7 Sonnet',
    actualModelName: 'anthropic.claude-3-7-sonnet-20250219-v1:0',
    description: 'Advanced reasoning with step-by-step thinking',
    color: '#8B5CF6',
    icon: <PsychologyIcon />,
    context: 'Best for complex deal evaluation with extended reasoning',
    contextWindow: 200000,
    maxOutputTokens: 30000,
    features: ['Advanced reasoning', 'Step-by-step thinking', 'Financial analysis expertise'],
    provider: 'Anthropic (AWS Bedrock)',
    recommended: true
  },
  {
    type: 'advanced_reasoning',
    displayName: 'OpenAI o1',
    actualModelName: 'o1',
    description: 'Advanced reasoning and in-depth analysis',
    color: '#3A72F8',
    icon: <AutoAwesomeIcon />,
    context: 'Best for complex deal evaluation and strategic analysis',
    contextWindow: 200000,
    maxOutputTokens: 30000,
    features: ['Advanced reasoning', 'Deep financial analysis', 'Strategic insights'],
    provider: 'OpenAI'
  },
  {
    type: 'fallback',
    displayName: 'GPT-4o Mini',
    actualModelName: 'gpt-4o-mini',
    description: 'Balanced performance and efficiency',
    color: '#2DD4BF',
    icon: <FlashOnIcon />,
    context: 'Efficient analysis for straightforward deals',
    contextWindow: 128000,
    maxOutputTokens: 16384,
    features: ['Fast processing', 'Concise summaries', 'Efficient analysis'],
    provider: 'OpenAI'
  },
  {
    type: 'ultra_context',
    displayName: 'Gemini Ultra Context',
    actualModelName: 'gemini-2.0-flash-001',
    description: 'Massive document handling capacity',
    color: '#8B5CF6',
    icon: <AssessmentIcon />,
    context: 'Best for analyzing multiple large documents',
    contextWindow: 1000000,
    maxOutputTokens: 30000,
    features: ['Multi-document analysis', 'Large context handling', 'Comprehensive comparison'],
    provider: 'Google'
  },
  {
    type: 'text_extract',
    displayName: 'Gemini Fast Extract',
    actualModelName: 'gemini-2.0-flash-001',
    description: 'Optimized for document extraction',
    color: '#F59E0B',
    icon: <BarChartIcon />,
    context: 'Best for rapid document processing',
    contextWindow: 1000000,
    maxOutputTokens: 30000,
    features: ['Rapid extraction', 'Document structure analysis', 'Data table recognition'],
    provider: 'Google'
  },
  {
    type: 'grounding_model',
    displayName: 'Gemini Grounded',
    actualModelName: 'gemini-2.0-flash-001',
    description: 'Real-time data integration',
    color: '#10B981',
    icon: <PublicIcon />,
    context: 'Market-aware analysis with real-time data',
    contextWindow: 1000000,
    maxOutputTokens: 30000,
    features: ['Real-time market data', 'Source attributions', 'Factual verification'],
    provider: 'Google',
    grounding: true
  }
];

export default modelConfig;