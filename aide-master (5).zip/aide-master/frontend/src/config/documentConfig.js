// src/config/documentConfig.js
// Single source of truth for document-related constants
import { 
  Description, 
  InsertDriveFile, 
  Article 
} from '@mui/icons-material';
import React from 'react';

// Document type definitions with colors and icons
export const DOCUMENT_TYPES = {
  'Teaser Deck': {
    color: '#3B82F6', // blue
    icon: <Description fontSize="small" />,
    description: 'Initial investment opportunity overview'
  },
  'Deal Qualification Memo': {
    color: '#3A72F8', // primary blue
    icon: <InsertDriveFile fontSize="small" />,
    description: 'Initial qualification of investment opportunity'
  },
  'DQM': {
    color: '#3A72F8', // primary blue
    icon: <InsertDriveFile fontSize="small" />,
    description: 'Initial qualification of investment opportunity'
  },
  'Confidential Investment Memo': {
    color: '#F59E0B', // amber
    icon: <Description fontSize="small" />,
    description: 'Detailed investment opportunity information'
  },
  'CIM': {
    color: '#F59E0B', // amber
    icon: <Description fontSize="small" />,
    description: 'Detailed investment opportunity information'
  },
  'Internal Memo': {
    color: '#10B981', // green
    icon: <InsertDriveFile fontSize="small" />,
    description: 'Internal analysis and recommendations'
  },
  'Investment Summary': {
    color: '#8B5CF6', // purple
    icon: <Article fontSize="small" />,
    description: 'Summary of investment details and terms'
  },
  'Financial Analysis': {
    color: '#2DD4BF', // teal
    icon: <Article fontSize="small" />,
    description: 'Financial data analysis and projections'
  }
};

// Token estimation constants
export const TOKEN_ESTIMATION = {
  // Characters per token (approximate)
  CHARS_PER_TOKEN: 4,
  // PDF-specific estimation (bytes per token)
  PDF_BYTES_PER_TOKEN: 2000,
  // Safety buffer (percentage to add for safety margin)
  SAFETY_BUFFER: 0.2
};

// Document processing constants
export const PROCESSING = {
  // Maximum polling attempts
  MAX_POLLS: 30,
  // Polling interval in milliseconds
  POLL_INTERVAL: 2000
};

// UI constants
export const UI = {
  COLORS: {
    success: '#10B981',
    info: '#3B82F6', 
    warning: '#F59E0B',
    error: '#EF4444',
    processing: '#8B5CF6'
  },
  GRADIENTS: {
    primary: 'linear-gradient(45deg, #3A72F8 30%, #2DD4BF 90%)'
  }
};

// Document status types
export const DOC_STATUS = {
  PROCESSED: 'processed',
  PROCESSING: 'processing',
  FAILED: 'failed',
  PENDING: 'pending'
};

// Utility function: Estimate tokens from file size
export const estimateTokensFromFileSize = (fileSizeBytes) => {
  if (!fileSizeBytes) return 0;
  // Base token estimate
  const baseTokens = Math.ceil(fileSizeBytes / TOKEN_ESTIMATION.PDF_BYTES_PER_TOKEN);
  // Add safety buffer
  return Math.ceil(baseTokens * (1 + TOKEN_ESTIMATION.SAFETY_BUFFER));
};

// Utility function: Estimate tokens from text
export const estimateTokensFromText = (text) => {
  if (!text) return 0;
  // Base estimate: characters divided by chars per token
  const baseTokens = Math.ceil(text.length / TOKEN_ESTIMATION.CHARS_PER_TOKEN);
  // Add safety buffer
  return Math.ceil(baseTokens * (1 + TOKEN_ESTIMATION.SAFETY_BUFFER));
};