#!/bin/bash
set -e

# Default env file path
ENV_FILE="../../backend/.env.local"

# Parse command-line arguments
while [[ "$#" -gt 0 ]]; do
  case $1 in
    --env-file) ENV_FILE="$2"; shift 2 ;;
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
done

# Check if env file exists
if [ ! -f "$ENV_FILE" ]; then
  echo "Error: Environment file $ENV_FILE not found"
  exit 1
fi

# Source the environment file to get version
source "$ENV_FILE"
VERSION=$PROJECT_VERSION
DEPLOY_DATE=$(date -u +%Y-%m-%dT%H:%M:%SZ)
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION=$(aws configure get region)

# Create backend-docdb-fixed.yaml
cat > backend-docdb-fixed.yaml << BACKEND_EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: aide-backend
  namespace: aide
  annotations:
    kubernetes.io/change-cause: "Version ${VERSION} - ${DEPLOY_DATE}"
    app.kubernetes.io/version: "${VERSION}"
spec:
  progressDeadlineSeconds: 900
  replicas: 2
  selector:
    matchLabels:
      app: aide-backend
  template:
    metadata:
      labels:
        app: aide-backend
        version: "${VERSION}"
      annotations:
        deploy-date: "${DEPLOY_DATE}"
    spec:
      containers:
      - name: aide-backend
        image: ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:${VERSION}
        imagePullPolicy: Always
        ports:
        - containerPort: 8000
        env:
        - name: API_ENV
          value: "production"
        - name: MONGODB_DB_NAME
          value: "aide_db"
        - name: MONGODB_URL
          value: "mongodb://aidemaster:AideDB2025!@aide-docdb-eks.cluster-c7qkksa8ibvm.ap-southeast-1.docdb.amazonaws.com:27017/aide_db?tls=true&tlsCAFile=/app/certs/rds-ca-bundle.pem&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false"
        - name: AWS_REGION
          value: "us-east-1"
        - name: AWS_DEFAULT_REGION  
          value: "us-east-1"        
        - name: PROJECT_VERSION
          value: "${VERSION}"
        envFrom:
        - secretRef:
            name: aide-api-keys
        volumeMounts:
        - name: rds-ca-volume
          mountPath: /app/certs
          readOnly: true
        resources:
          requests:
            cpu: "200m"
            memory: "512Mi"
          limits:
            cpu: "500m"
            memory: "1Gi"
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 15
          periodSeconds: 10
      volumes:
      - name: rds-ca-volume
        configMap:
          name: rds-ca-bundle
---
apiVersion: v1
kind: Service
metadata:
  name: aide-backend-service
  namespace: aide
spec:
  selector:
    app: aide-backend
  ports:
  - port: 8000
    targetPort: 8000
  type: ClusterIP
BACKEND_EOF

# Create frontend-deployment.yaml
cat > frontend-deployment.yaml << FRONTEND_EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: aide-frontend
  namespace: aide
  annotations:
    kubernetes.io/change-cause: "Version ${VERSION} - ${DEPLOY_DATE}"
    app.kubernetes.io/version: "${VERSION}"
spec:
  progressDeadlineSeconds: 900
  replicas: 2
  selector:
    matchLabels:
      app: aide-frontend
  template:
    metadata:
      labels:
        app: aide-frontend
        version: "${VERSION}"
      annotations:
        deploy-date: "${DEPLOY_DATE}"
    spec:
      containers:
      - name: aide-frontend
        image: ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:${VERSION}
        imagePullPolicy: Always
        ports:
        - containerPort: 80
        env:
        - name: VERSION
          value: "${VERSION}"
        resources:
          requests:
            cpu: "100m"
            memory: "256Mi"
          limits:
            cpu: "200m"
            memory: "512Mi"
        readinessProbe:
          httpGet:
            path: /
            port: 80
          initialDelaySeconds: 5
          periodSeconds: 10
---
apiVersion: v1
kind: Service
metadata:
  name: aide-frontend-service
  namespace: aide
spec:
  selector:
    app: aide-frontend
  ports:
  - port: 80
    targetPort: 80
  type: ClusterIP
FRONTEND_EOF

echo "Deployment files generated successfully!"