#!/bin/bash
set -e

# Default env file path
ENV_FILE="../../backend/.env.local"

# Parse command-line arguments
while [[ "$#" -gt 0 ]]; do
  case $1 in
    --env-file) ENV_FILE="$2"; shift 2 ;;
    *) echo "Unknown parameter: $1"; exit 1 ;;
  esac
done

# Check if env file exists
if [ ! -f "$ENV_FILE" ]; then
  echo "Error: Environment file $ENV_FILE not found"
  exit 1
fi

# Source the environment file to get values
source "$ENV_FILE"

# Generate base64 encoded values
GOOGLE_API_KEY_B64=$(echo -n "$GOOGLE_API_KEY" | base64 -w 0)
OPENAI_API_KEY_B64=$(echo -n "$OPENAI_API_KEY" | base64 -w 0)
PRIMARY_MODEL_B64=$(echo -n "$PRIMARY_MODEL" | base64 -w 0)
FALLBACK_MODEL_B64=$(echo -n "$FALLBACK_MODEL" | base64 -w 0)
ULTRA_CONTEXT_MODEL_B64=$(echo -n "$ULTRA_CONTEXT_MODEL" | base64 -w 0)
TEXT_EXTRACT_MODEL_B64=$(echo -n "$TEXT_EXTRACT_MODEL" | base64 -w 0)

# Create secrets.yaml from template
echo "Generating secrets.yaml from template..."
cp secrets-template.yaml secrets.yaml

# Replace placeholders
sed -i "s/{{GOOGLE_API_KEY_BASE64}}/$GOOGLE_API_KEY_B64/g" secrets.yaml
sed -i "s/{{OPENAI_API_KEY_BASE64}}/$OPENAI_API_KEY_B64/g" secrets.yaml
sed -i "s/{{PRIMARY_MODEL_BASE64}}/$PRIMARY_MODEL_B64/g" secrets.yaml
sed -i "s/{{FALLBACK_MODEL_BASE64}}/$FALLBACK_MODEL_B64/g" secrets.yaml
sed -i "s/{{ULTRA_CONTEXT_MODEL_BASE64}}/$ULTRA_CONTEXT_MODEL_B64/g" secrets.yaml
sed -i "s/{{TEXT_EXTRACT_MODEL_BASE64}}/$TEXT_EXTRACT_MODEL_B64/g" secrets.yaml

# Apply secrets to cluster
echo "Applying secrets to cluster..."
kubectl apply -f secrets.yaml

echo "Secrets created successfully!"
