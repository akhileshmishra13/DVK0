#!/usr/bin/env python3
"""
DocumentDB Interactive Shell
----------------------------
Provides interactive access to the AIDE DocumentDB database.
Run from your local machine to connect through a backend pod.
"""
import os
import sys
import json
import subprocess
from datetime import datetime
import argparse
import code

def get_backend_pod():
    """Get the name of an available backend pod"""
    result = subprocess.run(
        ["kubectl", "get", "pods", "-n", "aide", "-l", "app=aide-backend", "-o", "jsonpath='{.items[0].metadata.name}'"],
        capture_output=True, text=True, check=True
    )
    return result.stdout.strip().replace("'", "")

def run_in_pod(pod_name, script_content):
    """Run a Python script in the specified pod and return the result"""
    # Create a temporary script file
    temp_file = "/tmp/temp_docdb_script.py"
    with open(temp_file, "w") as f:
        f.write(script_content)
    
    # Copy to pod
    subprocess.run(["kubectl", "cp", temp_file, f"{pod_name}:/tmp/temp_docdb_script.py", "-n", "aide"], check=True)
    
    # Run in pod
    result = subprocess.run(
        ["kubectl", "exec", "-it", pod_name, "-n", "aide", "--", "python", "/tmp/temp_docdb_script.py"],
        capture_output=False, text=True
    )
    
    # Clean up
    os.unlink(temp_file)
    return result

def interactive_shell():
    """Launch an interactive MongoDB shell"""
    print("Connecting to DocumentDB through backend pod...")
    pod_name = get_backend_pod()
    print(f"Using pod: {pod_name}")
    
    script = '''
from pymongo import MongoClient
import os
import json
import code
from datetime import datetime
from bson import json_util

# Connect to DocumentDB
mongodb_url = os.environ.get("MONGODB_URL")
db_name = os.environ.get("MONGODB_DB_NAME", "aide_db")

print(f"Connected to: {mongodb_url.split('@')[1].split('/')[0]}")
print(f"Database: {db_name}")

# Connect with proper settings
client = MongoClient(mongodb_url)
db = client[db_name]

# Add helper functions
def list_collections():
    """List all collections with document counts"""
    collections = db.list_collection_names()
    result = []
    for coll in sorted(collections):
        count = db[coll].count_documents({})
        result.append({"collection": coll, "documents": count})
    return result

def list_documents(collection="fs.files", limit=10, query=None, projection=None):
    """List documents in a collection with optional query and projection"""
    if query is None:
        query = {}
    if projection is None:
        projection = {"_id": 1}
    
    return list(db[collection].find(query, projection).limit(limit))

def pretty(obj):
    """Pretty print an object"""
    return json.dumps(json.loads(json_util.dumps(obj)), indent=2)

def stats():
    """Get database stats"""
    return db.command("dbstats")

def collection_stats(collection="fs.files"):
    """Get collection stats"""
    return db.command("collStats", collection)

def help():
    """Show available helper functions"""
    print("\\nAvailable helper functions:")
    print("  list_collections() - List all collections with document counts")
    print("  list_documents(collection='fs.files', limit=10, query=None, projection=None)")
    print("  pretty(obj) - Pretty print an object")
    print("  stats() - Get database stats")
    print("  collection_stats(collection) - Get collection stats")
    print("  help() - Show this help")
    print("\\nAvailable variables:")
    print("  client - MongoDB client")
    print("  db - Database object")
    print("\\nExample queries:")
    print("  db.fs.files.find_one()")
    print("  list(db.fs.files.find({'filename': 'Project Atlas Teaser.pdf'}))")
    print("  db.fs.files.update_one({'filename': 'Project Phoenix IM.pdf'}, {'$set': {'new_field': 'value'}})")

print("\\n=== AIDE DocumentDB Interactive Shell ===")
help()
print("\\nPress Ctrl+D to exit")

# Start interactive shell
code.interact(local=locals())
'''
    
    run_in_pod(pod_name, script)

def main():
    parser = argparse.ArgumentParser(description="DocumentDB interactive shell")
    parser.add_argument("--collections", action="store_true", help="List collections")
    parser.add_argument("--documents", action="store_true", help="List documents")
    parser.add_argument("--stats", action="store_true", help="Show database stats")
    
    args = parser.parse_args()
    
    if args.collections:
        # Just list collections
        script = '''
from pymongo import MongoClient
import os
import json

client = MongoClient(os.environ.get("MONGODB_URL"))
db = client[os.environ.get("MONGODB_DB_NAME", "aide_db")]

collections = db.list_collection_names()
for coll in sorted(collections):
    count = db[coll].count_documents({})
    print(f"{coll}: {count} documents")
'''
        pod_name = get_backend_pod()
        run_in_pod(pod_name, script)
    elif args.documents:
        # List documents
        script = '''
from pymongo import MongoClient
import os
import json
from bson import json_util

client = MongoClient(os.environ.get("MONGODB_URL"))
db = client[os.environ.get("MONGODB_DB_NAME", "aide_db")]

print("Documents in fs.files:")
for doc in db.fs.files.find():
    print(f"- {doc['filename']} ({doc['metadata']['extracted_metadata']['document_type']})")
    print(f"  Uploaded: {doc['uploadDate']}")
    print(f"  Size: {doc['length']} bytes")
    print(f"  ID: {doc['_id']}")
    print()
'''
        pod_name = get_backend_pod()
        run_in_pod(pod_name, script)
    elif args.stats:
        # Show stats
        script = '''
from pymongo import MongoClient
import os
import json
from bson import json_util

client = MongoClient(os.environ.get("MONGODB_URL"))
db = client[os.environ.get("MONGODB_DB_NAME", "aide_db")]

stats = db.command("dbStats")
print("Database Stats:")
print(f"Database: {stats['db']}")
print(f"Collections: {stats['collections']}")
print(f"Views: {stats['views']}")
print(f"Objects: {stats['objects']}")
print(f"Data Size: {stats['dataSize']} bytes")
print(f"Storage Size: {stats['storageSize']} bytes")
print(f"Indexes: {stats['indexes']}")
print(f"Index Size: {stats['indexSize']} bytes")
'''
        pod_name = get_backend_pod()
        run_in_pod(pod_name, script)
    else:
        # Default to interactive shell
        interactive_shell()

if __name__ == "__main__":
    main()
