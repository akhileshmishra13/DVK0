# backend/tests/test_health.py

from fastapi.testclient import TestClient
from app.main import app

def test_health_endpoint(client):
    """Test that the health endpoint returns a 200 response"""
    response = client.get("/health")
    assert response.status_code == 200
    assert "status" in response.json()
    assert response.json()["message"] == "System health check"
