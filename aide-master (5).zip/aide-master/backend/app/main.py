# app/main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging
import datetime

from app.core.config import settings
from app.router import init_routes  
from app.middleware.auth_middleware import AuthMiddleware
from app.middleware.logging_middleware import LoggingMiddleware
from app.core.service_init import initialize_services, shutdown_services
from app.utils.response_util import ResponseUtil
from app.handlers import register_exception_handlers 

# Configure basic logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Keppel AI Deal Evaluation",
    version="0.1.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Logging middleware (should be first to capture all requests)
app.add_middleware(LoggingMiddleware)

# Auth middleware
app.add_middleware(AuthMiddleware)

# Register global exception handlers
register_exception_handlers(app)

# Initialize all routes
init_routes(app)

@app.get("/health", tags=["health"])
async def health_check():  # Add async keyword
    """System health check endpoint"""
    import platform
    
    system_info = {
        "status": "healthy",
        "timestamp": datetime.datetime.now().isoformat(),
        "environment": settings.API_ENV,
        "system": {
            "platform": platform.platform(),
            "python_version": platform.python_version()
        }
    }
    
    return await ResponseUtil.health_response(  # Add await keyword
        status_details=system_info,
        message="System health check"
    )

# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    await initialize_services(app)

@app.on_event("shutdown")
async def shutdown_event():
    await shutdown_services(app)