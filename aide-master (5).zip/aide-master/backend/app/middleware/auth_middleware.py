# backend/app/middleware/auth_middleware.py
from fastapi import Request, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

class AuthMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        # Define public paths that don't require authentication
        self.public_paths = [
            "/auth/login",  # Add the login endpoint specifically
            "/health",
            "/api/v1/system/status",
            "/api/v1/system/health",
            "/docs",
            "/redoc",
            "/openapi.json"
        ]
    
    async def dispatch(self, request: Request, call_next):
        # Skip authentication for OPTIONS requests (CORS preflight)
        if request.method == "OPTIONS":
            return await call_next(request)
            
        # Skip authentication for public paths
        path = request.url.path
        if any(path.startswith(public_path) for public_path in self.public_paths):
            return await call_next(request)
            
        # Check for Authorization header
        if "authorization" not in request.headers:
            # Create response with CORS headers included
            response = JSONResponse(
                status_code=status.HTTP_401_UNAUTHORIZED,
                content={
                    "status": "error",
                    "message": "Authentication required",
                    "data": None,
                    "metadata": {
                        "error_code": "AUTH_REQUIRED",
                        "error_detail": "No authorization header provided"
                    }
                }
            )
            
            # Add CORS headers manually
            response.headers["Access-Control-Allow-Origin"] = "*"
            response.headers["Access-Control-Allow-Methods"] = "*"
            response.headers["Access-Control-Allow-Headers"] = "*"
            return response
            
        return await call_next(request)