# backend/app/models/auth.py

from typing import Optional
from pydantic import BaseModel, EmailStr

class Token(BaseModel):
    access_token: str
    token_type: str
    expires_in: int
    id_token: Optional[str] = None
    refresh_token: Optional[str] = None

class TokenPayload(BaseModel):
    sub: Optional[str] = None
    exp: Optional[int] = None

class UserLogin(BaseModel):
    email: str  # Using str instead of EmailStr for simplicity
    password: str

class UserCreate(UserLogin):
    first_name: str
    last_name: str
