# backend/app/services/logging_service.py
import logging
import logging.handlers # Import handlers for RotatingFileHandler
import json
import time
import uuid
import os
import sys
from typing import Dict, Any, Optional
from pathlib import Path
import datetime # Keep this import

from app.services.base_service import BaseService, ServiceStatus
from app.core.config import settings

# Define a logger for the logging service itself
logger = logging.getLogger("logging_service") # Keep this specific logger name

# Configure logging format
class CustomFormatter(logging.Formatter):
    """Custom formatter that includes timestamp, level, context and structured data"""
    def format(self, record):
        # Add ISO format timestamp
        # Use timezone-aware UTC time for consistency
        # --- FIX: Ensure datetime module is accessible ---
        record.timestamp = datetime.datetime.fromtimestamp(record.created, tz=datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")

        # Add milliseconds
        record.msecs_formatted = "%03d" % record.msecs

        # Add request ID if it exists
        record.request_id = getattr(record, 'request_id', '-')

        # Add user ID if it exists
        record.user_id = getattr(record, 'user_id', '-')

        # Add correlation ID for tracking related events
        record.correlation_id = getattr(record, 'correlation_id', '-')

        # Format the log message
        log_message = super().format(record)

        return log_message

# --- (The rest of the LoggingService class remains the same as the previous correct version) ---
class LoggingService(BaseService):
    # ... (init, initialize, get_logger, log, stop methods) ...
    def __init__(self):
        # --- Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            # Initialize loggers dictionary before calling super().__init__
            self.loggers: Dict[str, logging.Logger] = {}

            # Call super().__init__ AFTER setting subclass attributes
            super().__init__(name="logging_service", dependencies=[]) # Logging has no dependencies

            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "log_level": settings.LOG_LEVEL,
                "log_format": "structured",
                "logs_path": "logs/",
                "initialized": False
            })
            self._initialized_ = True # Mark as initialized

    async def initialize(self) -> bool:
        """Initialize the logging service"""
        try:
            # Create logs directory if it doesn't exist using pathlib
            log_dir = Path("logs")
            log_dir.mkdir(exist_ok=True)
            error_log_path = log_dir / "error.log"
            app_log_path = log_dir / "aide.log"


            # Configure root logger
            root_logger = logging.getLogger() # Get the root logger
            # Set root logger level - handlers control filtering below this level
            root_logger.setLevel(getattr(logging, settings.LOG_LEVEL, logging.INFO))

            # Clear any existing handlers from the root logger ONLY
            # Avoid clearing handlers from other loggers like uvicorn
            for handler in root_logger.handlers[:]:
                root_logger.removeHandler(handler)

            # --- Console Handler ---
            console_handler = logging.StreamHandler(sys.stdout)
            # Let console handler respect the root logger's level by default
            # console_handler.setLevel(getattr(logging, settings.LOG_LEVEL, logging.INFO))
            console_format = "[%(timestamp)s.%(msecs_formatted)s] %(levelname)-7s [%(name)-15s] [%(correlation_id)s] [%(request_id)s] [%(user_id)s] - %(message)s"
            console_formatter = CustomFormatter(console_format)
            console_handler.setFormatter(console_formatter)
            root_logger.addHandler(console_handler)

            # --- Error File Handler ---
            # Use RotatingFileHandler for better log management
            error_file_handler = logging.handlers.RotatingFileHandler(
                 error_log_path, maxBytes=10*1024*1024, backupCount=3 # 10MB per file, keep 3 backups
            )
            error_file_handler.setLevel(logging.ERROR) # Only log ERROR and CRITICAL
            error_file_handler.setFormatter(console_formatter) # Use the same format
            root_logger.addHandler(error_file_handler)

            # --- Application File Handler (All Logs) ---
            # Use RotatingFileHandler
            file_handler = logging.handlers.RotatingFileHandler(
                 app_log_path, maxBytes=50*1024*1024, backupCount=5 # 50MB per file, keep 5 backups
            )
            # Let file handler respect the root logger's level
            # file_handler.setLevel(getattr(logging, settings.LOG_LEVEL, logging.INFO))
            file_handler.setFormatter(console_formatter) # Use the same format
            root_logger.addHandler(file_handler)

            # Mark as initialized
            self.status_details["initialized"] = True
            # Call super().initialize() which sets status to RUNNING and logs
            initialized_base = await super().initialize()
            if not initialized_base: # Check if base initialization failed
                 return False

            # Use the specific logger defined for this service AFTER ensuring base init is done
            # Note: Using logger.info here will work because the root logger handlers are now set up
            logger.info(f"Logging service initialized with log level: {settings.LOG_LEVEL}")


            return True
        except NameError as ne:
             # Specifically catch the NameError if Path wasn't defined (should be fixed now)
             print(f"CRITICAL: NameError during logging service initialization: {str(ne)}. Ensure 'from pathlib import Path' is present.")
             self.status = ServiceStatus.ERROR
             self.status_message = f"Logging service initialization error: {str(ne)}"
             return False
        except Exception as e:
            # Use print for critical initialization errors as logging might not be ready
            print(f"CRITICAL: Error initializing logging service: {type(e).__name__}: {str(e)}")
            self.status = ServiceStatus.ERROR
            self.status_message = f"Logging service initialization error: {str(e)}"
            return False

    def get_logger(self, name: str) -> logging.Logger:
        """Get a logger with the given name"""
        # Loggers inherit level from the root logger by default
        # No need to set level explicitly here unless specific override is needed
        if name not in self.loggers:
            self.loggers[name] = logging.getLogger(name)
        return self.loggers[name]

    def log(self,
            level: str,
            message: str,
            module: Optional[str] = None,
            request_id: Optional[str] = None,
            user_id: Optional[str] = None,
            correlation_id: Optional[str] = None,
            **kwargs) -> None:
        """
        Log a message with the specified level and context

        Args:
            level: Log level (debug, info, warning, error, critical)
            message: Log message
            module: Module name (defaults to service name if called from service context)
            request_id: Request ID for tracing
            user_id: User ID for context
            correlation_id: Correlation ID for related events
            **kwargs: Additional context to include in the log as JSON
        """
        # Use the service name as module if not provided and available
        actual_module = module or getattr(self, 'name', 'unknown_module')

        # Check if service is initialized before trying to use get_logger
        if not self.status_details.get("initialized", False):
             print(f"WARNING: LoggingService not initialized. Log attempt: [{level.upper()}] {actual_module} - {message}")
             return

        try:
            logger_instance = self.get_logger(actual_module)

            # Create extra context dictionary for formatter
            extra = {
                'request_id': request_id or '-',
                'user_id': user_id or '-',
                'correlation_id': correlation_id or '-',
            }

            # Convert log level string to int, default to INFO if invalid
            log_level_int = getattr(logging, level.upper(), logging.INFO)

            # Safely include additional context in the message as JSON
            if kwargs:
                try:
                    # Use default=str for non-serializable objects
                    context_str = json.dumps(kwargs, default=str)
                    message = f"{message} - Context: {context_str}"
                except Exception as json_err:
                    # Use the logger_instance directly here, it should exist
                    logger_instance.warning(f"Failed to serialize extra context for logging: {json_err}", extra=extra)
                    message = f"{message} - [Context serialization error]"

            # Log with extra context using the correct integer level
            logger_instance.log(log_level_int, message, extra=extra)
        except Exception as e:
            # Fallback logging if something goes wrong with the logging service itself
            print(f"CRITICAL LOGGING ERROR in module '{actual_module}': {str(e)}, Original message: {message}")

    async def stop(self) -> bool:
        """Stop the logging service"""
        try:
            # Use print instead of logging to avoid potential recursion issues
            print(f"[{datetime.datetime.now(datetime.timezone.utc).isoformat()}] INFO [logging_service] Shutting down logging service...")
            logging.shutdown() # Flushes and closes handlers
            print(f"[{datetime.datetime.now(datetime.timezone.utc).isoformat()}] INFO [logging_service] Logging service shutdown complete.")
            # Don't call super().stop() as it uses self.log which might fail after shutdown
            self.status = ServiceStatus.STOPPED
            self.status_message = "Service stopped"
            return True
        except Exception as e:
            print(f"Error stopping logging service: {str(e)}")
            self.status = ServiceStatus.ERROR
            self.status_message = f"Error stopping logging service: {str(e)}"
            return False

# Create the singleton instance
logging_service = LoggingService()