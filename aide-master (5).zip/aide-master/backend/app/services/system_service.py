# backend/app/services/system_service.py
from typing import Dict, List, Any, Optional
import logging
import datetime
import time
from app.services.base_service import BaseService, ServiceStatus, ServiceInfo
from app.core.registry import get_all_services, get_service # Added get_service

logger = logging.getLogger(__name__)

class SystemService(BaseService):
    """Service responsible for managing and monitoring other services"""

    def __init__(self):
        # --- FIX: Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            # Initialize these attributes before calling super().__init__
            self.initialization_order: List[str] = []
            self.start_time: str = datetime.datetime.now(datetime.timezone.utc).isoformat()
            self.start_timestamp: float = time.time()

            # Call super().__init__ AFTER setting subclass attributes
            super().__init__(name="system_service", dependencies=[]) # Dependencies managed internally

            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "total_services": 0, # Will be updated after registry scan
                "initialization_complete": False,
                "start_time": self.start_time # Add start time to details
            })
            self._initialized_ = True # Mark initialized

    @property
    def uptime_seconds(self) -> int:
        """Get the system uptime in seconds"""
        return int(time.time() - self.start_timestamp)

    async def initialize(self) -> bool:
        """Initialize the system service itself (after __init__)"""
        # This service is simple, mainly coordinates others
        # Update status details which might depend on other services being registered
        try:
             all_services = get_all_services()
             self.status_details["total_services"] = len(all_services)
             self.update_status(
                  ServiceStatus.RUNNING,
                  "System service running",
                  {"uptime_seconds": self.uptime_seconds} # Update uptime on init
             )
             return await super().initialize() # Call base initialize for logging
        except Exception as e:
             logger.error(f"Error during SystemService initialization: {e}")
             self.update_status(ServiceStatus.ERROR, f"Initialization error: {e}")
             return False


    def set_initialization_order(self, order: List[str]) -> None:
        """Set the service initialization order"""
        self.initialization_order = order
        logger.info(f"Service initialization order set: {order}")
        self.status_details["initialization_order_set"] = True

    async def initialize_all_services(self) -> bool:
        """Initialize all registered services in the defined order"""
        logger.info("Starting service initialization sequence")
        if not self.initialization_order:
            logger.error("Initialization order not set. Cannot initialize services.")
            self.update_status(ServiceStatus.ERROR, "Initialization order missing.")
            return False

        all_services = get_all_services()
        success = True
        initialized_services = set()

        for service_name in self.initialization_order:
            # Skip self, it's already initialized
            if service_name == self.name:
                initialized_services.add(service_name)
                continue

            if service_name not in all_services:
                logger.warning(f"Service '{service_name}' in initialization order but not found in registry. Skipping.")
                continue

            service = all_services[service_name]

            # Check dependencies
            all_deps_initialized = True
            missing_deps = []
            for dep_name in service.dependencies:
                if dep_name not in initialized_services:
                    all_deps_initialized = False
                    missing_deps.append(dep_name)

            if not all_deps_initialized:
                logger.error(f"Cannot initialize '{service_name}', missing dependencies: {missing_deps}. Aborting initialization.")
                success = False
                self.update_status(ServiceStatus.ERROR, f"Initialization failed: Missing dependencies for {service_name}: {missing_deps}")
                break # Stop initialization if dependencies are missing

            # Initialize the service
            logger.info(f"Initializing service: {service_name}")
            try:
                if await service.initialize():
                    initialized_services.add(service_name)
                    logger.info(f"Service {service_name} initialized successfully")
                else:
                    logger.error(f"Failed to initialize service: {service_name}")
                    success = False
                    self.update_status(ServiceStatus.ERROR, f"Initialization failed for service: {service_name}")
                    break # Stop initialization if a service fails
            except Exception as e:
                logger.exception(f"CRITICAL ERROR during initialization of {service_name}: {str(e)}")
                service.update_status(ServiceStatus.ERROR, f"Critical initialization error: {str(e)}")
                success = False
                self.update_status(ServiceStatus.ERROR, f"Critical error initializing {service_name}")
                break # Stop initialization on critical error

        # Update final status
        if success:
            self.status_details["initialization_complete"] = True
            self.update_status(
                ServiceStatus.RUNNING,
                "All services initialized successfully",
                {"initialized_services": list(initialized_services)}
            )
        else:
             self.status_details["initialization_complete"] = False
             # Status was already updated to ERROR when failure occurred


        return success

    def get_all_service_statuses(self) -> List[ServiceInfo]:
        """Get status information for all registered services"""
        services = get_all_services()
        # Update own uptime before returning statuses
        self.status_details["uptime_seconds"] = self.uptime_seconds
        return [service.get_status() for service in services.values()]

    def get_service_status(self, service_name: str) -> Optional[ServiceInfo]:
        """Get status for a specific service"""
        services = get_all_services()
        if service_name in services:
            service = services[service_name]
            # Update uptime for system service if requested
            if service_name == self.name:
                 service.status_details["uptime_seconds"] = self.uptime_seconds
            return service.get_status()
        logger.warning(f"Requested status for unknown service: {service_name}")
        return None

    async def stop(self) -> bool:
        """Stop the system service (usually called during app shutdown)"""
        # No specific resources to release here, base class handles status update
        return await super().stop()


# Create the singleton instance
system_service = SystemService()