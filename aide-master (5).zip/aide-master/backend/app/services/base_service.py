# backend/app/services/base_service.py

from typing import Dict, Any, Optional, List
from enum import Enum
import logging
from pydantic import BaseModel
from app.core.registry import register_service
from app.utils.logging_context import LoggingContext

logger = logging.getLogger(__name__)

class ServiceStatus(str, Enum):
    INITIALIZING = "initializing"
    RUNNING = "running"
    ERROR = "error"
    STOPPED = "stopped"

class ServiceInfo(BaseModel):
    name: str
    status: ServiceStatus
    message: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    dependencies: List[str] = []

class BaseService:
    """Base class for all services with status tracking and dependencies"""
    
    _instances = {}  # Class variable to store singleton instances
    
    def __new__(cls, *args, **kwargs):
        """Ensure only one instance per class exists"""
        if cls not in cls._instances:
            cls._instances[cls] = super(BaseService, cls).__new__(cls)
            # Mark this instance as needing initialization
            cls._instances[cls]._needs_init = True 
        return cls._instances[cls]
    
    def __init__(self, name: str, dependencies: List[str] = None):
        """Initialize service properties (only runs once)"""
        # Only initialize once
        if hasattr(self, '_needs_init') and self._needs_init:
            self.name = name
            self.dependencies = dependencies or []
            self.status = ServiceStatus.INITIALIZING
            self.status_message = "Service initializing"
            self.status_details = {}
            self._needs_init = False  # Mark as initialized
            self._log_service_creation()
            
            # Register service in registry
            register_service(name, self)
    
    def _log_service_creation(self):
        """Log service creation with request context if available"""
        request_id = LoggingContext.get_request_id()
        user_id = LoggingContext.get_user_id()
        correlation_id = LoggingContext.get_correlation_id()
        
        logger.info(
            f"Service {self.name} created",
            extra={
                "request_id": request_id or "-",
                "user_id": user_id or "-",
                "correlation_id": correlation_id or "-"
            }
        )
    
    def log(self, level: str, message: str, **kwargs):
        """Log a message using the logging service if available"""
        try:
            # Special handling for the logging service itself to avoid circular reference
            if self.name == "logging_service":
                # Just use standard logger directly
                getattr(logger, level.lower())(
                    message,
                    extra={
                        "request_id": "-",
                        "user_id": "-",
                        "correlation_id": "-"
                    }
                )
                return
                
            from app.core.registry import get_service
            logging_service = get_service("logging_service")
            
            # Get request context if available
            request_id = LoggingContext.get_request_id()
            user_id = LoggingContext.get_user_id()
            correlation_id = LoggingContext.get_correlation_id()
            
            # Log using the logging service, explicitly passing our service name as the module
            logging_service.log(
                level=level,
                message=message,
                module=self.name,  # Pass our service name as the module
                request_id=request_id,
                user_id=user_id,
                correlation_id=correlation_id,
                **kwargs
            )
        except (ImportError, KeyError):
            # If logging service is not available, use standard logger
            getattr(logger, level.lower())(
                message,
                extra={
                    "request_id": "-",
                    "user_id": "-",
                    "correlation_id": "-"
                }
            )
    
    async def initialize(self) -> bool:
        """Initialize the service"""
        try:
            self.log("info", f"Initializing {self.name} service")
            self.status = ServiceStatus.RUNNING
            self.status_message = "Service running"
            return True
        except Exception as e:
            self.log("error", f"Error initializing {self.name} service: {str(e)}")
            self.status = ServiceStatus.ERROR
            self.status_message = f"Initialization error: {str(e)}"
            return False
    
    async def stop(self) -> bool:
        """Stop the service"""
        try:
            self.log("info", f"Stopping {self.name} service")
            self.status = ServiceStatus.STOPPED
            self.status_message = "Service stopped"
            return True
        except Exception as e:
            self.log("error", f"Error stopping {self.name} service: {str(e)}")
            self.status = ServiceStatus.ERROR
            self.status_message = f"Stop error: {str(e)}"
            return False
    
    def get_status(self) -> ServiceInfo:
        """Get current service status"""
        return ServiceInfo(
            name=self.name,
            status=self.status,
            message=self.status_message,
            details=self.status_details,
            dependencies=self.dependencies
        )
    
    def update_status(self, status: ServiceStatus, message: str, details: Dict[str, Any] = None) -> None:
        """Update service status"""
        self.status = status
        self.status_message = message
        if details:
            self.status_details.update(details)
        self.log("info", f"Service {self.name} status updated: {status} - {message}")