# backend/app/services/completion_service.py

from typing import Dict, Any, Optional, List
import logging
import uuid
from app.services.base_service import BaseService, ServiceStatus
from app.core.registry import get_service
from app.core.config import settings

logger = logging.getLogger(__name__)

class CompletionService(BaseService):
    """
    Service for handling AI completion requests
    """

    def __init__(self):
        # --- FIX: Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            # No specific attributes *before* super in this case, but keep pattern

            # Call super().__init__ AFTER setting subclass attributes (if any)
            super().__init__(name="completion_service", dependencies=["model_manager", "prompt_system"])

            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "completions_processed": 0,
                "initialized": False
            })
            self._initialized_ = True # Mark as initialized

    async def initialize(self) -> bool:
        """Initialize completion service and dependencies"""
        try:
            # Verify dependencies are running (optional check)
            model_manager = get_service("model_manager")
            prompt_system = get_service("prompt_system")
            if model_manager.status != ServiceStatus.RUNNING:
                 logger.warning(f"Dependency {model_manager.name} is not running ({model_manager.status}).")
            if prompt_system.status != ServiceStatus.RUNNING:
                 logger.warning(f"Dependency {prompt_system.name} is not running ({prompt_system.status}).")

            # Mark as initialized
            self.status_details["initialized"] = True
            self.update_status(
                ServiceStatus.RUNNING,
                "Completion service initialized successfully"
            )
            # Call super().initialize() to log the final running status correctly
            return await super().initialize()
        except Exception as e:
            logger.error(f"Error initializing completion service: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Completion service initialization error: {str(e)}"
            )
            return False

    async def create_completion(self,
                            prompt: Optional[str] = None,
                            template_id: Optional[str] = None,
                            template_vars: Optional[Dict[str, Any]] = None,
                            max_tokens: Optional[int] = None,
                            temperature: Optional[float] = None,
                            model_type: str = 'primary',
                            documents: Optional[List[str]] = None,
                            use_reasoning: bool = False) -> Dict[str, Any]:
        """
        Create a completion based on prompt or template
        
        Args:
            prompt: Optional direct prompt text
            template_id: Optional template ID to use
            template_vars: Optional variables for template
            max_tokens: Maximum tokens to generate (uses default from settings if None)
            temperature: Temperature for generation (uses default from settings if None)
            model_type: Type of model to use (primary, ultra_context, etc.)
            documents: Optional list of document IDs to include in analysis
            use_reasoning: Whether to enable reasoning for supported models
            
        Returns:
            Completion result with standardized format
        """
        # Get services via registry when needed
        model_manager = get_service("model_manager")
        prompt_system = get_service("prompt_system")
        data_service = get_service("data_service")
        
        # Use defaults from settings if not provided
        max_tokens = max_tokens or settings.DEFAULT_MAX_TOKENS
        temperature = temperature or settings.DEFAULT_TEMPERATURE

        completion_id = str(uuid.uuid4())
        logger.info(f"Creating completion {completion_id} with model_type {model_type}")

        try:
            # Ensure either prompt or template_id is provided
            if not prompt and not template_id and not documents:
                raise ValueError("Either prompt, template_id, or documents must be provided.")

            # Build the prompt from various sources
            prompt_text = ""
            system_prompt = None
            
            # If document IDs are provided, fetch their content
            document_contents = []
            if documents and len(documents) > 0:
                logger.info(f"Processing {len(documents)} documents for completion")
                for doc_id in documents:
                    doc = await data_service.get_document(doc_id)
                    if doc:
                        # Look for text content in the correct location in document metadata
                        if doc.get("metadata", {}).get("text_content"):
                            document_contents.append(f"Document: {doc['filename']}\n\n{doc['metadata']['text_content']}")
                        # Fallback to extracted_text if present (but this should be rare with new flow)
                        elif doc.get("metadata", {}).get("extracted_text"):
                            document_contents.append(f"Document: {doc['filename']}\n\n{doc['metadata']['extracted_text']}")
                        else:
                            logger.warning(f"No text content found for document {doc_id}")
                
                if document_contents:
                    logger.info(f"Found content for {len(document_contents)} documents")
                else:
                    logger.warning(f"No document content found for any of the {len(documents)} requested documents")
            
            # If template is provided, format the prompt - handle document references but don't inject content
            if template_id:
                logger.info(f"Using template {template_id} for completion {completion_id}")
                
                # Initialize template_vars if not provided
                template_vars_copy = dict(template_vars or {})
                
                # Get template details to check required variables
                template_details = await prompt_system.get_template(template_id)
                required_vars = template_details.get('required_variables', [])
                
                # For document-related variables, add a reference but NOT the content
                if 'deal_details' in required_vars and documents and len(documents) > 0:
                    # Just note that documents are attached - don't try to include their content
                    doc_names = [f"'{doc['filename']}'" for doc in 
                               [await data_service.get_document(doc_id) for doc_id in documents] 
                               if doc]
                    doc_list = ", ".join(doc_names)
                    template_vars_copy['deal_details'] = f"Please analyze the attached documents: {doc_list}"
                
                # Get the formatted template with variables
                template_content = await prompt_system.get_prompt(
                    template_id,
                    **template_vars_copy
                )
                
                # Check if template has a system prompt section
                if "---SYSTEM PROMPT---" in template_content:
                    parts = template_content.split("---SYSTEM PROMPT---", 1)
                    if len(parts) == 2:
                        system_prompt = parts[0].strip()
                        prompt_text += parts[1].strip()
                    else:
                        prompt_text += template_content
                else:
                    prompt_text += template_content
            elif prompt:
                # Check if direct prompt has a system prompt section
                if "---SYSTEM PROMPT---" in prompt:
                    parts = prompt.split("---SYSTEM PROMPT---", 1)
                    if len(parts) == 2:
                        system_prompt = parts[0].strip()
                        prompt_text += parts[1].strip()
                    else:
                        prompt_text += prompt
                else:
                    prompt_text += prompt
            
            # CRITICAL FIX: Add document content section AFTER the prompt text
            if document_contents:
                prompt_text += "\n\n# Document Content\n\n" + "\n\n---\n\n".join(document_contents) + "\n\n"
                
                # Add document attribution instruction for document analysis
                prompt_text += "\n\nIMPORTANT: In your response, clearly attribute information to the specific documents used as sources. Include a 'Document Sources' section at the end of your response that lists all documents used."
            
            # If we have documents but no specific prompt, add a generic analysis request
            if documents and not prompt and not template_id:
                prompt_text += "\n\nPlease analyze these documents and provide a comprehensive deal evaluation."

            # Check if we should use grounding model
            use_grounding = model_type == 'grounding_model'
            
            # Enable reasoning for Claude 3.7 Sonnet by default when it's explicitly requested
            # or when using the primary model and Claude 3.7 Sonnet is set as the primary
            if not use_reasoning and model_type == 'primary' and 'claude-3-7' in model_manager.models.get('primary', '').lower():
                # Auto-enable reasoning for Claude models when it's the primary
                use_reasoning = True
                logger.info(f"Auto-enabling reasoning mode for Claude 3.7 Sonnet")
            
            # Add system prompt for Claude if not specified
            if not system_prompt and model_type in ('primary', 'advanced_reasoning'):
                provider = await model_manager.get_provider(await model_manager.get_model(model_type))
                if provider == 'bedrock':
                    system_prompt = "You are Claude, an AI assistant by Anthropic specializing in investment analysis. You provide thorough, thoughtful analysis with clear insights backed by evidence. Focus on what matters most to investors and structure your responses in a logical, easy-to-follow format."
                elif provider == 'openai':
                    system_prompt = "You are an AI assistant specializing in investment analysis. Provide clear, thorough analysis with key insights backed by evidence. Structure your response logically with numbered sections where appropriate."
            
            # Get model ID based on model_type
            model_id = await model_manager.get_model(model_type)
            logger.info(f"Selected model {model_id} for completion {completion_id}")
            
            # Log prompt size information
            estimated_tokens = await model_manager.estimate_tokens(prompt_text)
            logger.info(f"Estimated tokens for prompt: {estimated_tokens}")
            
            if estimated_tokens > 90000:
                logger.info(f"Large prompt detected ({estimated_tokens} tokens). Using ultra-context model.")
                # Only override model if it's not already ultra_context
                if model_type != 'ultra_context':
                    model_id = await model_manager.get_model('ultra_context')
                    logger.info(f"Switched to model {model_id} for large prompt")

            # Get completion from model - PASS THROUGH PARAMS
            completion = await model_manager.get_completion(
                prompt=prompt_text,
                model_id=model_id,
                max_tokens=max_tokens,
                temperature=temperature,
                use_grounding=use_grounding,
                system_prompt=system_prompt,
                use_reasoning=use_reasoning
            )

            # Update metrics
            current_processed = self.status_details.get("completions_processed", 0)
            self.status_details["completions_processed"] = current_processed + 1

            # Add completion ID
            completion["completion_id"] = completion_id

            logger.info(f"Completion {completion_id} created successfully with model {model_id}")
            return completion
        except Exception as e:
            logger.error(f"Error creating completion {completion_id}: {str(e)}")
            raise # Re-raise to be handled by the endpoint exception handler

    async def stop(self) -> bool:
        """Stop the completion service"""
        try:
            return await super().stop()
        except Exception as e:
            logger.error(f"Error stopping completion service: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Error stopping completion service: {str(e)}"
            )
            return False

# Create the singleton instance
completion_service = CompletionService()