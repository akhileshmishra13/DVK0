# backend/app/services/data_service.py

from typing import Dict, Any, Optional, List, BinaryIO, Union
import logging
import uuid
from pathlib import Path
import pymongo
from datetime import datetime # Keep this import
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorGridFSBucket, AsyncIOMotorDatabase # Added DB type hint
from app.services.base_service import BaseService, ServiceStatus
from app.core.config import settings
from app.core.exceptions import DatabaseError

logger = logging.getLogger(__name__)

class DataService(BaseService):
    """
    Service for managing document storage and retrieval
    """

    def __init__(self):
        # --- Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            self.db: Optional[AsyncIOMotorDatabase] = None # Use specific type hint
            self.gridfs: Optional[AsyncIOMotorGridFSBucket] = None

            # Call super().__init__ AFTER setting subclass attributes
            super().__init__(name="data_service", dependencies=[])

            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "documents_stored": 0,
                "connected": False
            })
            self._initialized_ = True # Mark as initialized

    async def initialize(self) -> bool:
        """Initialize database connection and GridFS"""
        try:
            # Use the MongoDB URL with explicit authSource
            mongodb_url = settings.MONGODB_URL
            if '?' not in mongodb_url and 'authSource' not in mongodb_url:
                # Append default DB name and authSource if not present
                mongodb_url = f"{mongodb_url.rstrip('/')}/{settings.MONGODB_DB_NAME}?authSource=admin"
            elif 'authSource' not in mongodb_url:
                 # Append only authSource if DB name is already in URL
                 mongodb_url = f"{mongodb_url}&authSource=admin"


            # Log connection attempt (with masked credentials)
            masked_url = mongodb_url
            if '@' in mongodb_url:
                prefix, suffix = mongodb_url.split('@', 1)
                protocol, credentials = prefix.split('://', 1)
                masked_url = f"{protocol}://*****@{suffix}"

            logger.info(f"Connecting to MongoDB at {masked_url}")

            # Connect to MongoDB with timeouts
            client = AsyncIOMotorClient(
                mongodb_url,
                connectTimeoutMS=settings.MONGODB_CONNECT_TIMEOUT_MS,
                socketTimeoutMS=settings.MONGODB_SOCKET_TIMEOUT_MS,
                serverSelectionTimeoutMS=settings.MONGODB_CONNECT_TIMEOUT_MS
            )
            # --- Assign database instance ---
            self.db = client[settings.MONGODB_DB_NAME]

            # Test the connection
            await self.db.command("ping")
            logger.info(f"Successfully pinged MongoDB server for db '{settings.MONGODB_DB_NAME}'.")

            # Initialize GridFS for document storage
            self.gridfs = AsyncIOMotorGridFSBucket(self.db)
            logger.info("GridFS initialized.")

            # Create necessary indexes
            try:
                # Index for efficient document ID lookup in metadata
                await self.db.fs.files.create_index([("metadata.document_id", pymongo.ASCENDING)], unique=True)
                logger.info("Created index on metadata.document_id.")
                # Index for sorting by upload date
                await self.db.fs.files.create_index([("uploadDate", pymongo.DESCENDING)])
                logger.info("Created index on uploadDate.")
                # Index for potential filtering by user
                await self.db.fs.files.create_index([("metadata.user_id", pymongo.ASCENDING)])
                logger.info("Created index on metadata.user_id.")
                # Index for potential filtering by document type
                await self.db.fs.files.create_index([("metadata.extracted_metadata.document_type", pymongo.ASCENDING)])
                logger.info("Created index on metadata.extracted_metadata.document_type.")

            except pymongo.errors.OperationFailure as e:
                 # Ignore "Index already exists" errors, log others
                 if "Index already exists" not in str(e) and "index options" not in str(e).lower():
                     logger.warning(f"Index creation warning (non-critical): {str(e)}")
                 else:
                     logger.info("Indexes already exist.")
            except Exception as e:
                logger.warning(f"Index creation warning (non-critical): {str(e)}")

            # Get document count
            doc_count = await self.db.fs.files.count_documents({})
            self.status_details["documents_stored"] = doc_count
            self.status_details["connected"] = True

            # Call super initialize AFTER successful connection
            initialized_base = await super().initialize()
            if not initialized_base:
                 return False

            # Update status AFTER base init
            self.update_status(
                ServiceStatus.RUNNING,
                f"Connected to MongoDB ('{settings.MONGODB_DB_NAME}') with {doc_count} documents stored in GridFS"
            )
            return True
        except pymongo.errors.ServerSelectionTimeoutError as e:
            logger.error(f"MongoDB connection timed out: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"MongoDB connection timed out: {str(e)}"
            )
            return False
        except pymongo.errors.OperationFailure as e:
            logger.error(f"MongoDB authentication/operation failure: {str(e)}")
            self.update_status(
                 ServiceStatus.ERROR,
                 f"MongoDB authentication/operation failure: {str(e)}"
            )
            return False
        except Exception as e:
            logger.error(f"Error initializing data service: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Data service initialization error: {str(e)}"
            )
            return False

    # ****** ADD THIS METHOD BACK ******
    async def store_document(self,
                            file_content: BinaryIO,
                            filename: str,
                            metadata: Dict[str, Any] = None) -> str:
        """
        Store a document in GridFS

        Args:
            file_content: The file content as bytes or file-like object
            filename: The filename
            metadata: Additional metadata

        Returns:
            The document ID (custom UUID string)
        """
        if not self.gridfs: # Check GridFS initialization
            logger.error("DataService.store_document called but GridFS is not initialized.")
            raise DatabaseError("GridFS not initialized. Cannot store document.")

        document_id = str(uuid.uuid4())
        logger.info(f"Storing document {filename} with ID {document_id}")

        try:
            # Prepare metadata
            meta = metadata or {}
            meta["original_filename"] = filename
            meta["document_id"] = document_id # Store our custom UUID here
            meta["upload_timestamp"] = datetime.utcnow() # Use proper datetime

            # Upload to GridFS - Pass our custom metadata object
            grid_id = await self.gridfs.upload_from_stream(
                filename=filename,
                source=file_content,
                metadata=meta # Ensure the whole meta dict is passed
            )

            # Update document count
            current_count = self.status_details.get("documents_stored", 0)
            self.status_details["documents_stored"] = current_count + 1

            logger.info(f"Document {filename} stored successfully with GridFS ID {grid_id}")
            return document_id # Return our custom ID
        except Exception as e:
            logger.error(f"Error storing document {filename}: {str(e)}")
            raise DatabaseError(f"Error storing document: {str(e)}")
    # ****** END OF METHOD TO ADD ******


    async def list_documents(self,
                            filters: Dict[str, Any] = None,
                            sort: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        List all documents with filtering and sorting
        """
        if self.db is None:
             logger.error("DataService.list_documents called but DB is not initialized.")
             raise DatabaseError("Database connection not initialized.")
        try:
            query = {}
            if filters:
                for key, value in filters.items():
                    if key == "search":
                        query["$or"] = [
                            {"filename": {"$regex": value, "$options": "i"}},
                            {"metadata.extracted_metadata.title": {"$regex": value, "$options": "i"}},
                            {"metadata.extracted_metadata.document_type": {"$regex": value, "$options": "i"}}
                        ]
                    elif key == "document_type":
                         query["metadata.extracted_metadata.document_type"] = value
                    elif key == "user_id":
                         query["metadata.user_id"] = value
                    else:
                        query[f"metadata.{key}"] = value

            sort_criteria = sort or {"uploadDate": -1}

            cursor = self.db.fs.files.find(query).sort(
                list(sort_criteria.items())
            )

            documents = await cursor.to_list(length=1000)

            return [
                {
                    "document_id": doc.get("metadata", {}).get("document_id", str(doc["_id"])),
                    "filename": doc.get("filename"),
                    "length": doc.get("length"),
                    "upload_date": doc.get("uploadDate"),
                    "metadata": doc.get("metadata", {})
                }
                for doc in documents
            ]
        except Exception as e:
            logger.error(f"Error listing documents: {str(e)}")
            raise DatabaseError(f"Error listing documents: {str(e)}")

    async def get_document(self, document_id: str) -> Optional[Dict[str, Any]]:
        """
        Get document metadata by OUR custom document_id stored in metadata
        """
        if self.db is None:
             logger.error("DataService.get_document called but DB is not initialized.")
             raise DatabaseError("Database connection not initialized.")
        try:
            document = await self.db.fs.files.find_one({"metadata.document_id": document_id})

            if not document:
                logger.warning(f"Document with ID {document_id} not found in GridFS.")
                return None

            return {
                "document_id": document.get("metadata", {}).get("document_id", document_id),
                "filename": document.get("filename"),
                "length": document.get("length"),
                "upload_date": document.get("uploadDate"),
                "metadata": document.get("metadata", {})
            }
        except Exception as e:
            logger.error(f"Error retrieving document metadata for {document_id}: {str(e)}")
            raise DatabaseError(f"Error retrieving document metadata: {str(e)}")

    async def get_document_content(self, document_id: str) -> Optional[bytes]:
        if self.db is None or self.gridfs is None:
            logger.error("DataService.get_document_content called but DB/GridFS is not initialized.")
            raise DatabaseError("Database/GridFS connection not initialized.")
        try:
            file_doc = await self.db.fs.files.find_one({"metadata.document_id": document_id})
            if not file_doc:
                 logger.warning(f"File metadata not found for document ID {document_id}.")
                 return None
            file_id = file_doc["_id"]
            grid_out = await self.gridfs.open_download_stream(file_id)
            content = await grid_out.read()
            logger.info(f"Retrieved content for document {document_id} (length: {len(content)} bytes).")
            return content
        except Exception as e:
             logger.error(f"Error retrieving document content for {document_id}: {str(e)}")
             raise DatabaseError(f"Error retrieving document content: {str(e)}")


    async def update_document_metadata(self, document_id: str, metadata_updates: Dict[str, Any]) -> bool:
        if self.db is None:
            logger.error("DataService.update_document_metadata called but DB is not initialized.")
            raise DatabaseError("Database connection not initialized.")
        try:
            updates = {f"metadata.{key}": value for key, value in metadata_updates.items()}
            updates["metadata.updated_at"] = datetime.utcnow() # Also add an updated timestamp within metadata

            result = await self.db.fs.files.update_one(
                {"metadata.document_id": document_id},
                {"$set": updates}
            )
            if result.matched_count == 0:
                 logger.warning(f"No document found with ID {document_id} to update metadata.")
                 return False

            logger.info(f"Updated metadata for document {document_id}. Modified count: {result.modified_count}")
            return result.modified_count > 0
        except Exception as e:
             logger.error(f"Error updating document metadata for {document_id}: {str(e)}")
             raise DatabaseError(f"Error updating document metadata: {str(e)}")


    async def count_documents(self, filters: Dict[str, Any] = None) -> int:
        if self.db is None:
            logger.error("DataService.count_documents called but DB is not initialized.")
            raise DatabaseError("Database connection not initialized.")
        try:
            query = {}
            if filters:
                 for key, value in filters.items():
                      if key == "document_type":
                           query["metadata.extracted_metadata.document_type"] = value
                      elif key == "user_id":
                           query["metadata.user_id"] = value

            count = await self.db.fs.files.count_documents(query)
            return count
        except Exception as e:
             logger.error(f"Error counting documents: {str(e)}")
             raise DatabaseError(f"Failed to count documents: {str(e)}")

    async def delete_document(self, document_id: str) -> bool:
        if self.db is None or self.gridfs is None:
            logger.error("DataService.delete_document called but DB/GridFS is not initialized.")
            raise DatabaseError("Database/GridFS connection not initialized.")
        try:
            file_doc = await self.db.fs.files.find_one({"metadata.document_id": document_id})
            if not file_doc:
                logger.warning(f"Document {document_id} not found for deletion.")
                return False
            await self.gridfs.delete(file_doc["_id"])
            logger.info(f"Deleted document {document_id} (GridFS ID: {file_doc['_id']}) successfully.")
            current_count = self.status_details.get("documents_stored", 0)
            self.status_details["documents_stored"] = max(0, current_count - 1)
            return True
        except Exception as e:
            logger.error(f"Error deleting document {document_id}: {str(e)}")
            raise DatabaseError(f"Error deleting document: {str(e)}")


    async def stop(self) -> bool:
        """Stop the data service"""
        try:
            # Close MongoDB connection if client exists
            if self.db and hasattr(self.db, "client"):
                self.db.client.close()
                logger.info("MongoDB connection closed.")

            self.status_details["connected"] = False
            return await super().stop()
        except Exception as e:
            logger.error(f"Error stopping data service: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Error stopping data service: {str(e)}"
            )
            return False

# Create the singleton instance
data_service = DataService()