# backend/app/services/prompt_system.py
from typing import Dict, Any, Optional, List
import logging
import json
from pathlib import Path
from app.services.base_service import BaseService, ServiceStatus
from app.core.exceptions import ValidationError
from pydantic import ValidationError as PydanticValidationError

logger = logging.getLogger(__name__)

class PromptTemplate:
    def __init__(self, 
                template_id: str, 
                content: str, 
                display_name: str,
                description: str,
                required_variables: List[str] = None,
                category: str = None,
                subcategory: str = None):
        self.template_id = template_id
        self.content = content
        self.display_name = display_name
        self.description = description
        self.required_variables = required_variables or []
        self.category = category
        self.subcategory = subcategory
    
    def format(self, **kwargs) -> str:
        """Format the template with the provided variables"""
        # Check that all required variables are provided
        missing_vars = [var for var in self.required_variables if var not in kwargs]
        if missing_vars:
            raise ValidationError(f"Missing required variables for template {self.template_id}: {missing_vars}")
        
        # Format the template
        return self.content.format(**kwargs)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert template to dictionary representation"""
        return {
            "template_id": self.template_id,
            "display_name": self.display_name,
            "description": self.description,
            "content": self.content,
            "required_variables": self.required_variables,
            "category": self.category,
            "subcategory": self.subcategory
        }

class PromptSystem(BaseService):
    """
    Service for managing prompt templates and generating prompts
    """
    
    def __init__(self):
        # --- FIXED: Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            # Initialize attributes before calling super().__init__
            self.templates = {}
            self.categories = {}
            
            # Call super().__init__ AFTER setting subclass attributes
            super().__init__(name="prompt_system", dependencies=["model_manager"])
            
            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "templates_loaded": 0,
                "categories_count": 0,
                "initialized": False
            })
            self._initialized_ = True # Mark as initialized
    
    async def initialize(self) -> bool:
        """Initialize prompt templates"""
        try:
            # Load prompts from library
            library_path = Path(__file__).parent.parent / "data" / "prompt_library.json"
            if library_path.exists():
                await self.load_prompt_library(library_path)
            else:
                # Create default prompt library
                await self.create_default_prompt_library()
            
            self.status_details["initialized"] = True
            self.status_details["templates_loaded"] = len(self.templates)
            self.status_details["categories_count"] = len(self.categories)
            
            self.update_status(
                ServiceStatus.RUNNING,
                f"Prompt system initialized with {len(self.templates)} templates in {len(self.categories)} categories"
            )
            return await super().initialize()
        except Exception as e:
            logger.error(f"Error initializing prompt system: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Prompt system initialization error: {str(e)}"
            )
            return False
    
    async def load_prompt_library(self, file_path: Path) -> None:
        """Load prompts from the prompt library JSON file"""
        try:
            content = file_path.read_text()
            library_data = json.loads(content)
            
            # Process each category
            for category, subcategories in library_data.items():
                # Initialize category in categories dict if not exists
                if category not in self.categories:
                    self.categories[category] = {}
                
                # Process each subcategory
                for subcategory, template_data in subcategories.items():
                    # Initialize subcategory in categories dict if not exists
                    if subcategory not in self.categories[category]:
                        self.categories[category][subcategory] = []
                    
                    # Use the template name as the template_id component
                    # This creates IDs like "deal_evaluation.financial_analysis.financial_analysis"
                    template_name = template_data.get("name", subcategory)
                    full_template_id = f"{category}.{subcategory}.{template_name}"
                    
                    # Create template object
                    template = PromptTemplate(
                        template_id=full_template_id,
                        content=template_data["template"],
                        display_name=template_data["display_name"],
                        description=template_data["description"],
                        required_variables=template_data.get("required_variables", []),
                        category=category,
                        subcategory=subcategory
                    )
                    
                    # Add to templates dict
                    self.templates[full_template_id] = template
                    
                    # Add to categories structure
                    self.categories[category][subcategory].append(full_template_id)
            
            logger.info(f"Loaded {len(self.templates)} templates from prompt library")
        except Exception as e:
            logger.error(f"Error loading prompt library from {file_path}: {str(e)}")
            raise
    
    async def create_default_prompt_library(self) -> None:
        """Create default prompt library JSON file"""
        library_path = Path(__file__).parent.parent / "data" / "prompt_library.json"
        library_path.parent.mkdir(exist_ok=True)
        
        # Default prompt library structure with minimal templates
        default_library = {
            "deal_evaluation": {
                "financial_analysis": {
                    "basic_analysis": {
                        "name": "basic_analysis",
                        "display_name": "Basic Financial Analysis",
                        "template": "Analyze the financial aspects of this investment opportunity:\n\n{deal_details}",
                        "description": "Basic financial analysis of an investment opportunity",
                        "required_variables": ["deal_details"]
                    }
                }
            },
            "system": {
                "core": {
                    "system_core": {
                        "name": "system_core",
                        "display_name": "System Core",
                        "template": "You are AIDE (AI Deal Evaluation), a sophisticated investment analysis system for Keppel.",
                        "description": "Core system prompt defining AIDE's behavior",
                        "required_variables": []
                    }
                }
            }
        }
        
        # Write default library to file
        library_path.write_text(json.dumps(default_library, indent=2))
        
        # Load the created library
        await self.load_prompt_library(library_path)
        
        logger.info("Created default prompt library")
    
    async def get_prompt(self, template_id: str, **kwargs) -> str:
        """Get a formatted prompt by template ID"""
        if template_id not in self.templates:
            raise ValidationError(f"Template with ID {template_id} not found")
        
        return self.templates[template_id].format(**kwargs)
    
    async def get_all_templates(self, 
                            category: Optional[str] = None,
                            subcategory: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
        """
        Get all templates with optional filtering
        
        Args:
            category: Optional category filter
            subcategory: Optional subcategory filter
            
        Returns:
            Dictionary of templates
        """
        # First get all templates
        all_templates = {
            template_id: template.to_dict()
            for template_id, template in self.templates.items()
        }
        
        # Apply filtering if requested
        if category and subcategory:
            return {k: v for k, v in all_templates.items() 
                    if k.startswith(f"{category}.{subcategory}")}
        elif category:
            return {k: v for k, v in all_templates.items() 
                    if k.startswith(f"{category}.")}
        else:
            return all_templates
    
    async def get_categories(self) -> Dict[str, Dict[str, List[Dict[str, Any]]]]:
        """Get all categories with template information"""
        result = {}
        
        for category, subcategories in self.categories.items():
            result[category] = {}
            
            for subcategory, template_ids in subcategories.items():
                result[category][subcategory] = [
                    self.templates[template_id].to_dict()
                    for template_id in template_ids
                ]
        
        return result
    
    async def get_template(self, template_id: str) -> Dict[str, Any]:
        """Get template details by ID"""
        if template_id not in self.templates:
            raise ValidationError(f"Template with ID {template_id} not found")
        
        return self.templates[template_id].to_dict()
    
    async def stop(self) -> bool:
        """Stop the prompt system"""
        try:
            return await super().stop()
        except Exception as e:
            logger.error(f"Error stopping prompt system: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Error stopping prompt system: {str(e)}"
            )
            return False

# Create the singleton instance
prompt_system = PromptSystem()