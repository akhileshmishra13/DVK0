# app/handlers.py

import logging
from fastapi import Request, HTTPException, status, FastAPI
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from app.utils.response_util import ResponseUtil
from app.core.exceptions import BaseAPIException

logger = logging.getLogger(__name__)

def register_exception_handlers(app: FastAPI):
    """Register all global exception handlers with the FastAPI app"""

    @app.exception_handler(BaseAPIException)
    async def base_api_exception_handler(request: Request, exc: BaseAPIException):
        logger.error(
            f"{exc.status_code} {exc.__class__.__name__}: {request.method} {request.url} - {exc.message}",
            extra={"detail": exc.detail}
        )
        return await ResponseUtil.error_response(
            message=exc.message,
            error_code=exc.code,
            error_detail=exc.detail,
            status_code=exc.status_code
        )

    @app.exception_handler(404)
    async def not_found_handler(request: Request, exc: HTTPException):
        logger.warning(f"404 Not Found: {request.method} {request.url}")
        return await ResponseUtil.error_response(
            message="The requested resource was not found",
            error_code="NOT_FOUND",
            error_detail=f"{request.method} {request.url.path}",
            status_code=404
        )

    @app.exception_handler(401)
    async def unauthorized_handler(request: Request, exc: HTTPException):
        logger.warning(f"401 Unauthorized: {request.method} {request.url}")
        return await ResponseUtil.error_response(
            message="Unauthorized",
            error_code="UNAUTHORIZED",
            error_detail=exc.detail or "Authentication required",
            status_code=401
        )

    @app.exception_handler(403)
    async def forbidden_handler(request: Request, exc: HTTPException):
        logger.warning(f"403 Forbidden: {request.method} {request.url}")
        return await ResponseUtil.error_response(
            message="Forbidden",
            error_code="FORBIDDEN",
            error_detail=exc.detail or "Access denied",
            status_code=403
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        logger.warning(f"422 Validation Error: {request.method} {request.url} - {exc.errors()}")
        return await ResponseUtil.error_response(
            message="Validation error",
            error_code="VALIDATION_ERROR",
            error_detail="One or more fields failed validation",
            additional_info={"errors": exc.errors()},
            status_code=422
        )

    @app.exception_handler(Exception)
    async def internal_server_error_handler(request: Request, exc: Exception):
        logger.error(f"500 Internal Server Error: {request.method} {request.url} - {str(exc)}", exc_info=True)
        return await ResponseUtil.error_response(
            message="Internal server error",
            error_code="INTERNAL_ERROR",
            error_detail=str(exc),
            status_code=500
        )

    @app.exception_handler(StarletteHTTPException)
    async def starlette_http_exception_handler(request: Request, exc: StarletteHTTPException):
        if exc.status_code == 404:
            return await not_found_handler(request, exc)
        elif exc.status_code == 401:
            return await unauthorized_handler(request, exc)
        elif exc.status_code == 403:
            return await forbidden_handler(request, exc)
        else:
            logger.warning(f"{exc.status_code} HTTPException: {request.method} {request.url} - {exc.detail}")
            return await ResponseUtil.error_response(
                message=exc.detail or "An error occurred",
                error_code="HTTP_ERROR",
                error_detail=str(exc.detail),
                status_code=exc.status_code
            )
