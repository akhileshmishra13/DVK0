# app/utils/bson_utils.py

from bson import json_util
import json
from typing import Any

def serialize_bson(obj: Any) -> Any:
    """
    Convert any MongoDB-returned object (including datetime, ObjectId, etc.)
    into a JSON-serializable Python object.
    """
    return json.loads(json_util.dumps(obj))
