# backend/app/utils/logging_context.py
import contextvars
import uuid
from typing import Optional, Dict, Any

# Context variables to store request-specific data
request_id_var = contextvars.ContextVar('request_id', default=None)
user_id_var = contextvars.ContextVar('user_id', default=None)
correlation_id_var = contextvars.ContextVar('correlation_id', default=None)
session_data_var = contextvars.ContextVar('session_data', default={})

class LoggingContext:
    """
    Context manager for managing logging context in request handling
    """
    def __init__(self, 
                 request_id: Optional[str] = None, 
                 user_id: Optional[str] = None,
                 correlation_id: Optional[str] = None):
        self.request_id = request_id or str(uuid.uuid4())
        self.user_id = user_id
        self.correlation_id = correlation_id or self.request_id
        self.token = None
        self.user_token = None
        self.corr_token = None
        
    def __enter__(self):
        # Set context variables
        self.token = request_id_var.set(self.request_id)
        if self.user_id:
            self.user_token = user_id_var.set(self.user_id)
        if self.correlation_id:
            self.corr_token = correlation_id_var.set(self.correlation_id)
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        # Reset context variables
        request_id_var.reset(self.token)
        if self.user_id:
            user_id_var.reset(self.user_token)
        if self.correlation_id:
            correlation_id_var.reset(self.corr_token)
            
    @staticmethod
    def get_request_id() -> Optional[str]:
        """Get the current request ID"""
        return request_id_var.get()
    
    @staticmethod
    def get_user_id() -> Optional[str]:
        """Get the current user ID"""
        return user_id_var.get()
    
    @staticmethod
    def get_correlation_id() -> Optional[str]:
        """Get the current correlation ID"""
        return correlation_id_var.get()
    
    @staticmethod
    def set_session_data(key: str, value: Any) -> None:
        """Set a session data value"""
        data = session_data_var.get().copy()
        data[key] = value
        session_data_var.set(data)
    
    @staticmethod
    def get_session_data(key: str, default: Any = None) -> Any:
        """Get a session data value"""
        return session_data_var.get().get(key, default)