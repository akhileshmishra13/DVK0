# app/utils/response_util.py

from datetime import datetime
from typing import Any, Dict, Optional, List, Union
from fastapi import Response, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from app.utils.logging_context import LoggingContext
from app.core.config import settings
from app.utils.bson_utils import serialize_bson

class ResponseMetadata(BaseModel):
    """Standard response metadata"""
    request_id: Optional[str] = Field(None, description="Request correlation ID")
    api_version: str = Field(..., description="API version")
    execution_time_ms: Optional[float] = Field(None, description="Execution time in milliseconds")

    class Config:
        arbitrary_types_allowed = True

class ErrorDetail(BaseModel):
    """Detailed error information"""
    code: str = Field(..., description="Error code")
    detail: str = Field("", description="Error details")
    source: Optional[str] = Field(None, description="Error source")
    params: Optional[Dict[str, Any]] = Field(None, description="Error parameters")

class ResponseUtil:
    """Utility class for standardized API responses"""

    @staticmethod
    async def success_response(
        data: Any = None,
        message: str = "Operation successful",
        metadata: Optional[Dict] = None,
        status_code: int = status.HTTP_200_OK,
        headers: Optional[Dict[str, str]] = None,
        execution_time_ms: Optional[float] = None
    ) -> JSONResponse:
        """Generate a standardized success response with appropriate HTTP status code"""
        request_id = LoggingContext.get_request_id()

        response_metadata = {
            "request_id": request_id,
            "api_version": settings.API_VERSION,
            "execution_time_ms": execution_time_ms
        }

        if metadata:
            response_metadata.update(metadata)

        content = {
            "status": "success",
            "message": message,
            "data": serialize_bson(data),
            "metadata": response_metadata,
            "timestamp": datetime.utcnow().isoformat()
        }

        return JSONResponse(
            content=content,
            status_code=status_code,
            headers=headers
        )

    @staticmethod
    async def error_response(
        message: str = "An error occurred",
        error_code: str = "INTERNAL_ERROR",
        error_detail: str = "",
        additional_info: Optional[Dict] = None,
        status_code: int = status.HTTP_400_BAD_REQUEST,
        headers: Optional[Dict[str, str]] = None,
        execution_time_ms: Optional[float] = None
    ) -> JSONResponse:
        """Generate a standardized error response with appropriate HTTP status code"""
        request_id = LoggingContext.get_request_id()

        error_metadata = {
            "request_id": request_id,
            "api_version": settings.API_VERSION,
            "execution_time_ms": execution_time_ms,
            "error": {
                "code": error_code,
                "detail": error_detail
            }
        }

        if additional_info:
            error_metadata["error"]["additional_info"] = serialize_bson(additional_info)

        content = {
            "status": "error",
            "message": message,
            "data": None,
            "metadata": error_metadata,
            "timestamp": datetime.utcnow().isoformat()
        }

        if status_code == status.HTTP_400_BAD_REQUEST:
            if error_code == "NOT_FOUND":
                status_code = status.HTTP_404_NOT_FOUND
            elif error_code == "UNAUTHORIZED":
                status_code = status.HTTP_401_UNAUTHORIZED
            elif error_code == "FORBIDDEN":
                status_code = status.HTTP_403_FORBIDDEN
            elif error_code == "VALIDATION_ERROR":
                status_code = status.HTTP_422_UNPROCESSABLE_ENTITY
            elif error_code == "CONFLICT":
                status_code = status.HTTP_409_CONFLICT
            elif error_code == "RATE_LIMIT_EXCEEDED":
                status_code = status.HTTP_429_TOO_MANY_REQUESTS

        return JSONResponse(
            content=content,
            status_code=status_code,
            headers=headers
        )

    @staticmethod
    async def list_response(
        items: List[Any],
        message: str = "Items retrieved successfully",
        metadata: Optional[Dict] = None,
        status_code: int = status.HTTP_200_OK,
        headers: Optional[Dict[str, str]] = None,
        execution_time_ms: Optional[float] = None
    ) -> JSONResponse:
        return await ResponseUtil.success_response(
            data=items,
            message=message,
            metadata=metadata,
            status_code=status_code,
            headers=headers,
            execution_time_ms=execution_time_ms
        )

    @staticmethod
    async def from_exception(
        exception: Exception,
        message: Optional[str] = None,
        status_code: Optional[int] = None,
        headers: Optional[Dict[str, str]] = None,
        execution_time_ms: Optional[float] = None
    ) -> JSONResponse:
        from app.core.exceptions import BaseAPIException
        if isinstance(exception, BaseAPIException):
            return await ResponseUtil.error_response(
                message=message or exception.message,
                error_code=exception.code,
                error_detail=exception.detail,
                status_code=status_code or exception.status_code,
                headers=headers,
                execution_time_ms=execution_time_ms
            )

        from pydantic import ValidationError as PydanticValidationError
        if isinstance(exception, PydanticValidationError):
            return await ResponseUtil.error_response(
                message=message or "Validation error",
                error_code="VALIDATION_ERROR",
                error_detail=str(exception),
                additional_info={"errors": exception.errors()},
                status_code=status_code or status.HTTP_422_UNPROCESSABLE_ENTITY,
                headers=headers,
                execution_time_ms=execution_time_ms
            )

        from fastapi import HTTPException
        if isinstance(exception, HTTPException):
            return await ResponseUtil.error_response(
                message=message or exception.detail,
                error_code="HTTP_ERROR",
                error_detail=str(exception.detail),
                status_code=status_code or exception.status_code,
                headers=headers or exception.headers,
                execution_time_ms=execution_time_ms
            )

        return await ResponseUtil.error_response(
            message=message or "Internal server error",
            error_code="INTERNAL_ERROR",
            error_detail=str(exception),
            status_code=status_code or status.HTTP_500_INTERNAL_SERVER_ERROR,
            headers=headers,
            execution_time_ms=execution_time_ms
        )

    @staticmethod
    async def health_response(
        status_details: Dict[str, Any],
        message: str = "System health check",
        status_code: int = status.HTTP_200_OK
    ) -> JSONResponse:
        overall_status = "healthy"
        if status_details.get("status") == "error" or \
           (status_details.get("services") and status_details["services"].get("error", 0) > 0):
            overall_status = "unhealthy"
            status_code = status.HTTP_503_SERVICE_UNAVAILABLE
        elif status_details.get("status") == "degraded" or \
             (status_details.get("services") and status_details["services"].get("initializing", 0) > 0):
            overall_status = "degraded"

        request_id = LoggingContext.get_request_id()

        content = {
            "status": overall_status,
            "message": message,
            "data": serialize_bson(status_details),
            "metadata": {
                "request_id": request_id,
                "api_version": settings.API_VERSION,
                "timestamp": datetime.utcnow().isoformat()
            }
        }

        return JSONResponse(
            content=content,
            status_code=status_code
        )

    @staticmethod
    async def system_status_response(
        services: List[Dict[str, Any]],
        system_metadata: Dict[str, Any],
        message: str = "System status retrieved successfully",
        status_code: int = status.HTTP_200_OK,
        execution_time_ms: Optional[float] = None
    ) -> JSONResponse:
        request_id = LoggingContext.get_request_id()

        content = {
            "status": "success",
            "message": message,
            "data": {
                "services": serialize_bson(services),
                "metadata": serialize_bson(system_metadata)
            },
            "metadata": {
                "request_id": request_id,
                "api_version": settings.API_VERSION,
                "execution_time_ms": execution_time_ms
            },
            "timestamp": datetime.utcnow().isoformat()
        }

        return JSONResponse(
            content=content,
            status_code=status_code
        )
