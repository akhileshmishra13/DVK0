# backend/app/core/singletons.py 
"""
Singleton service instances for the application
"""
# Import service classes for type hinting
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from app.services.base_service import BaseService
    from app.services.model_manager import ModelManager
    from app.services.prompt_system import PromptSystem
    from app.services.completion_service import CompletionService
    from app.services.data_service import DataService
    from app.services.event_handler import EventHandler
    from app.services.system_service import SystemService
    from app.services.extraction_service import ExtractionService
    from app.services.logging_service import LoggingService

# Import service instances (these will be imported from their modules)
from app.services.logging_service import logging_service
from app.services.system_service import system_service
from app.services.model_manager import model_manager
from app.services.prompt_system import prompt_system
from app.services.completion_service import completion_service
from app.services.data_service import data_service
from app.services.event_handler import event_handler
from app.services.extraction_service import extraction_service

# Order of initialization (respecting dependencies)
SERVICES_INIT_ORDER: List['BaseService'] = [
    logging_service,  # Initialize logging first
    system_service,
    model_manager,
    data_service,
    event_handler,
    prompt_system,
    completion_service,
    extraction_service
]

# Export all for public use
__all__ = [
    "logging_service",  
    "system_service", 
    "model_manager", 
    "prompt_system",
    "completion_service", 
    "data_service", 
    "event_handler",
    "extraction_service",
    "SERVICES_INIT_ORDER"
]