# backend/app/core/service_init.py
import logging
from fastapi import FastAPI
from app.core.registry import get_service, get_all_services
from app.core.config import settings

# Import service modules to ensure singletons are created
from app.services.logging_service import logging_service  # Import logging service first
from app.services.system_service import system_service  
from app.services.model_manager import model_manager
from app.services.prompt_system import prompt_system
from app.services.completion_service import completion_service
from app.services.data_service import data_service
from app.services.event_handler import event_handler
from app.services.extraction_service import extraction_service

logger = logging.getLogger(__name__)

async def initialize_services(app: FastAPI) -> None:
    """Initialize all application services on startup"""
    logger.info("Initializing application services")
    
    try:
        # Initialize logging service first to ensure proper logging
        logger.info("Initializing logging service first")
        success = await logging_service.initialize()
        
        if not success:
            logger.error("Failed to initialize logging service")
            # Continue with basic logging - don't return early
        
        # Log configuration to verify settings are loaded
        logger.info(f"MongoDB URL: {settings.MONGODB_URL.split('@')[0]}@***")
        logger.info(f"Google API Key configured: {'Yes' if settings.GOOGLE_API_KEY else 'No'}")
        logger.info(f"Primary Model: {settings.PRIMARY_MODEL}")
        logger.info(f"Ultra Context Model: {settings.ULTRA_CONTEXT_MODEL}")
        
        # Get system service
        system = get_service("system_service")
        
        # Set initialization order - add logging_service first in initialization order
        system.set_initialization_order([
            "logging_service",  # Initialize logging first
            "system_service",
            "model_manager",
            "data_service",
            "event_handler", 
            "prompt_system",
            "completion_service",
            "extraction_service"
        ])
        
        # Initialize system service
        await system.initialize()
        
        # Store system_service in app state for shutdown
        app.state.system_service = system
        
        # Then let it initialize all other services
        try:
            success = await system.initialize_all_services()
            
            if success:
                logger.info("All services initialized successfully")
            else:
                logger.error("Service initialization failed")
        except Exception as e:
            logger.error(f"Error initializing services: {str(e)}")
            
    except Exception as e:
        logger.error(f"Error during service initialization: {str(e)}")

async def shutdown_services(app: FastAPI) -> None:
    """Shutdown all application services on application shutdown"""
    logger.info("Shutting down application services")
    
    try:
        system = app.state.system_service
        
        # Get all services reversed
        services_in_reverse = [name for name in reversed(system.initialization_order)]
        all_services = get_all_services()
        
        # Shutdown each service
        for name in services_in_reverse:
            try:
                if name in all_services:
                    service = all_services[name]
                    logger.info(f"Stopping service: {name}")
                    await service.stop()
                    logger.info(f"Service {name} stopped successfully")
            except Exception as e:
                logger.error(f"Error stopping service {name}: {str(e)}")
    except Exception as e:
        logger.error(f"Error during service shutdown: {str(e)}")