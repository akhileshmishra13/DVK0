# backend/app/core/registry.py
"""
Service registry for storing and retrieving service singletons
"""
from typing import Dict, Any

# Global service registry
_registry: Dict[str, Any] = {}

def register_service(name: str, service: Any) -> None:
    """Register a service in the registry"""
    _registry[name] = service

def get_service(name: str) -> Any:
    """Get a service from the registry"""
    if name not in _registry:
        raise KeyError(f"Service '{name}' not found in registry")
    return _registry[name]

def get_all_services() -> Dict[str, Any]:
    """Get all registered services"""
    return _registry.copy()