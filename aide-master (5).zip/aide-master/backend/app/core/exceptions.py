# backend/app/core/exceptions.py 

from fastapi import status
from app.utils.logging_context import LoggingContext

class BaseAPIException(Exception):
    """Base exception for API errors"""
    def __init__(
        self, 
        message="An error occurred", 
        code="INTERNAL_ERROR", 
        detail="",
        status_code=status.HTTP_400_BAD_REQUEST
    ):
        self.message = message
        self.code = code
        self.detail = detail
        self.status_code = status_code
        super().__init__(self.message)
        
        # Log the exception using the logging context
        try:
            from app.core.registry import get_service
            logging_service = get_service("logging_service")
            
            # Get request context if available
            request_id = LoggingContext.get_request_id()
            user_id = LoggingContext.get_user_id()
            correlation_id = LoggingContext.get_correlation_id()
            
            # Log the exception
            logging_service.log(
                level="error",
                message=f"Exception {code}: {message} - {detail}",
                module="exceptions",
                request_id=request_id,
                user_id=user_id,
                correlation_id=correlation_id,
                exception_code=code,
                exception_detail=detail,
                status_code=status_code
            )
        except (ImportError, KeyError):
            # If logging service is not available, we can't log
            pass

# Update specific exception classes with status codes
class DatabaseError(BaseAPIException):
    """Database operation error"""
    def __init__(self, message="Database error", detail=""):
        super().__init__(
            message, 
            "DATABASE_ERROR", 
            detail,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

class AuthenticationError(BaseAPIException):
    """Authentication error"""
    def __init__(self, message="Authentication error", detail=""):
        super().__init__(
            message, 
            "AUTH_ERROR", 
            detail,
            status_code=status.HTTP_401_UNAUTHORIZED
        )

class ValidationError(BaseAPIException):
    """Data validation error"""
    def __init__(self, message="Validation error", detail=""):
        super().__init__(
            message, 
            "VALIDATION_ERROR", 
            detail,
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY
        )

class AIModelError(BaseAPIException):
    """AI model error"""
    def __init__(self, message="AI model error", detail=""):
        super().__init__(
            message, 
            "AI_MODEL_ERROR", 
            detail,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

class ResourceNotFoundError(BaseAPIException):
    """Resource not found error"""
    def __init__(self, message="Resource not found", detail=""):
        super().__init__(
            message, 
            "NOT_FOUND", 
            detail,
            status_code=status.HTTP_404_NOT_FOUND
        )