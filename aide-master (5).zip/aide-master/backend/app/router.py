# app/router.py

from fastapi import APIRouter, FastAPI
from app.api.v1.document import document_router
from app.api.v1.extraction import extraction_router
from app.api.v1.completion import completion_router
from app.api.v1.prompts import prompt_router
from app.api.v1.system import system_router
from app.api.auth.login import router as login_router

# Create the main API router
api_router = APIRouter()

# Include all domain-specific routers
api_router.include_router(document_router, prefix="/document", tags=["document"])
api_router.include_router(extraction_router, prefix="/extraction", tags=["extraction"])
api_router.include_router(completion_router, prefix="/completion", tags=["completion"])
api_router.include_router(prompt_router, prefix="/prompts", tags=["prompts"])
api_router.include_router(system_router, prefix="/system", tags=["system"])

def init_routes(app: FastAPI):
    """Initialize all routes with the app"""
    # API V1 endpoints
    app.include_router(api_router, prefix="/api/v1")
    
    # Auth endpoints 
    app.include_router(login_router, prefix="/auth/login", tags=["auth"])