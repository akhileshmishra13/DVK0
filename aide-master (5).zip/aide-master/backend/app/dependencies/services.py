# backend/app/dependencies/services.py
"""
Service dependency injection for FastAPI endpoints
"""
from app.core.registry import get_service

# Simple dependency functions that return singleton instances
def get_system_service():
    return get_service("system_service")

def get_model_manager():
    return get_service("model_manager")

def get_prompt_system():
    return get_service("prompt_system")

def get_completion_service():
    return get_service("completion_service")

def get_data_service():
    return get_service("data_service")

def get_event_handler():
    return get_service("event_handler")

def get_extraction_service():
    return get_service("extraction_service")

def get_logging_service():
    return get_service("logging_service")