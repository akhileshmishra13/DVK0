# backend/app/api/auth/login.py
from fastapi import APIRouter, HTTPException, status, Response
from app.models.auth import Token, UserLogin
from app.utils.auth_utils import get_cognito_user
import logging

router = APIRouter()

@router.post("/", response_model=None)
async def login(user_data: UserLogin, response: Response):
    """User login endpoint"""
    try:
        logging.info(f"Login attempt for user: {user_data.email}")
        
        # FIX: Add 'await' keyword here
        auth_result = await get_cognito_user(user_data.email, user_data.password)
        
        # Add CORS headers explicitly
        response.headers["Access-Control-Allow-Origin"] = "*" 
        response.headers["Access-Control-Allow-Methods"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "*"
        
        # Return simple dictionary
        return {
            "status": "success",
            "data": {
                "access_token": auth_result["AccessToken"],
                "token_type": "bearer",
                "expires_in": auth_result["ExpiresIn"],
                "id_token": auth_result.get("IdToken"),
                "refresh_token": auth_result.get("RefreshToken")
            }
        }
    except HTTPException as http_ex:
        # Add CORS headers to error responses
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Methods"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "*"
        
        logging.error(f"Authentication error: {http_ex.detail}")
        return {
            "status": "error",
            "message": str(http_ex.detail)
        }
    except Exception as e:
        # Add CORS headers to error responses
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Methods"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "*"
        
        logging.error(f"Unexpected error during login: {str(e)}")
        return {
            "status": "error",
            "message": str(e)
        }