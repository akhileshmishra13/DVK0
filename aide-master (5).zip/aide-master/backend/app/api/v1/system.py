# backend/app/api/v1/system.py

from fastapi import APIRouter, Depends, Query, status
from typing import List, Dict, Any, Optional
import platform
import os
import datetime
import time
import logging

from app.services.base_service import ServiceInfo
from app.utils.response_util import ResponseUtil
from app.dependencies.services import get_system_service, get_logging_service
from app.core.config import settings

logger = logging.getLogger(__name__)

# Create independent router 
system_router = APIRouter()

@system_router.get("/status")
async def get_system_status():
    """Get the status of all system services"""
    try:
        # Record start time for execution timing
        start_time = time.time()
        
        # Access system_service directly from dependencies
        system_service = get_system_service()
        logging_service = get_logging_service()
        
        # Get data service for database information
        from app.core.registry import get_service
        data_service = get_service("data_service")
        
        # Determine if using DocumentDB from connection URL
        is_documentdb = False
        db_url = settings.MONGODB_URL.lower()
        if "documentdb" in db_url or "docdb" in db_url or ".docdb." in db_url:
            is_documentdb = True
        
        # Create sanitized database info from data_service status
        # Using data from the existing status_details
        db_info = {
            "type": "MongoDB", 
            "name": settings.MONGODB_DB_NAME,
            "host": settings.MONGODB_URL.split('@')[-1].split('/')[0] if '@' in settings.MONGODB_URL else "localhost",
            "document_count": data_service.status_details.get("documents_stored", 0),
            "is_documentdb": is_documentdb,
            "db_system": "Amazon DocumentDB" if is_documentdb else "MongoDB"
        }
        
        # Log the request for status
        logging_service.log(
            "info",
            "System status requested",
            "system_api"
        )
        
        # Get all service statuses
        all_statuses = system_service.get_all_service_statuses()
        
        # Add system metadata
        metadata = {
            "system": {
                "python_version": platform.python_version(),
                "environment": os.environ.get("API_ENV", "development"),
                "hostname": platform.node(),
                "start_time": getattr(system_service, "start_time", datetime.datetime.now().isoformat()),
                "uptime_seconds": getattr(system_service, "uptime_seconds", 0),
                "version": settings.PROJECT_VERSION
            },
            "database": db_info,
            "services": {
                "total": len(all_statuses),
                "running": len([s for s in all_statuses if s.status == "running"]),
                "error": len([s for s in all_statuses if s.status == "error"]),
                "initializing": len([s for s in all_statuses if s.status == "initializing"]),
                "stopped": len([s for s in all_statuses if s.status == "stopped"])
            }
        }
        
        # Calculate execution time
        execution_time_ms = (time.time() - start_time) * 1000
        
        # Use the specialized system status response method
        return await ResponseUtil.system_status_response(
            services=[status.dict() for status in all_statuses],
            system_metadata=metadata,
            message="System status retrieved successfully",
            execution_time_ms=execution_time_ms
        )
    except Exception as e:
        logging_service = get_logging_service()
        logging_service.log(
            "error",
            f"Failed to retrieve system status: {str(e)}",
            "system_api",
            error=str(e)
        )
        
        # For errors, we still use the standard error response
        return await ResponseUtil.error_response(
            message="Failed to retrieve system status",
            error_code="SYSTEM_STATUS_ERROR",
            error_detail=str(e)
        )

@system_router.get("/health")
async def health_check():
    """Simple health check endpoint"""
    try:
        system_info = {
            "status": "healthy",
            "timestamp": datetime.datetime.now().isoformat(),
            "environment": os.environ.get("API_ENV", "development")
        }
        
        return await ResponseUtil.health_response(
            status_details=system_info,
            message="System health check"
        )
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return await ResponseUtil.from_exception(e)

@system_router.get("/test-response-pattern")
async def test_response_pattern(
    test_type: str = Query("success", description="Type of test (success, error, not_found)"),
    include_error: bool = Query(False, description="Include error in successful response")
):
    """Test endpoint to validate response pattern consistency"""
    try:
        from app.core.exceptions import ValidationError, ResourceNotFoundError
        
        if test_type == "error":
            raise ValidationError(
                message="Test validation error",
                detail="This is a test error response"
            )
        elif test_type == "not_found":
            raise ResourceNotFoundError(
                message="Test resource not found",
                detail="This is a test not found response"
            )
        else:
            # Success response
            data = {
                "test_id": "123",
                "timestamp": datetime.datetime.now().isoformat(),
                "pattern": "standardized"
            }
            
            if include_error:
                # This will cause an error that should be caught
                data["field"] = undefined_variable
                
            return await ResponseUtil.success_response(
                data=data,
                message="Response pattern test successful"
            )
    except Exception as e:
        logger.error(f"Test response pattern error: {str(e)}")
        return await ResponseUtil.from_exception(e)