# backend/app/api/v1/completion.py

from typing import Dict, Any, Optional, List
import uuid
import logging
from fastapi import APIRouter, Depends, BackgroundTasks, Body, status
from pydantic import BaseModel, Field

from app.utils.response_util import ResponseUtil
from app.utils.auth_utils import get_current_user
from app.services.completion_service import CompletionService
from app.services.event_handler import EventHandler, ProcessStatus, EventType
from app.dependencies.services import get_completion_service, get_event_handler
from app.core.exceptions import ResourceNotFoundError

logger = logging.getLogger(__name__)

# Create independent router - NO ROUTER-LEVEL DEPENDENCIES
completion_router = APIRouter()

class CompletionRequest(BaseModel):
    prompt: Optional[str] = Field(None, description="Direct prompt text")
    template_id: Optional[str] = Field(None, description="Template ID from the prompt library")
    template_vars: Optional[Dict[str, Any]] = Field(None, description="Variables for template")
    max_tokens: int = Field(2000, description="Maximum tokens to generate")
    model_type: str = Field("primary", description="Type of model to use")
    documents: Optional[List[str]] = Field(None, description="List of document IDs to analyze")
    use_reasoning: bool = Field(False, description="Whether to enable reasoning mode for supported models")
    
    class Config:
        schema_extra = {
            "example": {
                "template_id": "deal_evaluation.financial_analysis.financial_analysis",
                "template_vars": {
                    "deal_details": "Marina Bay Development Project: A 200-unit residential development in Singapore with a project cost of $300M and expected ROI of 15%."
                },
                "max_tokens": 2000,
                "model_type": "primary",
                "documents": [],
                "use_reasoning": True
            }
        }

async def process_completion(
    request: CompletionRequest,
    process_id: str,
    user: Dict[str, Any]
):
    """Background task to process completion"""
    try:
        # Get service singletons
        completion_service = get_completion_service()
        event_handler = get_event_handler()
        
        # Update process status
        await event_handler.update_process(
            process_id=process_id,
            status=ProcessStatus.RUNNING,
            percentage=10,
            current_step="Processing request"
        )
        
        # Add info event
        await event_handler.add_event(
            process_id=process_id,
            event_type=EventType.INFO,
            message="Starting completion processing",
            data={"user_id": user.get("sub")}
        )
        
        # Update progress
        await event_handler.update_process(
            process_id=process_id,
            percentage=30,
            current_step="Generating completion"
        )
        
        # Get completion
        completion = await completion_service.create_completion(
            prompt=request.prompt,
            template_id=request.template_id,
            template_vars=request.template_vars,
            max_tokens=request.max_tokens,
            model_type=request.model_type,  
            documents=request.documents,
            use_reasoning=request.use_reasoning      
        )
        
        # Update process with completion data
        await event_handler.update_process(
            process_id=process_id,
            status=ProcessStatus.COMPLETED,
            percentage=100,
            current_step="Completed",
            metadata_updates={
                "completion": completion,
                "token_count": completion.get("tokens", {}).get("total", 0)
            }
        )
        
        # Add completion event
        await event_handler.add_event(
            process_id=process_id,
            event_type=EventType.COMPLETION,
            message="Completion generated successfully",
            data=completion
        )
        
    except Exception as e:
        # Update process status on error
        await event_handler.update_process(
            process_id=process_id,
            status=ProcessStatus.FAILED,
            current_step=f"Error: {str(e)}"
        )
        
        # Add error event
        await event_handler.add_event(
            process_id=process_id,
            event_type=EventType.ERROR,
            message=f"Completion processing failed: {str(e)}",
            data={"error": str(e)}
        )

@completion_router.post("")
async def create_completion(
    request: CompletionRequest,
    background_tasks: BackgroundTasks,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Create a new completion request"""
    try:
        # Get service singletons
        event_handler = get_event_handler()
        
        process_id = f"completion_{uuid.uuid4()}"
        
        # Create process tracking
        await event_handler.create_process(
            process_id=process_id,
            process_type="completion",
            user_id=current_user.get("sub"),
            metadata={
                "request_type": "completion",
                "template_id": request.template_id,
                "max_tokens": request.max_tokens,
                "model_type": request.model_type,
                "use_reasoning": request.use_reasoning,
                "document_count": len(request.documents) if request.documents else 0
            }
        )
        
        # Add background task for processing
        background_tasks.add_task(
            process_completion,
            request,
            process_id,
            current_user
        )
        
        return await ResponseUtil.success_response(
            data={"process_id": process_id, "status": "processing"},
            message="Completion request received",
            status_code=status.HTTP_202_ACCEPTED
        )
    except Exception as e:
        logger.error(f"Error creating completion: {str(e)}")
        return await ResponseUtil.from_exception(e)

@completion_router.get("/{process_id}")
async def get_completion(
    process_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Get a completion by process ID"""
    try:
        # Get service singleton
        event_handler = get_event_handler()
        
        process = await event_handler.get_process(process_id)
        
        if not process:
            raise ResourceNotFoundError(
                message="Completion not found",
                detail=f"No completion found with ID {process_id}"
            )
        
        return await ResponseUtil.success_response(
            data=process,
            message="Completion retrieved successfully"
        )
    except Exception as e:
        logger.error(f"Error retrieving completion: {str(e)}")
        return await ResponseUtil.from_exception(e)