# AIDE CI/CD Documentation

**Version 0.33.06 | April 18, 2025**

## Table of Contents

1. [Introduction](#1-introduction)
2. [CI/CD Philosophy for AI Systems](#2-cicd-philosophy-for-ai-systems)
3. [Architecture Overview](#3-architecture-overview)
4. [Continuous Integration (CI) Pipeline](#4-continuous-integration-ci-pipeline)
5. [Continuous Delivery (CD) Pipeline](#5-continuous-delivery-cd-pipeline)
6. [Manual Deployment Process](#6-manual-deployment-process)
7. [Security Considerations](#7-security-considerations)
8. [Best Practices](#8-best-practices)
9. [Troubleshooting Guide](#9-troubleshooting-guide)
10. [Future Improvements](#10-future-improvements)

## 1. Introduction

This document details the Continuous Integration and Delivery (CI/CD) pipelines implemented for AIDE (AI Deal Evaluation), a state-of-the-art financial analysis system. The CI/CD system is designed to balance automation with human oversight, ensuring rapid development without compromising the reliability and stability required for a sophisticated AI system in a financial context.

## 2. CI/CD Philosophy for AI Systems

### Hybrid Approach Rationale

AIDE implements a hybrid CI/CD approach that consists of:

1. **Fully Automated Continuous Integration**: Automated testing on every code change
2. **Automated Continuous Delivery**: Automated building and pushing of Docker images
3. **Human-controlled Deployment**: Manual deployment to production environments

This approach provides several benefits specifically important for state-of-the-art AI systems:

- **Risk Mitigation**: AI systems require stricter validation than traditional software due to their potential for unexpected behavior in edge cases. Manual deployment provides an opportunity for final validation.

- **Model Version Control**: AIDE integrates with multiple AI providers (OpenAI, Google AI, AWS Bedrock) where model versions are critical. Our hybrid approach ensures proper model version management with human oversight.

- **Regulatory Compliance**: Financial systems often require documented approval processes for production changes. Our manual deployment step facilitates this audit trail.

- **Operational Safety**: Unlike traditional software, AI systems can produce unanticipated outputs even when code is technically correct. Human verification before deployment provides an essential safety check.

## 3. Architecture Overview

The AIDE CI/CD pipeline consists of three main components:

### CI Workflow (GitHub Actions)
- Runs on all branch pushes and pull requests
- Executes unit and integration tests
- Provides automatic feedback on code quality
- Configured in `.github/workflows/ci.yml`

### CD Workflow (GitHub Actions)
- Triggered only on pushes to main/master branches
- Extracts version information from commit messages
- Builds Docker images for backend and frontend
- Pushes images to Amazon ECR
- Configured in `.github/workflows/cd.yml`

### Manual Deployment Script (`deploy.sh`)
- Run by an engineer when ready to deploy
- Pulls images built by the CD pipeline
- Creates Kubernetes secrets from environment variables
- Generates deployment manifests
- Applies changes to Kubernetes
- Monitors deployment health
- Provides interactive rollback capabilities

## 4. Continuous Integration (CI) Pipeline

### Triggering Conditions
```yaml
on:
  push:
    branches: [ "**" ]
  pull_request:
    branches: [ "main", "master" ]
```

The CI pipeline runs on:
- All branch pushes (for early feedback)
- Pull requests to main/master (for pre-merge validation)

### Components

1. **Backend Testing**:
   - Sets up Python 3.12 environment
   - Creates a MongoDB test container
   - Installs dependencies using uv for performance
   - Creates a test-specific environment configuration
   - Runs non-completion tests by default
   - Optionally runs completion tests (AI model integration tests)

2. **Frontend Testing**:
   - Sets up Node.js 20 environment
   - Installs dependencies
   - Runs frontend tests when available

### Test Environment
- Isolated MongoDB instance for database testing
- Environment variables appropriate for testing
- Special test database name to avoid production data contamination
- Preconfigured model settings for AI tests

### Code Example
```yaml
- name: Run standard tests (excluding completion tests)
  working-directory: ./backend
  env:
    API_ENV: testing
    PYTHONPATH: .
    CI: "true"
  run: |
    # Run all tests except completion tests
    pytest tests/ -v -m "not completion"
```

## 5. Continuous Delivery (CD) Pipeline

### Triggering Conditions
```yaml
on:
  push:
    branches: [ "main", "master" ]
```

The CD pipeline runs only when code is merged to main/master, ensuring that only reviewed and approved code gets built for potential deployment.

### Version Management

Version information is critical for AI systems to ensure reproducibility and auditability. Our CD pipeline extracts version information in the following priority:

1. From commit messages (format: `v0.33.04`)
2. Timestamp-based version if none found in commit

```yaml
- name: Extract version from latest commit message
  id: get-version
  run: |
    VERSION=$(git log -1 --pretty=%B | grep -oP 'v\d+\.\d+\.\d+' || echo "0.33.$(date +%Y%m%d%H%M)")
    echo "VERSION=${VERSION}" >> $GITHUB_ENV
```

### Image Building Process

1. **Backend**:
   - Creates temporary configuration for build
   - Builds Docker image with Python 3.12
   - Tags with specific version and 'latest'
   - Pushes to Amazon ECR

2. **Frontend**:
   - Installs Node.js dependencies
   - Updates version in package.json
   - Builds React application with linting warnings allowed
   - Builds Docker image with Node.js 20
   - Tags with specific version and 'latest'
   - Pushes to Amazon ECR

### Error Handling

The CD pipeline includes robust error handling to ensure clarity when issues occur:

```yaml
docker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$VERSION . || 
  { echo "::error::Backend Docker build failed"; exit 1; }
```

All critical operations have explicit error messages and proper exit codes to make troubleshooting easier.

## 6. Manual Deployment Process

The deployment script (`deploy.sh`) provides controlled deployment to Kubernetes with human oversight.

### Key Benefits

1. **Human Verification**: Engineers can verify that the images built by the CD pipeline are ready for deployment.

2. **Environment-Specific Configuration**: Allows different configurations for production, staging, and other environments.

3. **Secret Management**: Generates Kubernetes secrets from environment variables without storing them in Git.

4. **Deployment Monitoring**: Monitors the health of the deployment with status reporting.

5. **Interactive Rollback**: Provides the option to roll back if deployments fail or exhibit issues.

### Key Components

1. **Version Reading**: Reads the current version from `backend/.env.local`.

2. **ECR Authentication**: Logs in to Amazon ECR to pull the images.

3. **Secret Generation**: Generates Kubernetes secrets from environment variables.

4. **Manifest Generation**: Creates deployment manifests for Kubernetes with proper version and configuration.

5. **Kubernetes Application**: Applies the manifests to the Kubernetes cluster.

6. **Deployment Monitoring**: Watches for successful deployment or issues.

7. **Health Verification**: Verifies that all pods are running and ready.

### Usage
```bash
# Full deployment
./deploy.sh

# Deployment options
./deploy.sh --restart     # Quick restart without rebuilding
./deploy.sh --rollback    # Rollback to previous version
./deploy.sh --skip-build  # Skip building images (use ones in ECR)
```

## 7. Security Considerations

### Credentials Management

1. **GitHub Secrets**: AWS access keys, API keys, and other sensitive data are stored as GitHub secrets, not in the codebase.

2. **ECR Password Masking**: Docker passwords for ECR operations are properly masked during CI/CD operations.

3. **Environment Isolation**: Different environments (development, staging, production) use different credentials.

### Configuration Management

1. **Environment Variables**: Sensitive configuration is stored in `.env.local` files that are excluded from Git.

2. **Kubernetes Secrets**: Generated at deployment time and never stored in the repository.

3. **Temporary Configuration**: The CD pipeline creates minimal temporary configuration for builds, avoiding secrets persistence.

### Access Control

1. **Principle of Least Privilege**: CI/CD roles and users have only the permissions necessary for their operations.

2. **Deployment Permissions**: Manual deployment requires specific permissions to Kubernetes resources.

## 8. Best Practices

### Commit Messages and Versioning

Use semantic versioning in commit messages when updating the version:

```
v0.33.04: Reinforcing hybrid CI/CD approach of (i) automated build, (ii) manual deployment
```

The CD pipeline extracts this information for image tagging and deployment.

### Pre-Deployment Testing

Always run the tests locally before pushing to main/master:

```bash
# Run backend tests
cd ~/git/keppel/aide/backend
./run_tests.sh standard
```

### Monitoring After Deployment

After deployment, monitor system health:

```bash
# Check pod status
kubectl get pods -n aide

# Check logs for any issues
kubectl logs -n aide deployment/aide-backend --tail=100
```

### Documentation Updates

Keep documentation updated with environment and deployment changes:

```bash
# Document changes in appropriate locations
~/git/keppel/aide/docs/
```

## 9. Troubleshooting Guide

### Common CI Issues

1. **Test Failures**:
   - Check test logs for specific errors
   - Verify MongoDB container is running
   - Ensure environment variables are set correctly

2. **ESLint/Linting Issues**:
   - Frontend build may fail due to ESLint errors
   - Set `CI=false` to bypass errors temporarily
   - Fix linting issues for long-term solution

### Common CD Issues

1. **Missing .env.local**:
   - CD pipeline now creates a temporary configuration
   - Verify version is correctly extracted from commit message

2. **ECR Authentication Failure**:
   - Check AWS credentials in GitHub secrets
   - Verify IAM permissions for ECR operations

3. **Docker Build Failures**:
   - Examine logs for specific build errors
   - Check for dependency issues
   - Verify Dockerfile compatibility with used base images

### Common Deployment Issues

1. **Kubernetes Authentication**:
   - Verify kubeconfig configuration
   - Check AWS IAM permissions for EKS operations

2. **Missing Deployment Files**:
   - Ensure `generate-secrets.sh` and `generate-deployment.sh` exist
   - Check template files for proper variable substitution

3. **Pod Health Issues**:
   - Examine pod logs for application errors
   - Check for resource constraints (CPU/memory)
   - Verify environment variables and secrets

## 10. Future Improvements

1. **Automated Testing Enhancement**:
   - Expand test coverage for AI model interactions
   - Add performance tests for critical components
   - Implement integration tests for document processing

2. **Deployment Automation**:
   - Implement canary deployments for safer rollouts
   - Add automated rollback based on health metrics
   - Create staging environment for pre-production verification

3. **Monitoring Integration**:
   - Add CloudWatch metrics for deployment health
   - Implement logging aggregation for easier troubleshooting
   - Create deployment alerting for failed deployments

4. **Security Enhancements**:
   - Implement regular secret rotation
   - Add vulnerability scanning in CI pipeline
   - Integrate OWASP dependency checks

---

## Version History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
| 1.0.0 | April 18, 2025 | DevTeam | Initial CI/CD documentation |