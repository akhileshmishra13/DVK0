# AIDE DocumentDB Configuration Documentation (AIDE v0.15.6)

## Overview

This document describes the Amazon DocumentDB implementation for the AIDE system. AIDE has successfully migrated from MongoDB to Amazon DocumentDB to achieve improved reliability, security, and persistence.

## Amazon DocumentDB Configuration

### Current Environment

The Amazon DocumentDB cluster has been deployed in the same VPC as the EKS cluster:

- **Cluster Name**: `aide-docdb-eks`
- **Cluster Endpoint**: `aide-docdb-eks.cluster-c7qkksa8ibvm.ap-southeast-1.docdb.amazonaws.com`
- **Connection Pattern**: `mongodb://${USERNAME}:${PASSWORD}@${HOST}:${PORT}/aide_db?tls=true&tlsCAFile=/app/certs/rds-ca-bundle.pem&replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false`
- **Database**: `aide_db`
- **Instance Type**: `db.t3.medium`
- **Engine Version**: `5.0.0`
- **VPC ID**: `vpc-03c1d67fc5b1ece23` (same as EKS cluster)
- **Security Group**: `aide-docdb-eks-sg` (configured to allow traffic from EKS nodes)
- **Subnet Group**: `aide-docdb-eks-subnet` (using the EKS cluster's subnets)
- **TLS/SSL**: Enabled and required, using AWS RDS CA bundle
- **Encryption**: Enabled at rest
- **Credentials Management**: Using Kubernetes Secrets (see "Secure Credentials Management" section)

## Secure Credentials Management

AIDE uses Kubernetes Secrets to manage DocumentDB credentials securely:

1. **Credentials Storage**:
   - All connection credentials are stored in the `docdb-credentials` Kubernetes Secret
   - The secret contains `username`, `password`, `host`, and `port` values
   - No credentials are hardcoded in deployment files or documentation

2. **Access Pattern**:
   - Backend pods reference the secret values via environment variables
   - Connection URL is constructed securely at runtime

3. **Security Best Practices**:
   - Credentials are never committed to version control
   - All configuration files with connection strings use environment variables
   - Deployment files with credentials are added to .gitignore

## TLS Certificate Configuration

A TLS certificate is required for secure connections to DocumentDB:

1. **Certificate Source**: AWS RDS global bundle
   - Source URL: https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem
   - Downloaded and stored in ConfigMap

2. **Kubernetes Implementation**:
   - ConfigMap name: `rds-ca-bundle`
   - Created with: `kubectl create configmap rds-ca-bundle -n aide --from-file=rds-ca-bundle.pem=/tmp/rds-combined-ca-bundle.pem`
   - Mounted at: `/app/certs/rds-ca-bundle.pem` in backend pods

3. **Connection Configuration**: 
   - Connection string includes: `tls=true&tlsCAFile=/app/certs/rds-ca-bundle.pem`
   - Additional required parameters: `replicaSet=rs0&readPreference=secondaryPreferred&retryWrites=false`

## Backend Integration

The backend is configured to connect to DocumentDB securely through Kubernetes Secrets:

```yaml
# Secure implementation using Kubernetes Secrets
containers:
- name: aide-backend
  env:
  - name: MONGODB_URL
    valueFrom:
      secretKeyRef:
        name: docdb-credentials
        key: connection-url
  - name: MONGODB_DB_NAME
    value: "aide_db"
  volumeMounts:
  - name: rds-ca-volume
    mountPath: /app/certs
    readOnly: true
volumes:
- name: rds-ca-volume
  configMap:
    name: rds-ca-bundle
```

## Data Model

AIDE stores documents in DocumentDB using GridFS with the following metadata structure:

```json
{
  "document_id": "unique-uuid-string",
  "original_filename": "Document Name.pdf",
  "upload_date": "2025-03-19T13:38:56.123Z",
  "content_type": "application/pdf",
  "extracted_metadata": {
    "document_type": "Teaser Deck|Deal Qualification Memo|Confidential Investment Memo|Internal Memo|Investment Summary",
    "title": "PROJECT NAME - Description",
    "date": "YYYY-MM-DD",
    "author": "Author Name/Organization",
    "project_name": "Project Name",
    "industry_sector": "Industry Type",
    "geographic_region": "Region Name",
    "key_financial_metrics": {
      "metric1": "value1",
      "metric2": "value2"
    },
    "transaction_type": "Transaction Description",
    "key_topics": ["Topic1", "Topic2", "Topic3"],
    "estimated_token_count": 1000
  },
  "extracted_structure": {
    "sections": [
      {"heading": "Section Title", "content": "Section content...", "level": 1}
    ],
    "tables": [
      {
        "caption": "Table Title",
        "headers": ["Column1", "Column2"],
        "data": [["Row1Col1", "Row1Col2"], ["Row2Col1", "Row2Col2"]]
      }
    ],
    "financial_metrics": {
      "metric1": "value1",
      "additional_metrics": {}
    },
    "key_points": ["Point 1", "Point 2", "Point 3"]
  },
  "extraction_complete": true
}
```

## Database Access Tools

The following tools have been created for interacting with DocumentDB:

### Interactive DocumentDB Shell

A custom shell script was created to access DocumentDB from within the Kubernetes cluster:

Location: `~/git/keppel/aide/backend/scripts/db/docdb_shell.py` and `~/git/keppel/aide/backend/scripts/db/docdb.sh`

Usage:
```bash
# Go to the scripts directory
cd ~/git/keppel/aide/backend/scripts/db

# Launch interactive shell (default)
./docdb.sh

# List all collections with document counts
./docdb.sh --collections

# List all documents with details
./docdb.sh --documents

# View database statistics
./docdb.sh --stats
```

This tool works by:
1. Identifying an available backend pod
2. Creating a temporary Python script with the desired operations
3. Copying the script to the pod
4. Executing it using the pod's environment variables and network access
5. Returning the results

## Sample Data

Five sample documents have been loaded into DocumentDB for testing purposes:

1. Teaser Deck: "Project Atlas Teaser.pdf"
2. Deal Qualification Memo: "Project SolarFlare DQM.pdf"
3. Confidential Investment Memo: "Project Harbor CIM.pdf"
4. Internal Memo: "Project Phoenix IM.pdf" 
5. Investment Summary: "Project Falcon Investment Summary.pdf"

These documents can be loaded using:

```bash
# Get a backend pod name
BACKEND_POD=$(kubectl get pods -n aide -l app=aide-backend -o jsonpath="{.items[0].metadata.name}")

# Copy sample data script to pod
kubectl cp ~/git/keppel/aide/backend/scripts/load_sample_docs.py $BACKEND_POD:/tmp/load_sample_docs.py -n aide

# Run the script
kubectl exec -it $BACKEND_POD -n aide -- python /tmp/load_sample_docs.py
```

## Secure Deployment Process

The application is deployed to Kubernetes with DocumentDB integration using the following process:

```bash
# PART 1: Build and push images
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION=$(aws configure get region)
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com

# Build and push backend
cd ~/git/keppel/aide/backend
docker build -t aide-backend:latest .
docker tag aide-backend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:latest

# Build and push frontend
cd ~/git/keppel/aide/frontend
docker build -t aide-frontend:latest .
docker tag aide-frontend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:latest

# PART 2: Deploy to Kubernetes
cd ~/git/keppel/aide/deploy/k8s

# Ensure RDS CA bundle exists
kubectl get configmap rds-ca-bundle -n aide &>/dev/null || (
  curl -o /tmp/rds-combined-ca-bundle.pem https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem
  kubectl create configmap rds-ca-bundle -n aide --from-file=rds-ca-bundle.pem=/tmp/rds-combined-ca-bundle.pem
)

# Deploy backend and frontend
kubectl apply -f backend-docdb-fixed.yaml  # This file uses secrets for credentials
kubectl apply -f frontend-deployment.yaml

# Wait for deployments to finish
kubectl rollout status deployment/aide-backend -n aide
kubectl rollout status deployment/aide-frontend -n aide
```

## Day-to-Day Database Interaction

These commands can be used for regular database interactions:

```bash
# Go to the scripts directory
cd ~/git/keppel/aide/backend/scripts/db

# Interactive shell
./docdb.sh

# Common database operations (inside the shell)
db.fs.files.count_documents({})  # Count documents
list(db.fs.files.find())         # List all documents
db.fs.files.find_one()           # Show one document
list_collections()               # List collections with counts
stats()                          # Show database stats

# Monitor document count
./docdb.sh --stats
```

## Troubleshooting Common Issues

### Connection Issues
If the backend can't connect to DocumentDB:

```bash
# Check backend logs
BACKEND_POD=$(kubectl get pods -n aide -l app=aide-backend -o jsonpath="{.items[0].metadata.name}")
kubectl logs $BACKEND_POD -n aide | grep -i "mongo\|docdb\|connection"

# Verify certificate mounting
kubectl describe pod $BACKEND_POD -n aide | grep -A 10 Volumes:

# Verify secret exists and has all fields
kubectl describe secret docdb-credentials -n aide

# Directly test connection from pod
kubectl exec -it $BACKEND_POD -n aide -- python -c "
import os
from pymongo import MongoClient
url = os.environ.get('MONGODB_URL')
client = MongoClient(url)
print(client.aide_db.command('ping'))
"
```

### SSL/TLS Issues
For SSL certificate problems:

```bash
# Verify certificate exists
kubectl exec -it $BACKEND_POD -n aide -- ls -la /app/certs/

# Check certificate content
kubectl exec -it $BACKEND_POD -n aide -- cat /app/certs/rds-ca-bundle.pem | head -5
```

## Implementation Notes

The migration from MongoDB to DocumentDB was completed with the following benefits:

1. **Data Persistence**: Documents now survive pod restarts (unlike the previous MongoDB container)
2. **Security**: Connection is encrypted with TLS and protected by VPC isolation
3. **Reliability**: AWS-managed service with automatic backups
4. **Performance**: Optimized for document storage with consistent performance
5. **Scalability**: Can scale as document volume grows
6. **Compatibility**: Maintains MongoDB compatibility for existing application code
7. **Security Best Practices**: Credentials managed via Kubernetes Secrets

Some DocumentDB limitations to be aware of:
1. Certain MongoDB features are not supported (transactions across collections, change streams)
2. Always use `retryWrites=false` in connection strings
3. Connection requires TLS with the correct certificate