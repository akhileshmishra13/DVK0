# AIDE Deployment Guide (v0.15.6)

## Infrastructure Overview

### AWS Account
- Account ID: [ACCOUNT_ID]
- Region: ap-southeast-1

### Kubernetes Cluster
- Name: aide-cluster-new
- Version: 1.27
- Nodes: 2 x t3.medium
- VPC ID: vpc-03c1d67fc5b1ece23

### Database
- Type: Amazon DocumentDB
- Cluster: aide-docdb-eks
- Instance Type: db.t3.medium
- Version: 5.0.0
- Security Group: aide-docdb-eks-sg (allows traffic from EKS nodes)
- Subnet Group: aide-docdb-eks-subnet (uses EKS subnets)
- TLS: Enabled with AWS RDS CA bundle

## Access Information

### Main Endpoints
- Frontend: http://k8s-aide-aideingr-0bfaad4f3c-1930919656.ap-southeast-1.elb.amazonaws.com
- Backend API: http://k8s-aide-aideingr-0bfaad4f3c-1930919656.ap-southeast-1.elb.amazonaws.com/api
- Health Check: http://k8s-aide-aideingr-0bfaad4f3c-1930919656.ap-southeast-1.elb.amazonaws.com/health

### NodePort Access (Alternative)
- Node IP: [NODE_IP]
- Frontend: http://[NODE_IP]:30080
- Backend: http://[NODE_IP]:30081

### Container Repositories
- Backend: [ACCOUNT_ID].dkr.ecr.ap-southeast-1.amazonaws.com/aide-backend
- Frontend: [ACCOUNT_ID].dkr.ecr.ap-southeast-1.amazonaws.com/aide-frontend

## Deployment Process

### 1. Building and Pushing Images

```bash
# Get AWS account ID and region
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION=$(aws configure get region)

# Login to ECR
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com

# Build and push backend
cd ~/git/keppel/aide/backend
docker build -t aide-backend:latest .
docker tag aide-backend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:latest

# Build and push frontend
cd ~/git/keppel/aide/frontend
docker build -t aide-frontend:latest .
docker tag aide-frontend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:latest
```

### 2. Deploying to Kubernetes

```bash
cd ~/git/keppel/aide/deploy/k8s

# Ensure RDS CA bundle exists
kubectl get configmap rds-ca-bundle -n aide &>/dev/null || (
  curl -o /tmp/rds-combined-ca-bundle.pem https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem
  kubectl create configmap rds-ca-bundle -n aide --from-file=rds-ca-bundle.pem=/tmp/rds-combined-ca-bundle.pem
  echo "Created RDS CA bundle configmap"
)

# Create DocumentDB credentials secret if not exists
kubectl get secret docdb-credentials -n aide &>/dev/null || (
  kubectl create secret generic docdb-credentials \
    --from-literal=username=<DOCDB_USERNAME> \
    --from-literal=password=<DOCDB_PASSWORD> \
    --from-literal=host=<DOCDB_ENDPOINT> \
    --from-literal=port=27017 \
    -n aide
  echo "Created DocumentDB credentials secret"
)

# Deploy frontend and backend
kubectl apply -f frontend-deployment.yaml
kubectl apply -f backend-docdb-fixed.yaml

# Wait for deployments to complete
kubectl rollout status deployment/aide-backend -n aide
kubectl rollout status deployment/aide-frontend -n aide

# Verify everything is running
kubectl get pods -n aide
```

### 3. DocumentDB Configuration

The backend is configured to connect to DocumentDB using Kubernetes secrets for secure credential management:

```yaml
env:
- name: MONGODB_URL
  valueFrom:
    secretKeyRef:
      name: docdb-credentials
      key: connection-url
- name: MONGODB_DB_NAME
  value: "aide_db"
volumeMounts:
- name: rds-ca-volume
  mountPath: /app/certs
  readOnly: true
volumes:
- name: rds-ca-volume
  configMap:
    name: rds-ca-bundle
```

This approach ensures that sensitive database credentials are never stored in the Git repository or deployment files.

## Key Components

### Frontend
- React application with Material UI and dark theme
- Redux for state management
- Authentication via AWS Cognito

### Backend
- FastAPI service with DocumentDB integration
- JWT authentication with Cognito
- AI model integration with AWS Bedrock and Google AI

### Database
- Amazon DocumentDB (MongoDB-compatible managed service)
- Data stored using GridFS for document handling
- TLS encryption for secure connections

## Monitoring and Maintenance

### Health Checks
- Backend health: http://k8s-aide-aideingr-0bfaad4f3c-1930919656.ap-southeast-1.elb.amazonaws.com/health
- Check database connectivity:
  ```bash
  # Get a backend pod
  BACKEND_POD=$(kubectl get pods -n aide -l app=aide-backend -o jsonpath="{.items[0].metadata.name}")
  
  # Check database connection
  kubectl exec -it $BACKEND_POD -n aide -- python -c "from pymongo import MongoClient; import os; client = MongoClient(os.environ['MONGODB_URL']); print('Connected:',client.admin.command('ping'))"
  ```

### Logging
- CloudWatch Container Insights enabled
- View logs via:
  ```bash
  kubectl logs -n aide deployment/aide-frontend
  kubectl logs -n aide deployment/aide-backend
  ```

### Basic Operations

```bash
# Check application status
kubectl get pods -n aide

# Restart services if needed
kubectl rollout restart deployment -n aide aide-frontend
kubectl rollout restart deployment -n aide aide-backend

# Scale services
kubectl scale deployment -n aide aide-frontend --replicas=3
kubectl scale deployment -n aide aide-backend --replicas=3
```

### Database Operations

```bash
# Use the secure database tools in the scripts directory
cd ~/git/keppel/aide/backend/scripts/db

# Interactive shell for database operations
./docdb.sh

# List collections
./docdb.sh --collections

# View documents
./docdb.sh --documents

# Check database stats
./docdb.sh --stats
```

## Scaling and Performance

### Horizontal Scaling
- Backend can be scaled by increasing replicas:
  ```bash
  kubectl scale deployment -n aide aide-backend --replicas=4
  ```
- Frontend can be scaled similarly:
  ```bash
  kubectl scale deployment -n aide aide-frontend --replicas=4
  ```

### DocumentDB Scaling
- Instance type can be modified for more resources
- Read replicas can be added for read-heavy workloads:
  ```bash
  aws docdb create-db-instance \
    --db-instance-identifier aide-docdb-reader \
    --db-instance-class db.t3.medium \
    --engine docdb \
    --db-cluster-identifier aide-docdb-eks
  ```

## Troubleshooting

### Common Issues

1. **DocumentDB Connection Issues**
   - Verify TLS certificate is mounted correctly
   - Check security group rules allow traffic from EKS
   - Ensure secrets are properly configured

2. **Frontend/Backend Communication Issues**
   - Check ingress rules and ALB configuration
   - Verify service endpoints and ports
   - Check CORS settings

3. **Pod Startup Issues**
   - Check pod events: `kubectl describe pod -n aide <pod-name>`
   - Check container logs: `kubectl logs -n aide <pod-name>`
   - Verify resource constraints aren't being hit

4. **Ingress/Load Balancer Issues**
   - Check ALB controller logs: `kubectl logs -n kube-system deployment/aws-load-balancer-controller`
   - Verify security groups allow traffic to nodes

## Backup and Disaster Recovery

### DocumentDB Backups
- Automated daily snapshots are enabled
- Retention period: 7 days
- Manual snapshot creation:
  ```bash
  aws docdb create-db-cluster-snapshot \
    --db-cluster-identifier aide-docdb-eks \
    --db-cluster-snapshot-identifier aide-docdb-manual-snapshot
  ```

### Application Configuration Backup
- All Kubernetes manifests are stored in git repository
- ECR repositories contain all container versions

## Security Best Practices

The system implements several security best practices:

1. **Credential Management**:
   - Database credentials stored in Kubernetes secrets
   - No sensitive data in Git repository
   - Proper use of environment variables

2. **Network Security**:
   - TLS for all DocumentDB connections
   - VPC isolation for DocumentDB
   - Security groups limit access to authorized sources

3. **Authentication & Authorization**:
   - JWT authentication with AWS Cognito
   - Proper access control throughout the application
   - Token-based authentication for API endpoints

4. **Encryption**:
   - Data encryption at rest for DocumentDB
   - TLS encryption for data in transit
   - HTTPS for all external communication
