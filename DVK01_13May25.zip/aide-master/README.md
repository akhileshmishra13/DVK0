# Keppel AIDE - AI Deal Evaluation

**Version 0.40.05 | May 3, 2025**

## System Architecture Overview

Keppel AIDE implements a multi-tier architecture focused on secure, performant AI-powered investment analysis. The system orchestrates multiple AI models from leading providers (OpenAI, Google AI, AWS Bedrock) through a unified interface, enabling sophisticated document analysis and financial evaluation for investment opportunities.

The system's architecture follows a layered approach with clear separation of concerns:

1. **API Layer**: Implements a REST interface through FastAPI, providing async endpoints with comprehensive validation, standardized response patterns, and robust error handling. All endpoints employ middleware for authentication, logging, and request tracking via correlation IDs.

2. **Service Layer**: Forms the core of the application with specialized services that handle specific domains:
   - `ModelManager`: Dynamically selects and routes requests between multiple AI providers based on model type, implementing robust failover, response validation, and context window optimization.
   - `DataService`: Manages document storage and retrieval with MongoDB-compatible persistence.
   - `ExtractionService`: Processes documents using a combination of rule-based techniques (PyPDF2) and AI-powered extraction.
   - `CompletionService`: Orchestrates generative AI workflows with prompt transformation and context management.
   - `PromptSystem`: Manages a library of templated prompts with variable substitution.
   - `EventHandler`: Provides asynchronous process tracking with real-time status updates.
   - `SystemService`: Manages service lifecycle and health monitoring.

3. **Data Layer**: Employs Amazon DocumentDB (MongoDB-compatible) with GridFS for document storage, supporting BSON serialization and TLS encryption.

4. **Deployment Layer**: Offers two parallel deployment approaches:
   - Kubernetes-based deployment on EKS with AWS Load Balancer Controller
   - AWS-native deployment using ECS with Fargate for serverless container management

The architecture implements enterprise-grade security with AWS Cognito for authentication, JWT-based authorization, encrypted transport (TLS), and secure secrets management. The CI/CD pipeline utilizes GitHub Actions for automated testing and container image building, with human-controlled deployment for production safety.

## Architecture

AIDE implements a multi-layered architecture:

### Frontend Layer
- React-based UI with Material UI components and modern dark theme
- Redux state management for predictable data flow
- Real-time update capabilities for process tracking
- Document management interface for PDF handling
- AI Assistant interface for investment insights
- Protected routes with authentication guards

### API Layer
- FastAPI implementation with async request handling
- Standardized response patterns using ResponseUtil
- JWT and AWS Cognito authentication
- Request validation with Pydantic
- Authentication middleware for secure endpoints

### Service Layer
- Specialized services:
  - ModelManager: Multi-provider orchestration for OpenAI, Google AI, and Bedrock
    - Centralized model management with dynamic provider detection
    - Single source of truth for model configurations via `.env.local`
    - Provider-specific error handling and response validation
    - Robust fallback mechanisms between models and providers
    - Detailed logging for provider selection and execution
  - CompletionService: AI model interactions with fallback mechanisms
  - DataService: Document storage and retrieval with DocumentDB
  - PromptSystem: Context-aware prompt management
  - ExtractionService: Document analysis and metadata extraction
  - EventHandler: Real-time process tracking
  - LoggingService: Structured logging with correlation IDs
  - SystemService: Service initialization and health monitoring

### Data Layer
- Amazon DocumentDB (MongoDB-compatible) for production-grade storage
- GridFS for deal document storage
- TLS encryption for secure database connectivity
- Persistent storage across container restarts

### AWS Infrastructure
- **Kubernetes Deployment**:
  - Amazon EKS (Elastic Kubernetes Service) for container orchestration
  - NodeGroups for scalable compute resources
  - AWS Load Balancer Controller for ingress
- **AWS-Native Deployment (Parallel Implementation)**:
  - Amazon ECS with Fargate for serverless container management
  - Application Load Balancer for traffic routing
  - Task definitions for containerized services
  - CloudWatch for monitoring and logging
- **Shared Resources**:
  - Amazon ECR (Elastic Container Registry) for Docker image management
  - Amazon DocumentDB for secure, scalable document storage
  - AWS Cognito for authentication and user management
  - IAM roles and policies for secure access control
  - VPC with proper security groups for network isolation

## Model Configuration Management

AIDE implements a centralized model configuration system:

1. **Single Source of Truth**:
   - All model IDs and configurations defined in `.env.local`
   - Settings class loads these values during application initialization
   - No hardcoded model IDs in the codebase

2. **ModelManager Service**:
   - Loads model configurations from settings during initialization
   - Dynamically determines appropriate providers based on model names
   - Exposes consistent API for model access via `get_model()` and `get_provider()`
   - Handles model selection based on context window needs

3. **Service Integration**:
   - All services (CompletionService, ExtractionService, etc.) access models through ModelManager
   - No direct references to settings or hardcoded model IDs
   - Consistent handling of model selection and fallback mechanisms

4. **Supported Models**:
   - Primary: o1 (OpenAI via AsyncOpenAI client)
   - Fallback: GPT-4o-mini (OpenAI via AsyncOpenAI)
   - Ultra Context: Gemini 2.0 Flash (Google AI via native SDK)
   - Text Extraction: Gemini 2.0 Flash (Google AI optimized for extraction)
   - Grounding: Gemini 2.0 Flash with Google Search integration

5. **Provider Capabilities**:
   - Google AI: Full grounding with search, function calling, code execution
   - OpenAI: High reliability with consistent response formats
   - Bedrock: Claude models with provisioned throughput support

This architecture ensures consistent model usage throughout the application while maintaining flexibility to change models by updating only the `.env.local` file.

## Current Implementation Status

### Local Development
- ✅ Complete project architecture and directory structure
- ✅ Frontend framework with Material UI components
- ✅ Modern dark-themed UI design with data visualizations
- ✅ Backend API structure with FastAPI
- ✅ Redux state management for documents and AI responses
- ✅ Component hierarchy and routing
- ✅ Base service classes ready for AI integration
- ✅ Standardized response handling
- ✅ API service integration framework

### AI Model Integration
- ✅ Multi-provider ModelManager with OpenAI, Google AI, and Bedrock support
- ✅ Centralized model configuration and dynamic provider detection
- ✅ Asynchronous API clients for all providers (AsyncOpenAI, Google GenAI SDK, aioboto3)
- ✅ Robust response validation for all provider-specific responses
- ✅ Comprehensive logging of provider selection and processing
- ✅ Advanced features like Google Search grounding for Gemini models
- ✅ Fallback mechanisms between models and providers
- ✅ Provider-specific error handling and proper response extraction
- ✅ Thread pool execution for synchronous operations
- ✅ Structured output extraction from models
- ✅ Enhanced token optimization for context window usage

### Kubernetes Deployment (EKS)
- ✅ AWS account setup and IAM configuration
- ✅ EKS cluster creation with appropriate node groups
- ✅ ECR repositories for Docker images
- ✅ Docker containerization of frontend and backend
- ✅ Kubernetes manifest creation for all application components
- ✅ NodePort services for immediate application access
- ✅ AWS Load Balancer Controller configuration
- ✅ ALB Ingress successfully deployed
- ✅ Public access via Application Load Balancer
- ✅ Secure secrets management with Kubernetes secrets
- ✅ Template-based deployment manifests
- ✅ HTTPS configuration (ready for future implementation)

### AWS-Native Deployment (ECS with Fargate)
- ✅ Parallel deployment using AWS-native services
- ✅ VPC with public and private subnets
- ✅ ECS cluster with Fargate launch type
- ✅ ECR repositories for container images
- ✅ DocumentDB configured for secure storage
- ✅ Application Load Balancer with path-based routing
- ✅ ECS task definitions for frontend and backend
- ✅ ECS services with ALB integration
- ✅ Comprehensive documentation and guides
- ✅ Image pushes and final configuration (to be completed by operators)

### Authentication
- ✅ AWS Cognito User Pool and Client setup
- ✅ JWT-based authentication with AWS Cognito
- ✅ Backend auth middleware for protected routes
- ✅ Frontend login interface with dark theme
- ✅ Redux auth state management
- ✅ React protected routes implementation
- ✅ Token handling and storage
- ✅ Centralized auth service architecture
- ✅ API request authentication interceptors
- ✅ User management documentation and tools

### DocumentDB Migration
- ✅ Amazon DocumentDB cluster creation in EKS VPC
- ✅ TLS/SSL encryption configuration with AWS RDS CA certificates
- ✅ Security group configuration for cluster access
- ✅ Backend integration with DocumentDB
- ✅ Sample document loading for testing
- ✅ Production-ready database configuration
- ✅ Persistent storage across pod restarts

### CI/CD Implementation
- ✅ GitHub Actions workflows for automated testing and delivery
- ✅ Hybrid approach balancing automation with human oversight
- ✅ Continuous Integration with automated testing for every code change
- ✅ Continuous Delivery with automatic Docker image building and pushing
- ✅ Human-controlled deployment for production reliability and safety
- ✅ Multi-environment support with environment-specific configurations
- ✅ Error-resilient workflows with robust failure handling
- ✅ Python 3.12 and Node.js 20 based build environments
- ✅ Integration with MongoDB containers for database testing
- ✅ uv integration for faster dependency installation
- ✅ Comprehensive test suite with pytest and pytest-asyncio
- ✅ Version extraction from commit messages for better traceability
- ✅ Template-based deployment for consistency across environments

## Live Access

> **⚠️ SECURITY NOTE**  
> The URLs below are placeholders. For production documentation, use environment variables or configuration 
> service to manage actual endpoint URLs.

### Kubernetes Deployment (EKS)
- Main URL: [AIDE_FRONTEND_URL]
- API Endpoint: [AIDE_API_URL]
- Health Check: [AIDE_HEALTH_URL]

### Alternative NodePort Access (EKS)
- Node IP: [NODE_IP]
- Frontend: http://[NODE_IP]:30080
- Backend API: http://[NODE_IP]:30081
- Health Check: http://[NODE_IP]:30081/health

### AWS-Native Deployment (ECS with Fargate)
- Main URL: [AIDE_AWS_NATIVE_URL]
- API Endpoint: [AIDE_AWS_NATIVE_API_URL]

## Technology Stack

### Backend
- **FastAPI**: High-performance asynchronous API framework
- **Pydantic**: Data validation and settings management
- **Motor**: Async MongoDB/DocumentDB driver for document storage
- **Amazon DocumentDB**: Production-grade MongoDB-compatible database service
- **Python 3.12+**: Modern Python features
- **Boto3/aioboto3**: AWS SDK for Python, used for Cognito and Bedrock integration
- **Python-Jose**: JWT token handling
- **PyPDF2**: PDF text extraction library

### Frontend
- **React**: UI library for component-based architecture
- **Redux**: Predictable state management
- **Material UI**: Component library with design system
- **Axios**: Promise-based HTTP client
- **React Router**: Navigation and routing
- **React Markdown**: For rendering markdown content with syntax highlighting

### Authentication
- **AWS Cognito**: User pools, authentication, and token generation
- **JWT Tokens**: Secure token-based authentication
- **React Protected Routes**: Frontend route protection
- **FastAPI Middleware**: Backend route protection

### AI Models
- **OpenAI**: o1 and GPT-4o-mini via AsyncOpenAI client
- **Google AI**: Gemini 2.0 Flash via Google GenAI SDK
- **AWS Bedrock**: Claude models (when provisioned throughput is configured)
- **AI Features**:
  - Grounding with Google Search for up-to-date information
  - Function calling and code execution
  - Response structure validation for all providers
  - Advanced multimodal capabilities for document processing

### DevOps and Infrastructure
- **Docker**: Containerization of application components
- **Kubernetes/EKS**: Container orchestration for primary deployment
- **ECS with Fargate**: Serverless container management for AWS-native deployment
- **Amazon ECR**: Container registry for Docker images
- **Amazon DocumentDB**: Managed MongoDB-compatible database
- **AWS Cognito**: Authentication service
- **AWS IAM**: Identity and access management
- **AWS Load Balancer Controller/ALB**: Load balancing and traffic routing
- **TLS/SSL**: Secure database connections
- **CloudWatch**: Monitoring and logging
- **Kubernetes Secrets**: Secure management of sensitive information
- **GitHub Actions**: CI/CD automation for testing and deployment
- **uv**: Fast Python package installer for CI/CD workflows
- **pytest**: Python testing framework

## AWS-Native Parallel Implementation

We have created a parallel AWS-native implementation of AIDE that runs alongside the existing Kubernetes-based deployment. This provides flexibility in deployment options and demonstrates integration with AWS-managed services.

### Architecture Overview
The AWS-native implementation uses:
- **Amazon ECS with Fargate** for serverless container management
- **Application Load Balancer** for traffic routing with path-based rules
- **Amazon DocumentDB** for MongoDB-compatible document storage
- **AWS IAM roles** and security groups for access control

### Key Benefits
1. **Simplified Operations**: No Kubernetes cluster to manage
2. **Cost Efficiency**: Pay-per-use pricing with Fargate
3. **Native AWS Integration**: Direct integration with other AWS services
4. **Reduced Operational Overhead**: Many components managed by AWS

### Components Created
- Dedicated VPC with public and private subnets
- ECS cluster with Fargate launch type
- Task definitions for both backend and frontend
- Application Load Balancer with path-based routing
- DocumentDB cluster for data storage
- Security groups for proper network isolation

### Documentation
Comprehensive documentation for the AWS-native implementation is available in the `aws-native/` directory:
- `README.md`: Overall architecture and comparison with EKS
- `docs/deployment-guide.md`: Complete deployment instructions
- `docs/direct-deployment.md`: Step-by-step record of the commands used
- `docs/comparison.md`: Detailed comparison of Kubernetes vs. AWS-native approaches
- `docs/next-steps.md`: Tasks required to fully operationalize the deployment

## CI/CD Implementation

AIDE implements a hybrid CI/CD approach that balances automation with human oversight—a critical requirement for sophisticated AI systems.

### CI/CD Philosophy
The CI/CD pipeline is designed with three core components:
1. **Fully Automated Continuous Integration** to validate code quality
2. **Automated Continuous Delivery** to build and push Docker images
3. **Human-controlled Deployment** for production safety and reliability

This hybrid approach provides several benefits specifically important for AI systems:
- **Risk Mitigation**: Allows validation of AI behavior before production impact
- **Model Version Control**: Ensures proper AI model version management
- **Regulatory Compliance**: Maintains audit trail for financial system changes
- **Operational Safety**: Provides human verification before deployment

### CI Workflow (GitHub Actions)
The CI workflow runs on every push to any branch and on pull requests to main/master:
- Sets up Python 3.12 and Node.js 20 environments
- Installs dependencies with uv for faster package installation
- Creates a test MongoDB container
- Configures a testing environment with required variables
- Runs backend tests with pytest
- Executes frontend tests (when available)

### CD Workflow (GitHub Actions)
The CD workflow runs only on pushes to main/master branches:
- Extracts version from commit messages or uses timestamp-based versioning
- Configures AWS credentials for ECR access
- Builds Docker images for backend and frontend
- Tags images with both version-specific and latest tags
- Pushes images to Amazon ECR repositories

### Manual Deployment Process
The `deploy.sh` script provides controlled deployment to Kubernetes with human oversight:
- Pulls images built by the CD pipeline
- Creates Kubernetes secrets from environment variables
- Generates deployment manifests
- Applies changes to Kubernetes
- Monitors deployment health
- Provides interactive rollback capabilities

### Testing Architecture
The system uses pytest with pytest-asyncio for asynchronous code testing:
- Fixtures provide common test dependencies
- Tests run against a real MongoDB container
- Health, model, and data service functionality is verified
- Integration tests for AI model interactions

### Adding New Tests
As new functionality is developed, tests should be added:
1. Create test files in `backend/tests/` with the naming pattern `test_*.py`
2. Use function names starting with `test_`
3. Utilize the provided fixtures (client, test environment, etc.)
4. For complex services, use pytest-mock to isolate dependencies

Tests will be automatically run by the CI pipeline on each code commit.

### Versioning and Deployment Practices
- Use semantic versioning in commit messages when updating the version (format: `v0.33.04`)
- CI/CD extracts this information for image tagging and deployment traceability
- Run tests locally before pushing to main/master
- Monitor system health after deployment
- Update documentation with environment and deployment changes

## Getting Started

### Local Development Environment

#### Prerequisites
- Ubuntu 24.04 or newer (or compatible Linux distribution)
- Python 3.12+ with pip and venv
- Node.js 20.x or newer
- Docker and Docker Compose
- Git

#### Environment Setup

```bash
# Update package lists and install essential tools
sudo apt update
sudo apt install -y build-essential git curl wget unzip python3-pip python3-venv jq

# Install AWS CLI v2
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
rm -rf aws awscliv2.zip

# Install Node.js via NodeSource
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Install Docker
sudo apt install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
"$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Add user to docker group
sudo usermod -aG docker $USER
# Note: You may need to log out and log back in for this to take effect
```

#### Project Setup

```bash
# Create directory structure
mkdir -p ~/git/keppel

# Clone the repository
cd ~/git/keppel
git clone https://github.com/deepvertical-ai/aide.git aide

# Create development data directories
mkdir -p ~/git/keppel/aide/dev-data/mongodb
```

#### MongoDB Configuration

> **⚠️ SECURITY NOTE**  
> For development, use secure unique passwords instead of the example values shown below.
> Never commit credential information to repositories.

MongoDB setup is critical for the data service to function properly:

```bash
# Start MongoDB container with authentication
docker run -d --name aide-mongodb \
  -p 27017:27017 \
  -v ~/git/keppel/aide/dev-data/mongodb:/data/db \
  --env MONGO_INITDB_ROOT_USERNAME=root \
  --env MONGO_INITDB_ROOT_PASSWORD=[SECURE_PASSWORD] \
  --env MONGO_INITDB_DATABASE=aide_db \
  mongo:latest

# Create the application user that matches .env.local credentials
docker exec -it aide-mongodb mongosh -u root -p [SECURE_PASSWORD] --authenticationDatabase admin

# In the MongoDB shell, run:
use admin
db.createUser({
  user: '[DB_USER]',
  pwd: '[DB_PASSWORD]',
  roles: [
    { role: 'readWrite', db: 'aide_db' },
    { role: 'dbAdmin', db: 'aide_db' }
  ]
})
exit
```

#### Backend Setup

```bash
# Navigate to backend directory
cd ~/git/keppel/aide/backend

# Create and activate virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Verify MongoDB connection and start backend server
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

#### Frontend Setup

```bash
# Navigate to frontend directory
cd ~/git/keppel/aide/frontend

# Install dependencies
npm install

# Create frontend environment configuration
cat > .env.local << 'EOF'
REACT_APP_API_URL=http://localhost:8000
EOF

# Start the React development server
npm start
```

#### Development Database Tools

For local development, you can use the database tools in `backend/scripts/db/dev`:

```bash
# Create development database tools
mkdir -p ~/git/keppel/aide/backend/scripts/db/dev

# Create the MongoDB shell script for development
cat > ~/git/keppel/aide/backend/scripts/db/dev/docdb_dev.py << 'EOF'
#!/usr/bin/env python3
"""
MongoDB Interactive Shell - Development Version
----------------------------------------------
Provides interactive access to the AIDE local MongoDB database.
"""
import os
import sys
import json
import argparse
import code
from datetime import datetime
from pymongo import MongoClient
from bson import json_util

def interactive_shell():
    """Launch an interactive MongoDB shell"""
    print("Connecting to local MongoDB database...")
    
    # Connect using the same URL as the application
    mongodb_url = "mongodb://[DB_USER]:[DB_PASSWORD]@localhost:27017"
    db_name = "aide_db"
    
    print(f"Connected to: localhost:27017")
    print(f"Database: {db_name}")
    
    # Connect with proper settings
    client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
    db = client[db_name]
    
    # Add helper functions
    def list_collections():
        """List all collections with document counts"""
        collections = db.list_collection_names()
        result = []
        for coll in sorted(collections):
            count = db[coll].count_documents({})
            result.append({"collection": coll, "documents": count})
        return result

    def list_documents(collection="fs.files", limit=10, query=None, projection=None):
        """List documents in a collection with optional query and projection"""
        if query is None:
            query = {}
        if projection is None:
            projection = {"_id": 1}
        
        return list(db[collection].find(query, projection).limit(limit))

    def pretty(obj):
        """Pretty print an object"""
        return json.dumps(json.loads(json_util.dumps(obj)), indent=2)

    def stats():
        """Get database stats"""
        return db.command("dbstats")

    def collection_stats(collection="fs.files"):
        """Get collection stats"""
        return db.command("collStats", collection)

    def help():
        """Show available helper functions"""
        print("\nAvailable helper functions:")
        print("  list_collections() - List all collections with document counts")
        print("  list_documents(collection='fs.files', limit=10, query=None, projection=None)")
        print("  pretty(obj) - Pretty print an object")
        print("  stats() - Get database stats")
        print("  collection_stats(collection) - Get collection stats")
        print("  help() - Show this help")
        print("\nAvailable variables:")
        print("  client - MongoDB client")
        print("  db - Database object")
        print("\nExample queries:")
        print("  db.fs.files.find_one()")
        print("  list(db.fs.files.find({'filename': 'Project Atlas Teaser.pdf'}))")
        print("  db.fs.files.update_one({'filename': 'Project Phoenix IM.pdf'}, {'$set': {'new_field': 'value'}})")

    print("\n=== AIDE MongoDB Interactive Shell (Development) ===")
    help()
    print("\nPress Ctrl+D to exit")

    # Start interactive shell
    code.interact(local=locals())

def main():
    parser = argparse.ArgumentParser(description="MongoDB interactive shell for development")
    parser.add_argument("--collections", action="store_true", help="List collections")
    parser.add_argument("--documents", action="store_true", help="List documents")
    parser.add_argument("--stats", action="store_true", help="Show database stats")
    
    args = parser.parse_args()
    
    # Connect using the same URL as the application
    mongodb_url = "mongodb://[DB_USER]:[DB_PASSWORD]@localhost:27017"
    db_name = "aide_db"
    
    if args.collections:
        # List collections
        client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
        db = client[db_name]
        
        collections = db.list_collection_names()
        for coll in sorted(collections):
            count = db[coll].count_documents({})
            print(f"{coll}: {count} documents")
    elif args.documents:
        # List documents
        client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
        db = client[db_name]
        
        print("Documents in fs.files:")
        for doc in db.fs.files.find():
            try:
                doc_type = doc.get('metadata', {}).get('extracted_metadata', {}).get('document_type', 'Unknown')
                print(f"- {doc.get('filename', 'Unnamed')} ({doc_type})")
                print(f"  Uploaded: {doc.get('uploadDate', 'Unknown')}")
                print(f"  Size: {doc.get('length', 0)} bytes")
                print(f"  ID: {doc.get('_id', 'Unknown')}")
                print()
            except Exception as e:
                print(f"Error processing document: {e}")
    elif args.stats:
        # Show stats
        client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
        db = client[db_name]
        
        stats = db.command("dbStats")
        print("Database Stats:")
        print(f"Database: {stats['db']}")
        print(f"Collections: {stats['collections']}")
        print(f"Views: {stats['views']}")
        print(f"Objects: {stats['objects']}")
        print(f"Data Size: {stats['dataSize']} bytes")
        print(f"Storage Size: {stats['storageSize']} bytes")
        print(f"Indexes: {stats['indexes']}")
        print(f"Index Size: {stats['indexSize']} bytes")
    else:
        # Default to interactive shell
        interactive_shell()

if __name__ == "__main__":
    main()
EOF

cat > ~/git/keppel/aide/backend/scripts/db/dev/docdb_dev.sh << 'EOF'
#!/bin/bash
# Quick access to MongoDB shell and tools for development
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$SCRIPT_DIR/docdb_dev.py" "$@"
EOF

chmod +x ~/git/keppel/aide/backend/scripts/db/dev/docdb_dev.sh
chmod +x ~/git/keppel/aide/backend/scripts/db/dev/docdb_dev.py
```

#### Accessing the Application

- **Backend API**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs
- **Frontend UI**: http://localhost:3000

#### Troubleshooting MongoDB Authentication

If you see MongoDB authentication errors during startup:

1. Verify the MongoDB container is running:
   ```bash
   docker ps | grep aide-mongodb
   ```

2. Check the MongoDB logs for authentication attempts:
   ```bash
   docker logs aide-mongodb | grep -i "auth\|user\|failed"
   ```

3. Ensure the `aideusr` user exists in the admin database:
   ```bash
   docker exec -it aide-mongodb mongosh -u root -p [SECURE_PASSWORD] --authenticationDatabase admin --eval "use admin; db.getUsers()"
   ```

4. If the user doesn't exist, create it with the proper roles:
   ```bash
   docker exec -it aide-mongodb mongosh -u root -p [SECURE_PASSWORD] --authenticationDatabase admin --eval "
   use admin;
   db.createUser({
     user: '[DB_USER]',
     pwd: '[DB_PASSWORD]',
     roles: [
       { role: 'readWrite', db: 'aide_db' },
       { role: 'dbAdmin', db: 'aide_db' }
     ]
   });
   "
   ```

5. Verify the MongoDB URL in `.env.local` matches the credentials:
   ```
   MONGODB_URL=mongodb://[DB_USER]:[DB_PASSWORD]@localhost:27017
   ```

### User Management

AIDE uses AWS Cognito for user authentication and access management. For comprehensive instructions on managing users, please refer to the [User Management Guide](./docs/user-management-guide.md), which covers:

- Adding and managing users through AWS Cognito
- Setting up user permissions
- Password reset procedures
- Troubleshooting authentication issues
- Security best practices for user management

This dedicated guide provides detailed steps for administrators to properly manage system access.

### AWS Deployment Options

#### Option 1: Automated Deployment with deploy.sh

This script provides a comprehensive deployment solution that handles building, pushing, and deploying the application:

```bash
# Full deployment process
./deploy.sh

# Show help and options
./deploy.sh --help

# Quick restart without rebuilding images
./deploy.sh --restart

# Rollback to previous version
./deploy.sh --rollback

# Skip specific steps
./deploy.sh --skip-build --skip-secrets
```

The script handles:
- Reading configuration from `.env.local` (single source of truth)
- Building and pushing Docker images
- Generating Kubernetes secrets from environment variables
- Creating deployment manifests from templates
- Applying manifests and monitoring rollout
- Providing rollback options if deployment fails

#### Option 2: Manual Kubernetes Deployment (EKS)

##### Prerequisites
- AWS CLI configured with appropriate credentials
- kubectl installed
- eksctl installed
- Docker installed

##### Step 1: AWS Account and IAM Setup
```bash
# Configure AWS CLI with credentials
aws configure
# Enter Access Key ID, Secret Key, Region (ap-southeast-1), and output format (json)

# Verify configuration
aws sts get-caller-identity
```

##### Step 2: Create EKS Cluster
```bash
# Create cluster using the configuration in deploy/aws/cluster-config.yaml
cd ~/git/keppel/aide/deploy/aws
eksctl create cluster -f cluster-config.yaml

# Verify cluster creation
kubectl get nodes
```

##### Step 3: Create ECR Repositories
```bash
# Create repositories for backend and frontend if they don't exist
aws ecr create-repository --repository-name aide-backend --image-scanning-configuration scanOnPush=true
aws ecr create-repository --repository-name aide-frontend --image-scanning-configuration scanOnPush=true

# Get repository URLs
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION=$(aws configure get region)
BACKEND_REPO=${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend
FRONTEND_REPO=${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend
```

##### Step 4: Build and Push Docker Images
```bash
# Log in to ECR
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com

# Build and push backend image
cd ~/git/keppel/aide/backend
docker build -t aide-backend:latest .
docker tag aide-backend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:latest

# Build and push frontend image
cd ~/git/keppel/aide/frontend
docker build -t aide-frontend:latest .
docker tag aide-frontend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:latest
```

##### Step 5: Create DocumentDB in the Same VPC as EKS
```bash
# Get EKS VPC and subnet information
EKS_VPC=$(kubectl get nodes -o json | jq -r '.items[].spec.providerID' | grep -o 'i-[a-z0-9]*' | head -1 | xargs -I {} aws ec2 describe-instances --instance-ids {} --query 'Reservations[].Instances[].VpcId' --output text)
EKS_SUBNETS=$(kubectl get nodes -o json | jq -r '.items[].spec.providerID' | grep -o 'i-[a-z0-9]*' | xargs -I {} aws ec2 describe-instances --instance-ids {} --query 'Reservations[].Instances[].SubnetId' --output text | sort | uniq | tr '\n' ' ')
EKS_NODE_SG=$(kubectl get nodes -o json | jq -r '.items[].spec.providerID' | grep -o 'i-[a-z0-9]*' | head -1 | xargs -I {} aws ec2 describe-instances --instance-ids {} --query 'Reservations[].Instances[].SecurityGroups[].GroupId' --output text)

# Create subnet group
aws docdb create-db-subnet-group \
  --db-subnet-group-name aide-docdb-eks-subnet \
  --db-subnet-group-description "Subnet group for AIDE DocumentDB in EKS VPC" \
  --subnet-ids $EKS_SUBNETS

# Create security group
aws ec2 create-security-group \
  --group-name aide-docdb-eks-sg \
  --description "Security group for AIDE DocumentDB in EKS VPC" \
  --vpc-id $EKS_VPC

# Store security group ID
DOCDB_SG=$(aws ec2 describe-security-groups \
  --filters "Name=group-name,Values=aide-docdb-eks-sg" \
  --query "SecurityGroups[0].GroupId" \
  --output text)

# Allow traffic from EKS nodes
aws ec2 authorize-security-group-ingress \
  --group-id $DOCDB_SG \
  --source-group $EKS_NODE_SG \
  --protocol tcp \
  --port 27017

# Create DocumentDB cluster with secure credentials (replace with your own secure password)
aws docdb create-db-cluster \
  --db-cluster-identifier aide-docdb-eks \
  --engine docdb \
  --master-username aidemaster \
  --master-user-password "[SECURE_DOCDB_PASSWORD]" \
  --db-subnet-group-name aide-docdb-eks-subnet \
  --vpc-security-group-ids $DOCDB_SG \
  --storage-encrypted \
  --no-deletion-protection

# Create an instance
aws docdb create-db-instance \
  --db-instance-identifier aide-docdb-instance1-eks \
  --db-instance-class db.t3.medium \
  --engine docdb \
  --db-cluster-identifier aide-docdb-eks
```

##### Step 6: Set Up RDS CA Certificate for TLS
```bash
# Download the official Amazon RDS certificate bundle
curl -o /tmp/rds-combined-ca-bundle.pem https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem

# Create a ConfigMap with the official certificate
kubectl create configmap rds-ca-bundle -n aide \
  --from-file=rds-ca-bundle.pem=/tmp/rds-combined-ca-bundle.pem
```

##### Step 7: Create Kubernetes Secrets for API Keys and Database Credentials
```bash
# Create database credentials secret
DOCDB_ENDPOINT=$(aws docdb describe-db-clusters \
  --db-cluster-identifier aide-docdb-eks \
  --query "DBClusters[0].Endpoint" \
  --output text)

kubectl create secret generic docdb-credentials \
  --from-literal=username=aidemaster \
  --from-literal=password="[SECURE_DOCDB_PASSWORD]" \
  --from-literal=host=${DOCDB_ENDPOINT} \
  --from-literal=port=27017 \
  -n aide

# Create API keys secret
kubectl create secret generic aide-api-keys \
  --from-literal=GOOGLE_API_KEY="[YOUR_GOOGLE_API_KEY]" \
  --from-literal=OPENAI_API_KEY="[YOUR_OPENAI_API_KEY]" \
  --from-literal=PRIMARY_MODEL="o1" \
  --from-literal=FALLBACK_MODEL="gpt-4o-mini" \
  --from-literal=ULTRA_CONTEXT_MODEL="gemini-2.0-flash-001" \
  --from-literal=TEXT_EXTRACT_MODEL="gemini-2.0-flash-001" \
  -n aide

# Create AWS config secret
kubectl create secret generic aide-aws-config \
  --from-literal=AWS_REGION="us-east-1" \
  --from-literal=COGNITO_REGION="ap-southeast-1" \
  --from-literal=COGNITO_USER_POOL_ID="[YOUR_COGNITO_USER_POOL_ID]" \
  --from-literal=COGNITO_CLIENT_ID="[YOUR_COGNITO_CLIENT_ID]" \
  -n aide
```

##### Step 8: Generate and Apply Deployment Manifests
```bash
# Generate deployment manifests from templates
cd ~/git/keppel/aide/deploy/k8s
./generate-deployment.sh --env-file ../../backend/.env.local

# Apply the manifests
kubectl apply -f namespace.yaml
kubectl apply -f backend-docdb-fixed.yaml
kubectl apply -f frontend-deployment.yaml
kubectl apply -f ingress-complete.yaml

# Verify all components are running
kubectl get all -n aide
```

#### Option 3: AWS-Native Deployment (ECS with Fargate)

##### Prerequisites
- AWS CLI configured with appropriate credentials
- Docker installed

##### Step 1: Set Up Core Infrastructure
```bash
# Set environment variables
export ENV_NAME=aide-aws-native
export REGION=ap-southeast-1

# Create network infrastructure
cd ~/git/keppel/aide/aws-native/infrastructure
./deploy.sh

# Wait for infrastructure deployment to complete
```

##### Step 2: Set Up ECS and Load Balancer
```bash
# Set environment variables again (if needed)
export ENV_NAME=aide-aws-native
export REGION=ap-southeast-1

# Get important values from CloudFormation stacks
export ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
VPC_ID=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-network" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-VPC'].OutputValue" --output text)
PUBLIC_SUBNETS=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-network" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-PublicSubnets'].OutputValue" --output text)
ECS_SG=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-network" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-ECSSecurityGroup'].OutputValue" --output text)

# Create ALB security group
ALB_SG_ID=$(aws ec2 create-security-group \
  --group-name ${ENV_NAME}-alb-sg-direct \
  --description "Security group for AIDE ALB (direct)" \
  --vpc-id ${VPC_ID} \
  --query GroupId \
  --output text)

# Configure security groups
aws ec2 authorize-security-group-ingress \
  --group-id ${ALB_SG_ID} \
  --protocol tcp \
  --port 80 \
  --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress \
  --group-id ${ECS_SG} \
  --protocol tcp \
  --port 8000 \
  --source-group ${ALB_SG_ID}

# Create load balancer
PUBLIC_SUBNET_1=$(echo ${PUBLIC_SUBNETS} | cut -d',' -f1)
PUBLIC_SUBNET_2=$(echo ${PUBLIC_SUBNETS} | cut -d',' -f2)

ALB_ARN=$(aws elbv2 create-load-balancer \
  --name ${ENV_NAME}-alb-direct \
  --subnets ${PUBLIC_SUBNET_1} ${PUBLIC_SUBNET_2} \
  --security-groups ${ALB_SG_ID} \
  --query LoadBalancers[0].LoadBalancerArn \
  --output text)

# Create target groups
BACKEND_TG_ARN=$(aws elbv2 create-target-group \
  --name ${ENV_NAME}-be-tg \
  --protocol HTTP \
  --port 8000 \
  --vpc-id ${VPC_ID} \
  --target-type ip \
  --health-check-path /health \
  --query TargetGroups[0].TargetGroupArn \
  --output text)

FRONTEND_TG_ARN=$(aws elbv2 create-target-group \
  --name ${ENV_NAME}-fe-tg \
  --protocol HTTP \
  --port 80 \
  --vpc-id ${VPC_ID} \
  --target-type ip \
  --health-check-path / \
  --query TargetGroups[0].TargetGroupArn \
  --output text)

# Create listener and routing rules
LISTENER_ARN=$(aws elbv2 create-listener \
  --load-balancer-arn ${ALB_ARN} \
  --protocol HTTP \
  --port 80 \
  --default-actions Type=forward,TargetGroupArn=${FRONTEND_TG_ARN} \
  --query Listeners[0].ListenerArn \
  --output text)

aws elbv2 create-rule \
  --listener-arn ${LISTENER_ARN} \
  --priority 10 \
  --conditions Field=path-pattern,Values='/api*' \
  --actions Type=forward,TargetGroupArn=${BACKEND_TG_ARN}
```

##### Step 3: Create and Register Task Definitions
```bash
# Create directories if needed
mkdir -p aws-native/ecs/task-definitions

# Get necessary values
ECS_CLUSTER=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-ecs-cluster" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-ECSCluster'].OutputValue" --output text)
ECS_EXEC_ROLE=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-ecs-cluster" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-ECSTaskExecutionRoleArn'].OutputValue" --output text)
ECS_TASK_ROLE=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-ecs-cluster" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-ECSTaskRoleArn'].OutputValue" --output text)
ECS_LOG_GROUP=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-ecs-cluster" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-ECSLogGroup'].OutputValue" --output text)
DOCDB_CONN_PARAM=$(aws cloudformation describe-stacks --stack-name "${ENV_NAME}-documentdb" --region ${REGION} --query "Stacks[0].Outputs[?ExportName=='${ENV_NAME}-DocumentDBConnectionStringParam'].OutputValue" --output text)

# Create backend task definition
cat > aws-native/ecs/task-definitions/backend-nocert.json << EOF
{
  "family": "aide-aws-native-backend",
  "executionRoleArn": "${ECS_EXEC_ROLE}",
  "taskRoleArn": "${ECS_TASK_ROLE}",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "2048",
  "containerDefinitions": [
    {
      "name": "aide-backend",
      "image": "${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ENV_NAME}-backend:latest",
      "essential": true,
      "portMappings": [
        {
          "containerPort": 8000,
          "hostPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "API_ENV",
          "value": "production"
        },
        {
          "name": "MONGODB_DB_NAME",
          "value": "aide_db"
        },
        {
          "name": "TLS_INSECURE_SKIP_VERIFY",
          "value": "true"
        },
        {
          "name": "PRIMARY_MODEL",
          "value": "o1"
        },
        {
          "name": "FALLBACK_MODEL",
          "value": "gpt-4o-mini"
        },
        {
          "name": "ULTRA_CONTEXT_MODEL",
          "value": "gemini-2.0-flash-001"
        },
        {
          "name": "TEXT_EXTRACT_MODEL",
          "value": "gemini-2.0-flash-001"
        },
        {
          "name": "AWS_REGION",
          "value": "us-east-1"
        }
      ],
      "secrets": [
        {
          "name": "MONGODB_URL",
          "valueFrom": "${DOCDB_CONN_PARAM}"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-region": "${REGION}",
          "awslogs-group": "${ECS_LOG_GROUP}",
          "awslogs-stream-prefix": "backend"
        }
      },
      "healthCheck": {
        "command": ["CMD-SHELL", "curl -f http://localhost:8000/health || exit 1"],
        "interval": 30,
        "timeout": 5,
        "retries": 3,
        "startPeriod": 60
      }
    }
  ]
}
EOF

# Register task definitions
BACKEND_TASK_DEF_ARN=$(aws ecs register-task-definition \
  --cli-input-json file://aws-native/ecs/task-definitions/backend-nocert.json \
  --region ${REGION} \
  --query taskDefinition.taskDefinitionArn \
  --output text)

# Note: Frontend task definition is already registered as shown in our deployment
```

##### Step 4: Create ECS Services
```bash
# Create the backend service
aws ecs create-service \
  --cluster ${ECS_CLUSTER} \
  --service-name ${ENV_NAME}-be-direct \
  --task-definition ${BACKEND_TASK_DEF_ARN} \
  --desired-count 2 \
  --launch-type FARGATE \
  --platform-version LATEST \
  --network-configuration "awsvpcConfiguration={subnets=[${PUBLIC_SUBNET_1},${PUBLIC_SUBNET_2}],securityGroups=[${ECS_SG}],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=${BACKEND_TG_ARN},containerName=aide-backend,containerPort=8000" \
  --health-check-grace-period-seconds 120 \
  --region ${REGION}

# Get the frontend task definition
FRONTEND_TASK_DEF_ARN=$(aws ecs describe-task-definition \
  --task-definition aide-aws-native-frontend \
  --region ${REGION} \
  --query taskDefinition.taskDefinitionArn \
  --output text)

# Create the frontend service
aws ecs create-service \
  --cluster ${ECS_CLUSTER} \
  --service-name ${ENV_NAME}-fe-direct \
  --task-definition ${FRONTEND_TASK_DEF_ARN} \
  --desired-count 2 \
  --launch-type FARGATE \
  --platform-version LATEST \
  --network-configuration "awsvpcConfiguration={subnets=[${PUBLIC_SUBNET_1},${PUBLIC_SUBNET_2}],securityGroups=[${ECS_SG}],assignPublicIp=ENABLED}" \
  --load-balancers "targetGroupArn=${FRONTEND_TG_ARN},containerName=aide-frontend,containerPort=80" \
  --health-check-grace-period-seconds 120 \
  --region ${REGION}
```

##### Step 5: Build and Push Docker Images
```bash
# Log in to ECR
aws ecr get-login-password --region ${REGION} | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com

# Build and push backend image
cd ~/git/keppel/aide/backend
docker build -t ${ENV_NAME}-backend:latest .
docker tag ${ENV_NAME}-backend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ENV_NAME}-backend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ENV_NAME}-backend:latest

# Build and push frontend image
cd ~/git/keppel/aide/frontend
docker build -t ${ENV_NAME}-frontend:latest .
docker tag ${ENV_NAME}-frontend:latest ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ENV_NAME}-frontend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ENV_NAME}-frontend:latest
```

##### Step 6: Access the Application
```bash
# Get ALB DNS name
ALB_DNS=$(aws elbv2 describe-load-balancers \
  --load-balancer-arns ${ALB_ARN} \
  --query LoadBalancers[0].DNSName \
  --output text)

echo "Application URL: http://${ALB_DNS}"
echo "API endpoint: http://${ALB_DNS}/api"
```

## Project Structure

### Repository Root
```
aide/
├── .github/                # GitHub Actions workflows
│   └── workflows/          # CI/CD workflow definitions
│       ├── ci.yml          # Continuous Integration workflow
│       └── cd.yml          # Continuous Deployment workflow
├── backend/                # FastAPI backend
├── frontend/               # React frontend
├── deploy/                 # Deployment configurations
│   ├── aws/                # AWS-specific configurations
│   └── k8s/                # Kubernetes manifests and templates
│       ├── backend-deployment-template.yaml  # Backend deployment template
│       ├── frontend-deployment-template.yaml # Frontend deployment template
│       ├── secrets-template.yaml             # Secrets template
│       ├── generate-secrets.sh               # Script to generate secrets
│       └── generate-deployment.sh            # Script to generate deployments
├── aws-native/             # AWS-native parallel implementation
│   ├── infrastructure/     # Core infrastructure templates
│   ├── ecs/                # ECS configurations
│   ├── cicd/               # CI/CD configurations
│   ├── sagemaker/          # SageMaker development environment
│   ├── docs/               # Documentation and guides
│   └── scripts/            # Utility scripts
├── docs/                   # Documentation
│   ├── ci-cd.md                 # CI/CD documentation
│   ├── deployment-guide.md      # Deployment guide
│   ├── dev-environment-setup.md # Development setup instructions
│   ├── documentdb-configuration.md # DocumentDB configuration
│   └── user-management-guide.md # User management documentation
├── README.md               # Project documentation
├── deployment-guide.md     # Detailed deployment instructions
└── deploy.sh               # Main deployment script
```

### Backend
```
backend/
├── app/
│   ├── api/               # API endpoints and routing
│   │   ├── auth/          # Authentication endpoints
│   │   └── v1/            # API version 1 endpoints
│   ├── core/              # Core configuration
│   │   ├── config.py      # Application settings
│   │   ├── exceptions.py  # Error handling
│   │   ├── registry.py    # Service registry
│   │   └── service_init.py # Service initialization
│   ├── middleware/        # Middleware components
│   │   ├── auth_middleware.py # Authentication middleware
│   │   └── logging_middleware.py # Request logging
│   ├── services/          # Business logic services
│   │   ├── base_service.py # Base service class
│   │   ├── data_service.py # Document storage service
│   │   ├── model_manager.py # AI model orchestration
│   │   ├── completion_service.py # AI completion generation
│   │   ├── extraction_service.py # Document extraction
│   │   ├── event_handler.py # Process tracking
│   │   ├── logging_service.py # Structured logging
│   │   ├── prompt_system.py # AI prompt management
│   │   └── system_service.py # System lifecycle management
│   └── utils/             # Utility functions
│       ├── auth_utils.py  # Authentication utilities
│       ├── logging_context.py # Request context tracking
│       ├── pagination.py  # Pagination utilities
│       ├── response_decorators.py # API response decorators
│       └── response_util.py # Standardized API responses
├── scripts/               # Utility scripts
│   └── db/                # Database scripts
├── tests/                 # Test directory
│   ├── conftest.py        # Test fixtures and configuration
│   └── test_*.py          # Test files
├── pytest.ini             # pytest configuration
├── .env.local             # Environment variables (single source of truth)
├── Dockerfile             # Container definition
└── requirements.txt       # Python dependencies
```

### Frontend
```
frontend/
├── public/                # Static files
├── src/
│   ├── components/        # React components
│   │   ├── ai/            # AI interaction components
│   │   ├── auth/          # Authentication components
│   │   ├── common/        # Shared components
│   │   ├── document/      # Document handling components
│   │   └── layout/        # Layout components
│   ├── services/          # API services
│   │   ├── apiService.js  # API request handling
│   │   ├── authService.js # Authentication service
│   │   └── domain/        # Domain-specific API services
│   ├── store/             # Redux store configuration
│   │   ├── aiSlice.js     # AI state management
│   │   ├── authSlice.js   # Authentication state management
│   │   ├── documentSlice.js # Document state management
│   │   └── index.js       # Store configuration
│   ├── App.js             # Main application component
│   └── index.js           # Application entry point
├── Dockerfile             # Container definition
└── package.json           # Node.js dependencies
```

### AWS-Native Implementation
```
aws-native/
├── infrastructure/        # CloudFormation templates
│   ├── templates/         # Core infrastructure templates
│   │   ├── network.yaml   # VPC, subnets, security groups
│   │   ├── ecs-cluster.yaml # ECS cluster and IAM roles
│   │   └── documentdb.yaml # DocumentDB cluster
│   ├── deploy.sh          # Infrastructure deployment script
│   └── teardown.sh        # Infrastructure cleanup script
├── ecs/                   # ECS resources
│   ├── task-definitions/  # Container configurations
│   ├── services/          # ECS service templates
│   └── scripts/           # Utility scripts
├── docs/                  # Documentation
│   ├── deployment-guide.md # Full deployment instructions
│   ├── direct-deployment.md # Step-by-step command record
│   ├── comparison.md      # EKS vs. AWS-native comparison
│   └── next-steps.md      # Additional tasks
└── README.md              # AWS-native overview
```

### Deployment Files
```
deploy/
├── aws/                   # AWS configuration for EKS
│   ├── alb-iam-policy.json # ALB controller policy
│   ├── cluster-config.yaml # EKS cluster configuration
│   ├── ecr-repos.txt      # ECR repository information
│   └── nodegroup.yaml     # EKS node group configuration
└── k8s/                   # Kubernetes manifests
    ├── aide-configmaps.yaml # Application ConfigMaps
    ├── aide-docdb-data-job.yaml # DocumentDB data loading job
    ├── aide-services.yaml # Service definitions
    ├── alb-ingress-class.yaml # ALB ingress class
    ├── aws-load-balancer-sa.yaml # LoadBalancer service account
    ├── backend-deployment-template.yaml # Backend deployment template
    ├── backend-nodeport.yaml # NodePort for backend
    ├── certificate.crt    # TLS certificate
    ├── controller-v2.5.4.yaml # AWS Load Balancer controller
    ├── csr.pem            # Certificate signing request
    ├── frontend-deployment-template.yaml # Frontend deployment template
    ├── frontend-nodeport.yaml # NodePort for frontend
    ├── generate-deployment.sh # Script to generate deployment files
    ├── generate-secrets.sh    # Script to generate Kubernetes secrets
    ├── ingress-complete.yaml # Complete ingress configuration
    ├── namespace.yaml     # AIDE namespace
    └── secrets-template.yaml # Template for Kubernetes secrets
```

## Development Roadmap

### Core Infrastructure (Completed)
- ✅ Project setup and architecture
- ✅ Base service implementation
- ✅ Frontend and backend integration
- ✅ AWS EKS cluster deployment
- ✅ Container orchestration setup
- ✅ Application Load Balancer configuration
- ✅ AWS-native parallel implementation with ECS/Fargate
- ✅ Automated deployment with environment-aware scripts
- ✅ Template-based deployment and secrets management

### Security and Authentication (Completed)
- ✅ AWS Cognito implementation
- ✅ JWT-based API authentication
- ✅ Authentication middleware
- ✅ Login frontend interface
- ✅ Redux auth state management
- ✅ Protected route implementation
- ✅ Token handling and management
- ✅ Centralized auth service architecture
- ✅ API request authentication interceptors
- ✅ User management documentation and tools

### Database and Storage (Completed)
- ✅ Amazon DocumentDB setup in EKS VPC
- ✅ TLS/SSL encryption configuration
- ✅ Security group configuration for cluster access
- ✅ Backend integration with DocumentDB
- ✅ Sample document loading for testing
- ✅ Production-ready database configuration
- ✅ Persistent storage across pod restarts

### AI Model Integration (Completed)
- ✅ Centralized model configuration management
- ✅ Provider-neutral model access methods
- ✅ Dynamic provider detection based on model types
- ✅ Multi-provider support (OpenAI, Google AI, Bedrock)
- ✅ Robust response validation for all providers
- ✅ Advanced features like Google Search grounding
- ✅ Asynchronous completion workflows with fallback mechanisms
- ✅ Detailed logging and instrumentation
- ✅ Token-aware context management

### Document Processing and Analysis 
- ✅ PDF extraction enhancements
- ✅ Financial document structure analysis
- ✅ Document comparison
- ✅ Source attribution to input documents

### Production Enhancements
- ✅ DocumentDB for production-grade storage
- ✅ TLS encryption for database communication
- ✅ Kubernetes deployment optimization
- ✅ AWS-native parallel deployment option
- ✅ Secrets management and secure configuration
- ✅ CI/CD pipeline implementation
- ✅ Enhanced monitoring and alerting

## Security and Controls

AIDE implements comprehensive security controls:
- AWS IAM roles and policies for access control
- EKS security groups for network isolation
- VPC configuration for secure database access
- TLS encryption for DocumentDB connections
- Kubernetes RBAC for API authentication and authorization
- Containerized application components for isolation
- AWS Cognito for enterprise-grade authentication
- JWT-based authentication for application users
- Protected routes and endpoints
- Secure token handling and validation
- Comprehensive audit logging
- Kubernetes secrets for managing sensitive information
- No hardcoded credentials in deployment files
- Proper TLS certificate management
- Single source of truth for configuration (.env.local)
- Template-based secret management for Kubernetes

## Security Best Practices

The following security best practices have been implemented:
- All credentials are stored in Kubernetes secrets or AWS SSM Parameter Store
- Private keys are never stored in the repository
- TLS encryption is used for all database connections
- Deployment scripts use environment variables for sensitive information
- The .gitignore file prevents credential files from being committed
- API keys and passwords are managed through secrets
- Deployment templates do not contain sensitive information
- Sensitive information is only present in .env.local and Kubernetes secrets
- Environment-specific configuration is handled securely

## Command Reference

### Deployment Operations
```bash
# Full deployment process
./deploy.sh

# Quick restart without rebuilding
./deploy.sh --restart

# Rollback to previous version
./deploy.sh --rollback

# Skip specific steps
./deploy.sh --skip-build --skip-secrets
```

### Kubernetes Operations (EKS)
```bash
# Check pod status
kubectl get pods -n aide

# View logs for a specific pod
kubectl logs -n aide POD_NAME

# Get all resources in the namespace
kubectl get all -n aide

# Describe a specific resource
kubectl describe pod POD_NAME -n aide

# Execute command in a pod
kubectl exec -it POD_NAME -n aide -- bash

# Manage secrets
kubectl get secrets -n aide
kubectl describe secret SECRET_NAME -n aide
```

### AWS-Native Operations (ECS)
```bash
# Check ECS cluster status
aws ecs describe-clusters --clusters aide-aws-native-cluster --region ap-southeast-1

# List services in the cluster
aws ecs list-services --cluster aide-aws-native-cluster --region ap-southeast-1

# Describe a service
aws ecs describe-services --cluster aide-aws-native-cluster --services aide-aws-native-be-direct --region ap-southeast-1

# List running tasks
aws ecs list-tasks --cluster aide-aws-native-cluster --region ap-southeast-1

# Describe a task
aws ecs describe-tasks --cluster aide-aws-native-cluster --tasks TASK_ARN --region ap-southeast-1

# View CloudWatch logs
aws logs get-log-events --log-group-name /ecs/aide-aws-native --log-stream-name "backend/aide-backend/TASK_ID" --region ap-southeast-1
```

### AWS DocumentDB Operations
```bash
# Get DocumentDB cluster information
aws docdb describe-db-clusters --db-cluster-identifier aide-docdb-eks

# Get DocumentDB instance information
aws docdb describe-db-instances --db-instance-identifier aide-docdb-instance1-eks

# Create manual snapshot
aws docdb create-db-cluster-snapshot \
  --db-cluster-identifier aide-docdb-eks \
  --db-cluster-snapshot-identifier aide-docdb-snapshot-manual
```

### Docker Operations
```bash
# Build images
docker build -t aide-backend:latest ./backend
docker build -t aide-frontend:latest ./frontend

# Push to ECR
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
REGION=$(aws configure get region)
aws ecr get-login-password --region $REGION | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-backend:latest
docker push ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/aide-frontend:latest
```

### CI/CD Operations
```bash
# Trigger CI workflow manually
gh workflow run "CI - Run Tests"

# View GitHub Actions logs
gh run list --workflow "CI - Run Tests"
gh run view RUN_ID

# Run tests locally (same as CI)
cd backend
python -m pytest tests/ -v

# Add a new test
touch backend/tests/test_new_feature.py
```

### User Management Operations

For detailed user management operations, please refer to the [User Management Guide](./docs/user-management-guide.md) which provides complete instructions for:
- Creating new users
- Managing existing users
- Resetting passwords
- Enabling/disabling user accounts
- Configuring user permissions

## Troubleshooting

### Common Issues and Solutions

1. **DocumentDB Connection Issues**:
   - Verify TLS certificate is mounted correctly
   - Check security group rules allow traffic from EKS nodes
   - Ensure the connection string parameters are correct
   - Use proper TLS CA file path in the connection string
   - For AWS-native deployment, verify the TLS_INSECURE_SKIP_VERIFY flag is set

2. **Backend Pod Health Checks Failing**:
   - Check backend logs for connection issues
   - Verify the health endpoint implementation
   - Ensure all required environment variables are set
   - For ECS tasks, check CloudWatch logs for container startup failures
   - Verify async endpoints use await correctly

3. **Sample Data Issues**:
   - Run the sample data loader script from inside a backend pod
   - Verify DocumentDB connectivity before attempting to load data
   - Check for proper TLS certificate configuration

4. **Authentication Problems**:
   - Verify Cognito user pool and client ID settings
   - Check JWT token validation in authentication middleware
   - Examine auth headers in API requests
   - See the User Management Guide for user-specific issues

5. **ALB Ingress Issues (EKS)**:
   - Check AWS Load Balancer Controller logs
   - Verify ingress resource configuration
   - Ensure target groups are properly configured

6. **ECS Service Deployment Issues (AWS-Native)**:
   - Check if ECR repositories exist and contain images
   - Verify Fargate task networking configuration
   - Check CloudWatch logs for container errors
   - Ensure security group rules allow proper communication

7. **ALB Listener Rule Conflicts (AWS-Native)**:
   - Check priority settings for path-based routing
   - Verify health check settings for target groups
   - Ensure container ports match target group ports

8. **Kubernetes Secrets Issues**:
   - Verify secrets are created correctly using `kubectl get secrets -n aide`
   - Ensure deployment manifests reference the correct secret names and keys
   - Check for environment variable naming consistency

9. **CI/CD Workflow Issues**:
   - Check GitHub repository secrets are properly configured
   - Verify MongoDB container starts correctly in CI environment
   - Check that Python and Node.js versions match expected versions
   - Ensure uv is properly installing dependencies

10. **AI Model Integration Issues**:
    - Verify API keys are correctly set in environment variables
    - Check provider-specific error messages in logs
    - Ensure proper error handling in model interactions
    - Verify model IDs are correctly configured in `.env.local`
    - Check for proper initialization of provider clients
    - For Google AI models, ensure correct library is installed (`google-genai>=1.9.0`)
    - For OpenAI, check proper AsyncOpenAI client initialization

---

AIDE integrates multiple advanced AI providers with thoroughly tested functionality. We've established a flexible, provider-agnostic architecture where OpenAI, Google AI (with full grounding capabilities), and AWS Bedrock models work seamlessly through a unified interface with intelligent fallback mechanisms. The multi-provider ModelManager implementation provides sophisticated error handling, response validation, and detailed logging that makes the system both powerful and maintainable.

The deployment options to both AWS EKS and the AWS-native approach with ECS/Fargate offer flexibility and choices for different deployment scenarios. Both approaches enable scalable, container-based operation with enterprise-grade security, data persistence, and management capabilities. The CI/CD implementation ensures code quality through automated testing and streamlines the deployment process.