# AIDE Development Environment Setup Guide

**Version 0.40.05 | May 03, 2025**

This guide provides comprehensive instructions for setting up a local development environment for the AIDE (AI Deal Evaluation) platform. It covers setting up all required dependencies, configuring the database, and getting both the backend and frontend running for development purposes.

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Environment Setup](#2-environment-setup)
3. [Project Setup](#3-project-setup)
4. [MongoDB Configuration](#4-mongodb-configuration)
5. [Backend Setup](#5-backend-setup)
6. [Frontend Setup](#6-frontend-setup)
7. [Running the Application](#7-running-the-application)
8. [Troubleshooting](#8-troubleshooting)
9. [Development Tools](#9-development-tools)
10. [CI/CD Integration](#10-cicd-integration)
11. [User Management](#11-user-management)

## 1. Prerequisites

### System Requirements
- Ubuntu 24.04 or newer
- At least 8GB RAM (16GB+ recommended)
- 20GB+ free disk space

## 2. Environment Setup

### Install Essential Tools

```bash
# Update package lists
sudo apt update

# Install essential development tools
sudo apt install -y build-essential git curl wget unzip python3-pip python3-venv jq lsof

# Install AWS CLI v2
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
rm -rf aws awscliv2.zip

# Verify AWS CLI installation
aws --version
```

### Install Node.js

```bash
# Install Node.js via NodeSource
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Verify installation
node --version
npm --version
```

### Install Docker and Docker Compose

```bash
# Install dependencies
sudo apt install -y ca-certificates curl

# Add Docker's official GPG key
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Add the repository to Apt sources
echo \
  "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Update package lists
sudo apt update

# Install Docker packages
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Add your user to the docker group to run Docker without sudo
sudo usermod -aG docker $USER

# Verify Docker installation (may require logout/login or reboot)
docker --version
docker compose version
```

**IMPORTANT**: After adding your user to the docker group, you must log out and log back in, or reboot your system for the changes to take effect.

### Configure AWS Credentials

```bash
# Configure AWS CLI with credentials
aws configure
```

When prompted, enter:
- AWS Access Key ID
- AWS Secret Access Key
- Default region name (e.g., ap-southeast-1)
- Default output format (json)

> **⚠️ SECURITY WARNING**  
> Never store actual AWS credentials in documentation, scripts, or code that may be committed to repositories.
> Use secure credential management practices, especially for production environments.

## 3. Project Setup

### Clone the Repository

```bash
# Create directory structure
mkdir -p ~/git/keppel

# Clone the repository
cd ~/git/keppel
git clone https://github.com/deepvertical-ai/aide.git aide

# Navigate to the project root
cd aide
```

### Create Development Data Directory

```bash
# Create a directory for development data within the project
mkdir -p ~/git/keppel/aide/dev-data/mongodb
```

## 4. MongoDB Configuration

MongoDB is used for both document storage and application state management.

### Start MongoDB Container

```bash
# Start MongoDB container
docker run -d --name aide-mongodb \
  -p 27017:27017 \
  -v ~/git/keppel/aide/dev-data/mongodb:/data/db \
  --restart=always \
  --env MONGO_INITDB_ROOT_USERNAME=root \
  --env MONGO_INITDB_ROOT_PASSWORD=[MONGODB_ROOT_PASSWORD] \
  --env MONGO_INITDB_DATABASE=aide_db \
  mongo:latest
```

### Create Required User

```bash
# Wait a moment for MongoDB to initialize
sleep 3

# Create user with required permissions
docker exec -it aide-mongodb mongosh -u root -p [MONGODB_ROOT_PASSWORD] --authenticationDatabase admin --eval "
use admin;
db.createUser({
  user: '[MONGODB_APP_USER]',
  pwd: '[MONGODB_APP_PASSWORD]',
  roles: [
    { role: 'readWrite', db: 'aide_db' },
    { role: 'dbAdmin', db: 'aide_db' }
  ]
});
"
```

### MongoDB Container Management

If you need to start/stop the container later:

```bash
# Start MongoDB container if it's stopped
docker start aide-mongodb

# Stop the container when not needed
docker stop aide-mongodb

# Check container status
docker ps | grep aide-mongodb
```

### MongoDB Configuration Details

- **Container Name**: aide-mongodb
- **Port**: 27017 (mapped to host)
- **Data Location**: ~/git/keppel/aide/dev-data/mongodb
- **Restart Policy**: always (auto-restart after system reboots)
- **Root Credentials**: 
  - Username: root
  - Password: [MONGODB_ROOT_PASSWORD]
- **Application User**:
  - Username: [MONGODB_APP_USER]
  - Password: [MONGODB_APP_PASSWORD]
  - Authentication Database: admin
  - Roles: readWrite and dbAdmin on aide_db

### MongoDB Access

```bash
# Connect as application user
docker exec -it aide-mongodb mongosh -u [MONGODB_APP_USER] -p [MONGODB_APP_PASSWORD] --authenticationDatabase admin

# Connect as root user
docker exec -it aide-mongodb mongosh -u root -p [MONGODB_ROOT_PASSWORD] --authenticationDatabase admin
```

## 5. Backend Setup

### Create Virtual Environment

```bash
# Navigate to the backend directory
cd ~/git/keppel/aide/backend

# Create a Python virtual environment
python3 -m venv .venv

# Activate the virtual environment
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Install Development Tools (Optional)

```bash
# Install useful development tools
pip install black isort pytest-asyncio pytest-cov
```

### Backend Configuration

The backend is configured via `.env.local` in the backend directory. This file contains:

- API settings
- MongoDB connection details
- API keys for AI services
- Model configurations

> **⚠️ SECURITY WARNING**  
> The `.env.local` file contains sensitive configuration. Never commit this file to version control.
> Use template files for documentation and add `.env.local` to your `.gitignore`.

Key settings in this file:
```
# API Settings
API_ENV=development
DEBUG=True
PORT=8000
API_VERSION=v1

# MongoDB
MONGODB_URL=mongodb://[MONGODB_APP_USER]:[MONGODB_APP_PASSWORD]@localhost:27017
MONGODB_DB_NAME=aide_db
MONGODB_CONNECT_TIMEOUT_MS=5000
MONGODB_SOCKET_TIMEOUT_MS=10000

# AI Model Config
PRIMARY_MODEL=o1
FALLBACK_MODEL=gpt-4o-mini
ULTRA_CONTEXT_MODEL=gemini-2.0-flash-001
TEXT_EXTRACT_MODEL=gemini-2.0-flash-001
GROUNDING_MODEL=gemini-2.0-flash-001

# AWS Cognito Settings
COGNITO_REGION=ap-southeast-1
COGNITO_USER_POOL_ID=[COGNITO_USER_POOL_ID]
COGNITO_CLIENT_ID=[COGNITO_CLIENT_ID]
```

## 6. Frontend Setup

### Install Dependencies

```bash
# Navigate to the frontend directory
cd ~/git/keppel/aide/frontend

# Install dependencies
npm install
```

### Frontend Configuration

The frontend uses minimal configuration:

```bash
# Create frontend local environment configuration
cat > .env.local << 'EOF'
REACT_APP_API_URL=http://localhost:8000
EOF
```

## 7. Running the Application

### Running for Development

For development work, run the backend and frontend in separate terminal windows to maintain full visibility into logs:

**Terminal 1 - Start the Backend:**
```bash
# Ensure MongoDB is running first
docker start aide-mongodb 2>/dev/null || docker run -d --name aide-mongodb \
  -p 27017:27017 \
  -v ~/git/keppel/aide/dev-data/mongodb:/data/db \
  --restart=always \
  --env MONGO_INITDB_ROOT_USERNAME=root \
  --env MONGO_INITDB_ROOT_PASSWORD=[MONGODB_ROOT_PASSWORD] \
  --env MONGO_INITDB_DATABASE=aide_db \
  mongo:latest

# Then start the backend
cd ~/git/keppel/aide/backend
source .venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

**Terminal 2 - Start the Frontend:**
```bash
cd ~/git/keppel/aide/frontend
npm start
```

### Development URLs

- **Backend API**: http://localhost:8000
- **Frontend UI**: http://localhost:3000
- **API Documentation**: http://localhost:8000/docs
- **Health Check**: http://localhost:8000/health

### Stopping the Application

- To stop the backend or frontend: Press `Ctrl+C` in the respective terminal
- To stop MongoDB: `docker stop aide-mongodb`

## 8. Troubleshooting

### Common Issues and Solutions

#### MongoDB Connection Problems

If the data_service fails to initialize with a connection error:

1. Check if the MongoDB container is running:
   ```bash
   docker ps | grep aide-mongodb
   ```

2. If not running, start it:
   ```bash
   docker start aide-mongodb
   ```

3. Verify the user is correctly set up:
   ```bash
   docker exec -it aide-mongodb mongosh -u root -p [MONGODB_ROOT_PASSWORD] --authenticationDatabase admin
   use admin
   db.getUsers()
   ```

4. If the user doesn't exist, create it:
   ```bash
   docker exec -it aide-mongodb mongosh -u root -p [MONGODB_ROOT_PASSWORD] --authenticationDatabase admin
   use admin
   db.createUser({
     user: '[MONGODB_APP_USER]',
     pwd: '[MONGODB_APP_PASSWORD]',
     roles: [
       { role: 'readWrite', db: 'aide_db' },
       { role: 'dbAdmin', db: 'aide_db' }
     ]
   });
   ```

#### Port Already in Use

If port 8000 or 3000 is already in use:

1. Find processes using the port:
   ```bash
   lsof -i:8000
   ```

2. Kill the process:
   ```bash
   kill -9 <PID>
   ```

#### Missing Virtual Environment

If the virtual environment is missing or corrupted:

```bash
cd ~/git/keppel/aide/backend
rm -rf .venv
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

#### Changes Not Reflecting in Frontend

If changes to the frontend code aren't showing up:

1. Clear browser cache
2. Restart the frontend application
3. Check the browser console for errors

#### Authentication Issues

If you encounter login or authentication problems:

1. Check Cognito configuration in `.env.local`
2. Verify user exists in Cognito user pool
3. See the [User Management Guide](./user-management-guide.md) for detailed user administration instructions

## 9. Development Tools

### Database Development Tools

AIDE provides development tools for database operations in `backend/scripts/db/dev/`:

```bash
# Navigate to the dev scripts directory
cd ~/git/keppel/aide/backend/scripts/db/dev

# Run the local database shell
./docdb_dev.sh

# List collections
./docdb_dev.sh --collections

# Show database stats
./docdb_dev.sh --stats
```

### Running Tests

```bash
# Navigate to the backend directory
cd ~/git/keppel/aide/backend

# Activate virtual environment
source .venv/bin/activate

# Run different test categories
./run_tests.sh standard       # Run standard tests
./run_tests.sh completion     # Run completion tests
./run_tests.sh all            # Run all tests
```

### Docker Management Commands

```bash
# View MongoDB logs
docker logs aide-mongodb

# Check all running containers
docker ps

# Remove MongoDB container (will lose data if not using volume)
docker rm -f aide-mongodb
```

## 10. CI/CD Integration

### GitHub Actions Workflows

AIDE uses two GitHub Actions workflows:

1. **CI Workflow**:
   - Runs on all branch pushes and pull requests
   - Executes unit tests for backend and frontend
   - Verifies code quality and functionality
   
2. **CD Workflow**:
   - Runs only on pushes to main/master
   - Builds and pushes Docker images to ECR
   - Uses the version extracted from commit messages or uses a timestamp-based version
   - Does not directly deploy to Kubernetes (handled by `deploy.sh`)

### Deployment Script

The `deploy.sh` script at the project root handles production deployment:

```bash
# Full deployment
./deploy.sh

# Deployment options
./deploy.sh --restart     # Quick restart without rebuilding
./deploy.sh --rollback    # Rollback to previous version
./deploy.sh --skip-build  # Skip building images
./deploy.sh --skip-push   # Skip pushing images to ECR
./deploy.sh --skip-deploy # Skip Kubernetes deployment
```

### Production Endpoints

- External URL: [AIDE_FRONTEND_URL]
- Production health check: [AIDE_HEALTH_URL]

## 11. User Management

For user management and authentication, AIDE uses AWS Cognito. Detailed instructions for managing users are available in the [AIDE User Management Guide](./user-management-guide.md).

This guide covers:
- Adding new users to the system
- Managing user credentials
- Troubleshooting authentication issues
- Security best practices for user management

For local development, the default authentication flow can be tested with the user credentials provided by your administrator.

---

## Version History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
| 0.30.01 | April 16, 2025 | Deep Vertical AI | Initial documentation |
| 0.33.09 | April 20, 2025 | Deep Vertical AI | Updated with MongoDB setup and troubleshooting |
| 0.40.00 | May 02, 2025 | Deep Vertical AI | Added user management section and security warnings |
| 0.40.05 | May 03, 2025 | Deep Vertical AI | Minor updates to align with other AIDE documentation |
