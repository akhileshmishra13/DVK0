# AIDE User Management Guide

**Version 0.40.05 | May 3, 2025**

## Table of Contents

1. [Introduction](#1-introduction)
2. [AWS Cognito Overview](#2-aws-cognito-overview)
3. [AWS Console Access](#3-aws-console-access)
4. [User Management via AWS Console](#4-user-management-via-aws-console)
5. [User Management via AWS CLI](#5-user-management-via-aws-cli)
6. [User Permissions and Access Levels](#6-user-permissions-and-access-levels)
7. [Troubleshooting Common Issues](#7-troubleshooting-common-issues)
8. [Security Best Practices](#8-security-best-practices)
9. [Appendix: Command Reference](#9-appendix-command-reference)

## 1. Introduction

This document provides comprehensive instructions for managing users in the AIDE (AI Deal Evaluation) platform. As the root user of the KAI Accelerator, Keppel has full control over user access management through AWS Cognito. This guide explains the procedures for creating, modifying, and managing user accounts for AIDE.

> **⚠️ SECURITY WARNING**  
> This document refers to AWS account credentials, Cognito configuration, and other sensitive information.
> - Never store actual credentials in any documentation
> - Never commit sensitive information to Git repositories
> - Always use secure methods to share credentials (password managers, secure vaults)
> - Actual credential values should be obtained directly from Keppel's authorized security team

## 2. AWS Cognito Overview

AIDE uses AWS Cognito for secure user authentication and management. Key components include:

- **User Pool**: A centralized directory containing all user accounts and their attributes
- **App Client**: The application registered with Cognito that users will authenticate against
- **User Attributes**: Information stored about each user (email, name, etc.)

**AIDE Configuration**:
- User Pool ID: `[COGNITO_USER_POOL_ID]` (in ap-southeast-1 region)
- Client ID: `[COGNITO_CLIENT_ID]`
- Region: `ap-southeast-1`

> **Note**: Actual Cognito pool and client IDs should be obtained by authorised Keppel personnel from the AWS console or from Keppel's security team. These values should never be stored in public documentation.

## 3. AWS Console Access

### Accessing the AWS Management Console

Keppel administrators can access the AWS Management Console using the company's approved access method:

```
Sign-in URL: [AWS_ACCOUNT_SIGNIN_URL]
Username: [ADMIN_USERNAME]
Password: [Provided by security team]
MFA: Required for administrative access
```

> **Note**: Actual sign-in URLs, usernames, and passwords should never be documented in files that could be committed to version control. Contact Keppel's IT/security team for access.

### Navigating to the Cognito Service

1. Sign in to the AWS Management Console
2. In the search bar at the top, type "Cognito" and select it from the results
3. In the Cognito dashboard, click "Manage User Pools"
4. Select the AIDE user pool from the list

## 4. User Management via AWS Console

### Viewing Existing Users

1. In the Cognito User Pool dashboard, select "Users and groups" from the left navigation
2. You'll see a list of all existing users with their usernames, status, and creation dates

### Creating a New User (Console)

1. In the Users list, click the "Create user" button
2. Select "Send an email invitation" or "Create the user without an invitation"
3. Enter the user's information:
   - Email address (also serves as username)
   - Name (optional)
   - Phone number (optional)
   - Temporary password (if not sending an invitation)
4. Click "Create user"

### Resetting a User's Password (Console)

1. In the Users list, find and select the user that needs a password reset
2. Click the "Actions" dropdown and select "Reset password"
3. Choose whether to generate a temporary password or set a custom one
4. Optionally select "Mark phone number as verified" if applicable
5. Click "Reset" to confirm

### Disabling/Enabling a User (Console)

1. In the Users list, find and select the user
2. Click the "Actions" dropdown and select "Disable" or "Enable"
3. Confirm the action when prompted

## 5. User Management via AWS CLI

### Installing and Configuring AWS CLI

If AWS CLI is not already installed:

```bash
# Install AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
rm -rf aws awscliv2.zip

# Configure AWS CLI (never store actual credentials in documentation)
aws configure
# When prompted, enter credentials provided by your security team
```

> **⚠️ IMPORTANT SECURITY NOTE**  
> Never store AWS access keys or secret access keys in documentation, scripts, or code repositories.
> Use AWS IAM roles when possible or securely manage credentials using AWS credentials file with appropriate permissions.

### Listing All Users

```bash
# List all users in the user pool
aws cognito-idp list-users --user-pool-id [COGNITO_USER_POOL_ID]
```

### Getting User Details

```bash
# Get details about a specific user
aws cognito-idp admin-get-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username username@keppel.com
```

### Creating a New User

```bash
# Create a new user with temporary password
aws cognito-idp admin-create-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com" \
  --temporary-password "TemporaryPassword123!" \
  --user-attributes Name=email,Value=username@keppel.com Name=email_verified,Value=true
```

### Setting a Permanent Password

```bash
# Set a permanent password for a user
aws cognito-idp admin-set-user-password \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com" \
  --password "SecurePassword123!" \
  --permanent
```

### Resetting a User's Password

```bash
# Reset a user's password
aws cognito-idp admin-set-user-password \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com" \
  --password "NewPassword123!" \
  --permanent
```

### Disabling a User

```bash
# Disable a user
aws cognito-idp admin-disable-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com"
```

### Enabling a User

```bash
# Enable a user
aws cognito-idp admin-enable-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com"
```

## 6. User Permissions and Access Levels

AIDE implements a straightforward access model where all authenticated users have the same level of access to the application. There are no built-in roles or permission levels within the current implementation.

When planning for production use with more users, consider implementing:

1. **AWS IAM Identity Center** (formerly AWS SSO) for more advanced user management
2. **Integration with Keppel's existing SSO solution** using SAML or OIDC federation
3. **Role-based access control** within the application if different permission levels are required

## 7. Troubleshooting Common Issues

### User Cannot Log In

1. Verify the user exists in the Cognito user pool:
   ```bash
   aws cognito-idp admin-get-user \
     --user-pool-id [COGNITO_USER_POOL_ID] \
     --username "username@keppel.com"
   ```

2. Check if the user is enabled:
   - If the user status shows "DISABLED", enable the user:
     ```bash
     aws cognito-idp admin-enable-user \
       --user-pool-id [COGNITO_USER_POOL_ID] \
       --username "username@keppel.com"
     ```

3. Reset the user's password if necessary:
   ```bash
   aws cognito-idp admin-set-user-password \
     --user-pool-id [COGNITO_USER_POOL_ID] \
     --username "username@keppel.com" \
     --password "NewSecurePassword123!" \
     --permanent
   ```

### Email Verification Issues

If a user is not receiving verification emails:

1. Check if the email is already verified:
   ```bash
   aws cognito-idp admin-get-user \
     --user-pool-id [COGNITO_USER_POOL_ID] \
     --username "username@keppel.com"
   ```

2. Manually mark the email as verified:
   ```bash
   aws cognito-idp admin-update-user-attributes \
     --user-pool-id [COGNITO_USER_POOL_ID] \
     --username "username@keppel.com" \
     --user-attributes Name=email_verified,Value=true
   ```

### Account Locked Due to Failed Login Attempts

If a user's account is locked due to too many failed login attempts:

```bash
# Unlock the user's account and reset their password
aws cognito-idp admin-set-user-password \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com" \
  --password "NewSecurePassword123!" \
  --permanent
```

## 8. Security Best Practices

### Password Policies

The Cognito user pool is configured with the following password policy:
- Minimum length: 8 characters
- Requires uppercase letters
- Requires lowercase letters
- Requires numbers
- Requires special characters

When setting passwords manually, ensure they meet these requirements.

### Access Key Rotation

Regularly rotate the AWS access keys used for administrative access:

1. Create a new access key in the AWS IAM console
2. Update applications to use the new key
3. Disable (but don't immediately delete) the old key
4. After confirming everything works, delete the old key

### Administrative Access Audit

Periodically review who has administrative access to the Cognito user pool:

1. Review the IAM users and roles with access to Cognito
2. Remove any unnecessary access permissions
3. Ensure MFA is enabled for all administrative users

### Protecting Sensitive Information

- Never store AWS credentials, passwords, or configuration details in code repositories
- Use AWS Secrets Manager or Parameter Store for sensitive configuration
- Always use placeholder values in documentation
- Establish a secure method for sharing actual credential values within Keppel

## 9. Appendix: Command Reference

### User Management Commands

```bash
# List all users
aws cognito-idp list-users --user-pool-id [COGNITO_USER_POOL_ID]

# Get user details
aws cognito-idp admin-get-user --user-pool-id [COGNITO_USER_POOL_ID] --username "username@keppel.com"

# Create new user
aws cognito-idp admin-create-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com" \
  --temporary-password "Temp@123!" \
  --user-attributes Name=email,Value=username@keppel.com Name=email_verified,Value=true

# Set permanent password
aws cognito-idp admin-set-user-password \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com" \
  --password "SecurePassword123!" \
  --permanent

# Disable user
aws cognito-idp admin-disable-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com"

# Enable user
aws cognito-idp admin-enable-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com"

# Update user attributes
aws cognito-idp admin-update-user-attributes \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com" \
  --user-attributes Name=email,Value=newemail@keppel.com

# Delete user
aws cognito-idp admin-delete-user \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --username "username@keppel.com"
```

### User Pool Management Commands

```bash
# Describe user pool
aws cognito-idp describe-user-pool \
  --user-pool-id [COGNITO_USER_POOL_ID]

# Describe user pool client
aws cognito-idp describe-user-pool-client \
  --user-pool-id [COGNITO_USER_POOL_ID] \
  --client-id [COGNITO_CLIENT_ID]
```

---

## Version History

| Version | Date | Author | Description |
|---------|------|--------|-------------|
| 0.40.00 | May 2, 2025 | Deep Vertical AI | User management documentation |
| 0.40.00 | May 3, 2025 | Deep Vertical AI | Updated user management documentation |