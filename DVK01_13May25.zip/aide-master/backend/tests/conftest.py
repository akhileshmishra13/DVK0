# backend/tests/conftest.py - Updated with proper dependency patching

import pytest
import os
from fastapi.testclient import TestClient
from app.main import app
from unittest.mock import patch
from fastapi import Depends

# This will be our mock authenticated user
TEST_USER = {
    "sub": "test-user-id",
    "email": "test@example.com",
    "name": "Test User",
    "exp": 9999999999  # Far future expiration
}

# Original dependency
from app.utils.auth_utils import get_current_user

# We need a function that returns our test user
def get_test_user():
    return TEST_USER

@pytest.fixture
def client():
    """
    Test client for the FastAPI application
    """
    return TestClient(app)

@pytest.fixture
def auth_client():
    """
    Test client with authentication bypass for protected endpoints
    
    This approach patches the dependency injection system to use our test user
    instead of the real get_current_user function.
    """
    # Store original dependency
    original_dependency = app.dependency_overrides.copy()
    
    # Override dependency for testing
    app.dependency_overrides[get_current_user] = get_test_user
    
    # Create test client with auth header for middleware
    with TestClient(app) as client:
        client.headers.update({"Authorization": "Bearer test_token"})
        yield client
    
    # Restore original dependencies
    app.dependency_overrides = original_dependency

@pytest.fixture(scope="session", autouse=True)
def set_test_environment():
    """
    Set test environment variables
    """
    os.environ["API_ENV"] = "testing"
    os.environ["MONGODB_DB_NAME"] = "aide_test_db"