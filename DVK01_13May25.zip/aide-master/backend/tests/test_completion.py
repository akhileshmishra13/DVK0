# backend/tests/test_completion.py

import pytest
import logging
import os
import time
from fastapi.testclient import TestClient
from app.main import app

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("test_completion")

# Use a pytest marker to easily filter this test
@pytest.mark.completion
def test_direct_completion_endpoint(auth_client):  # Use auth_client instead of client
    """Test the actual /api/v1/completion endpoint with a direct prompt"""
    # Skip in CI unless explicitly enabled
    if os.environ.get("CI") == "true" and os.environ.get("RUN_COMPLETION_TESTS", "").lower() != "true":
        pytest.skip("Skipping completion test in CI. Set RUN_COMPLETION_TESTS=true to enable.")
    
    # Create a simple test request
    request_data = {
        "prompt": "What is the capital of France? Answer in one word.",
        "max_tokens": 50
    }
    
    # Use the real API endpoint with authenticated client
    logger.info("Sending completion request to API endpoint...")
    response = auth_client.post("/api/v1/completion", json=request_data)
    
    # Check response status
    assert response.status_code == 202, f"Expected status 202, got {response.status_code}: {response.text}"
    
    # Parse response
    data = response.json()
    assert data["status"] == "success", f"Expected success status, got: {data['status']}"
    assert "process_id" in data["data"], "Response should contain process_id"
    
    process_id = data["data"]["process_id"]
    logger.info(f"Completion process started with ID: {process_id}")
    
    # Poll the completion status
    max_attempts = 15  # Increased from 10 to give more time
    for attempt in range(max_attempts):
        logger.info(f"Polling attempt {attempt+1}/{max_attempts}...")
        
        # Get completion status
        status_response = auth_client.get(f"/api/v1/completion/{process_id}")
        
        # Check for errors
        if status_response.status_code != 200:
            logger.error(f"Status request failed: {status_response.status_code} - {status_response.text}")
            time.sleep(2)
            continue
            
        status_data = status_response.json()
        
        # Check if completed
        if status_data["data"]["status"] == "completed":
            logger.info("Process completed!")
            # Verify the completion has expected data
            assert "metadata" in status_data["data"], "Completion should include metadata"
            assert "completion" in status_data["data"]["metadata"], "Metadata should include completion"
            
            completion = status_data["data"]["metadata"]["completion"]
            assert "text" in completion, "Completion should contain text"
            assert "model" in completion, "Completion should identify model used"
            
            # Check response content
            logger.info(f"Model used: {completion['model']}")
            logger.info(f"Response text: {completion['text']}")
            
            # Verify it contains the right answer
            assert "paris" in completion["text"].lower(), f"Expected Paris in response, got: {completion['text']}"
            return
            
        elif status_data["data"]["status"] == "failed":
            logger.error(f"Process failed: {status_data['data']['current_step']}")
            assert False, f"Completion process failed: {status_data['data']['current_step']}"
            
        # Wait before polling again
        time.sleep(3)  # Increased from 2 seconds to 3 seconds
    
    # If we get here, the process didn't complete in time
    assert False, f"Completion process did not complete within {max_attempts} attempts"