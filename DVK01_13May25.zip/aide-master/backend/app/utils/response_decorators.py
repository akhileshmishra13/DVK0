# backend/app/utils/response_decorators.py

import time
import functools
import asyncio
from typing import Callable, TypeVar, Any, Dict, Optional
from fastapi import Response, status
from fastapi.responses import JSONResponse

from app.utils.response_util import ResponseUtil
from app.core.exceptions import BaseAPIException
from app.utils.logging_context import LoggingContext

F = TypeVar('F', bound=Callable)

def api_response(
    success_message: str = "Operation successful",
    success_status_code: int = status.HTTP_200_OK,
    error_status_code: int = status.HTTP_400_BAD_REQUEST,
    include_execution_time: bool = True
) -> Callable[[F], F]:
    """
    Decorator for API endpoints that standardizes response handling
    
    Args:
        success_message: Default message for successful responses
        success_status_code: Default status code for successful responses
        error_status_code: Default status code for error responses
        include_execution_time: Whether to include execution time in response
        
    Returns:
        Decorated function with standardized response handling
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        async def wrapped(*args, **kwargs):
            # Record start time if tracking execution time
            start_time = time.time() if include_execution_time else None
            
            try:
                # Call the original function
                result = await func(*args, **kwargs) if asyncio.iscoroutinefunction(func) else func(*args, **kwargs)
                
                # Calculate execution time
                execution_time_ms = (time.time() - start_time) * 1000 if start_time else None
                
                # If result is already a Response, return it as is
                if isinstance(result, Response):
                    return result
                
                # If result is a tuple (data, message, status_code), unpack it
                if isinstance(result, tuple) and len(result) in (2, 3):
                    if len(result) == 2:
                        data, message = result
                        status_code = success_status_code
                    else:
                        data, message, status_code = result
                    
                    return ResponseUtil.success_response(
                        data=data,
                        message=message,
                        status_code=status_code,
                        execution_time_ms=execution_time_ms
                    )
                
                # Otherwise, wrap the result in a standard response
                return ResponseUtil.success_response(
                    data=result,
                    message=success_message,
                    status_code=success_status_code,
                    execution_time_ms=execution_time_ms
                )
                
            except Exception as e:
                # Calculate execution time
                execution_time_ms = (time.time() - start_time) * 1000 if start_time else None
                
                # Log the exception
                import logging
                logger = logging.getLogger(func.__module__)
                logger.exception(f"Error in {func.__name__}: {str(e)}")
                
                # Return standardized error response
                return ResponseUtil.from_exception(
                    exception=e,
                    execution_time_ms=execution_time_ms
                )
        
        return wrapped
    
    return decorator