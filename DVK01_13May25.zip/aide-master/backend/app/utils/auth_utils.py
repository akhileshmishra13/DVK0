import aioboto3  
import time
from botocore.exceptions import ClientError
from fastapi import HTTPException, status, Request
from jose import JWTError, jwt
from app.core.config import settings
from app.models.auth import TokenPayload

# Create aioboto3 session
async def get_cognito_session():
    """Create and return a Cognito session"""
    try:
        session = aioboto3.Session(region_name=settings.COGNITO_REGION)
        return session
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create Cognito session: {str(e)}"
        )

async def get_cognito_user(email: str, password: str):
    """Authenticate user with Cognito and return tokens (async version)"""
    try:
        session = await get_cognito_session()
        async with session.client('cognito-idp') as cognito_client:
            response = await cognito_client.initiate_auth(
                ClientId=settings.COGNITO_CLIENT_ID,
                AuthFlow='USER_PASSWORD_AUTH',
                AuthParameters={
                    'USERNAME': email,
                    'PASSWORD': password
                }
            )
            return response['AuthenticationResult']
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'NotAuthorizedException':
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password"
            )
        elif error_code == 'UserNotFoundException':
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=str(e)
            )

def validate_token(token: str):
    """Validate JWT token and return user information"""
    try:
        # Decode token (signature verification disabled in dev)
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=["RS256"],
            options={"verify_signature": False}
        )
        token_data = TokenPayload(**payload)
        
        if token_data.exp and token_data.exp < time.time():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
            
        return payload
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
        )

def get_current_user(request: Request):
    """Extract Bearer token from Authorization header and return validated user"""
    auth_header = request.headers.get("Authorization")

    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Authorization header"
        )

    token = auth_header.split("Bearer ")[1].strip()
    payload = validate_token(token)

    if not payload.get("sub"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token payload"
        )

    return payload