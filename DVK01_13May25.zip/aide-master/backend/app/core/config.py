# backend/app/core/config.py

from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    PROJECT_NAME: str = "AIDE API"
    PROJECT_VERSION: str = os.getenv("PROJECT_VERSION", "0.20.00")
    API_ENV: str = "development"
    DEBUG: bool = True
    PORT: int = 8000
    
    # MongoDB
    MONGODB_URL: str = "mongodb://aideusr:aidepwd@localhost:27017"
    MONGODB_DB_NAME: str = "aide_db"
    MONGODB_CONNECT_TIMEOUT_MS: int = 5000
    MONGODB_SOCKET_TIMEOUT_MS: int = 10000
    
    # AWS Cognito Settings
    COGNITO_REGION: str = "ap-southeast-1"
    COGNITO_USER_POOL_ID: str = "ap-southeast-1_xxaqtO67f"
    COGNITO_CLIENT_ID: str = "6mo82mnns7n2pv64cnlrhrogjr"
    
    # JWT
    SECRET_KEY: str = "your-secret-key-here"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # Logging
    LOG_LEVEL: str = "INFO"
    
    # Google AI
    GOOGLE_API_KEY: str = ""
    
    # OpenAI API - added for GPT model access
    OPENAI_API_KEY: str = ""
    
    # AI Model Config
    PRIMARY_MODEL: str = "gemini-2.5-flash-preview-04-17"
    FALLBACK_MODEL: str = "o1"
    ULTRA_CONTEXT_MODEL: str = "gemini-2.0-flash-001"
    TEXT_EXTRACT_MODEL: str = "gemini-2.0-flash-001"
    ADVANCED_REASONING_MODEL: str = "anthropic.claude-3-7-sonnet-20250219-v1:0"
    
    # Global Default Hyperparameters
    DEFAULT_MAX_TOKENS: int = 30000
    DEFAULT_TEMPERATURE: float = 0.7
    DEFAULT_TOP_P: float = 0.95
    
    # Bedrock Hyperparameters
    BEDROCK_MAX_TOKENS: int = 30000
    BEDROCK_TEMPERATURE: float = 0.7
    BEDROCK_TOP_P: float = 0.95
    BEDROCK_REASONING_BUDGET_RATIO: float = 0.3  # % of max_tokens used for reasoning
    BEDROCK_REASONING_MIN_BUDGET: int = 1024     # Minimum reasoning tokens
    
    # Google AI Hyperparameters
    GOOGLE_MAX_TOKENS: int = 30000
    GOOGLE_TEMPERATURE: float = 0.7
    GOOGLE_TOP_P: float = 0.95
    GOOGLE_TOP_K: int = 40
    GOOGLE_THINKING_ENABLED: bool = True  
    GOOGLE_THINKING_BUDGET: int = 8192    # tokens used for reasoning
    
    # OpenAI Hyperparameters
    OPENAI_MAX_TOKENS: int = 16384
    OPENAI_TEMPERATURE: float = 0.7
    OPENAI_TOP_P: float = 0.95
    OPENAI_FREQUENCY_PENALTY: float = 0.0
    OPENAI_PRESENCE_PENALTY: float = 0.0
    
    # AWS Bedrock
    AWS_REGION: str = "us-east-1"
    
    # API Version
    API_VERSION: str = "v1"
    
    class Config:
        env_file = ".env.local"

settings = Settings()