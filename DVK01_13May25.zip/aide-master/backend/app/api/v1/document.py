# backend/app/api/v1/document.py

from typing import Dict, Any, Optional, List
import uuid
import logging
from fastapi import APIRouter, Depends, UploadFile, File, Form, BackgroundTasks, Query, status, Response
from pydantic import BaseModel, Field

from app.utils.response_util import ResponseUtil
from app.utils.auth_utils import get_current_user
from app.services.data_service import DataService
from app.services.extraction_service import ExtractionService
from app.services.event_handler import EventHandler, ProcessStatus, EventType
from app.dependencies.services import get_data_service, get_event_handler, get_extraction_service
from app.core.exceptions import ResourceNotFoundError, DatabaseError # Import DatabaseError

# Create logger
logger = logging.getLogger(__name__)

# Create independent router - NO ROUTER-LEVEL DEPENDENCIES
document_router = APIRouter()

@document_router.post("/upload")
async def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    metadata: Optional[str] = Form(None),
    data_service: DataService = Depends(get_data_service),
    extraction_service: ExtractionService = Depends(get_extraction_service),
    event_handler: EventHandler = Depends(get_event_handler),
    current_user: dict = Depends(get_current_user)
):
    """Upload a document and initiate extraction"""
    process_id = f"upload_{uuid.uuid4()}" # Define process_id early for potential error handling
    try:
        logger.info(f"Document upload initiated by user {current_user.get('sub')} for file: {file.filename if file else 'None'}")

        # Create process tracking first
        await event_handler.create_process(
            process_id=process_id,
            process_type="document_upload",
            user_id=current_user.get("sub"),
            metadata={
                "filename": file.filename,
                "content_type": file.content_type
            }
        )

        # Update status
        await event_handler.update_process(
            process_id=process_id,
            status=ProcessStatus.RUNNING,
            percentage=10,
            current_step="Reading file"
        )

        # Read file content
        file_content = await file.read()
        if not file_content:
             logger.error(f"Upload failed for {file.filename}: File content is empty.")
             raise ValueError("Uploaded file content is empty.")


        # Update progress
        await event_handler.update_process(
            process_id=process_id,
            percentage=30,
            current_step="Storing document"
        )

        # Store document
        document_id = await data_service.store_document(
            file_content=file_content,
            filename=file.filename,
            metadata={
                "content_type": file.content_type,
                "upload_process_id": process_id,
                "user_id": current_user.get("sub")
                # 'document_id' is added within store_document
            }
        )

        # Update progress for starting extraction
        await event_handler.update_process(
            process_id=process_id,
            percentage=50,
            current_step="Starting document extraction"
        )

        # Start extraction in background
        background_tasks.add_task(
            process_extraction,
            document_id,
            process_id
            # Pass services via dependency injection resolution if needed, or rely on get_service within task
            # extraction_service=extraction_service, # Avoid passing instance directly if possible
            # event_handler=event_handler
        )

        return await ResponseUtil.success_response(
            data={
                "document_id": document_id,
                "process_id": process_id,
                "status": "processing"
            },
            message="Document uploaded successfully, processing started.",
            status_code=status.HTTP_201_CREATED # Use 201 for resource creation
        )
    except DatabaseError as db_err:
        logger.error(f"Database error during document upload: {db_err}", exc_info=True)
        await event_handler.update_process(
             process_id=process_id, status=ProcessStatus.FAILED, current_step=f"Database error: {db_err}"
        )
        return await ResponseUtil.from_exception(db_err)
    except ValueError as val_err: # Catch empty file error
        logger.error(f"Value error during document upload: {val_err}", exc_info=True)
        await event_handler.update_process(
             process_id=process_id, status=ProcessStatus.FAILED, current_step=f"Validation error: {val_err}"
        )
        # Return a 400 Bad Request for empty file
        return await ResponseUtil.error_response(
            message="Upload failed.",
            error_code="VALIDATION_ERROR",
            error_detail=str(val_err),
            status_code=status.HTTP_400_BAD_REQUEST
        )
    except Exception as e:
        logger.error(f"Unexpected error uploading document: {e}", exc_info=True) # Log full traceback
        # Update process on error using the locally defined process_id
        await event_handler.update_process(
            process_id=process_id,
            status=ProcessStatus.FAILED,
            current_step=f"Unexpected error during upload: {type(e).__name__}"
        )
        return await ResponseUtil.from_exception(e)


async def process_extraction(document_id: str, process_id: str):
    """Process document extraction in the background"""
    from app.dependencies.services import get_extraction_service, get_event_handler
    extraction_service: ExtractionService = get_extraction_service()
    event_handler: EventHandler = get_event_handler()

    try:
        logger.info(f"Background task started for extraction: doc_id={document_id}, process_id={process_id}")
        
        # Extract text - CHANGED: use PyPDF2 first (use_ai=False)
        await event_handler.update_process(
            process_id=process_id,
            percentage=60,
            current_step="Extracting document text with Python"
        )
        text = await extraction_service.extract_document_text(document_id, use_ai=False)
        logger.info(f"Text extraction completed for {document_id}. Text length: {len(text) if text else 0}")

        # Extract metadata
        await event_handler.update_process(
            process_id=process_id,
            percentage=75,
            current_step="Extracting document metadata with AI"
        )
        metadata = await extraction_service.extract_document_metadata(document_id)
        logger.info(f"Metadata extraction completed for {document_id}")

        # Extract structure (unchanged)
        await event_handler.update_process(
            process_id=process_id,
            percentage=90,
            current_step="Extracting document structure"
        )
        structure = await extraction_service.extract_document_structure(document_id)
        logger.info(f"Structure extraction completed for {document_id}")

        # Complete process
        await event_handler.update_process(
            process_id=process_id,
            status=ProcessStatus.COMPLETED,
            percentage=100,
            current_step="Extraction complete",
            metadata_updates={
                "extraction_complete": True,
                "structure_extracted": True
            }
        )

        await event_handler.add_event(
            process_id=process_id,
            event_type=EventType.COMPLETION,
            message="Document extraction completed successfully",
            data={"document_id": document_id}
        )
        logger.info(f"Background extraction task completed successfully for {document_id}")

    except Exception as e:
        # Error handling (unchanged)
        logger.error(f"Error during background extraction for {document_id}: {e}", exc_info=True)
        await event_handler.update_process(
            process_id=process_id,
            status=ProcessStatus.FAILED,
            current_step=f"Extraction error: {type(e).__name__}"
        )

        await event_handler.add_event(
            process_id=process_id,
            event_type=EventType.ERROR,
            message=f"Document extraction failed: {str(e)}",
            data={"error": str(e), "type": type(e).__name__}
        )


# IMPORTANT - Use empty string instead of "/" for base path to avoid FastAPI's redirect behavior
# Ensure path is "" for root of the router prefix
@document_router.get("") # Changed from "/" to ""
async def list_documents(
    data_service: DataService = Depends(get_data_service),
    current_user: dict = Depends(get_current_user)
):
    """List all documents - simplified to avoid pagination"""
    try:
        logger.info(f"List documents request received from user {current_user.get('sub')}")
        # Get all documents with default sorting
        documents = await data_service.list_documents(
            filters={},
            sort={"uploadDate": -1}
        )

        # --- FIX: Modify logging ---
        logger.info(f"Retrieved {len(documents)} documents for user {current_user.get('sub')}")
        # Avoid logging the entire potentially large 'documents' list content

        # Return documents directly with async ResponseUtil
        return await ResponseUtil.success_response(
            data=documents, # BSON serialization handled by ResponseUtil
            message="Documents retrieved successfully"
        )
    except DatabaseError as db_err:
         # Catch specific DatabaseError from DataService
         logger.error(f"Database error listing documents: {db_err}", exc_info=True)
         return await ResponseUtil.from_exception(db_err)
    except Exception as e:
        # Catch any other unexpected errors
        logger.error(f"Unexpected error in document list: {e}", exc_info=True)
        return await ResponseUtil.from_exception(e)

# --- (get_document and delete_document remain the same as previous correct version) ---
@document_router.get("/{document_id}")
async def get_document(
    document_id: str,
    data_service: DataService = Depends(get_data_service),
    current_user: dict = Depends(get_current_user)
):
    """Get document metadata by ID"""
    try:
        logger.info(f"Get document request for ID {document_id} by user {current_user.get('sub')}")
        document = await data_service.get_document(document_id)
        if document is None: # Check against None explicitly
            logger.warning(f"Document {document_id} not found.")
            raise ResourceNotFoundError(
                message="Document not found",
                detail=f"No document found with ID {document_id}"
            )

        logger.info(f"Document {document_id} retrieved successfully.")
        return await ResponseUtil.success_response(
            data=document,
            message="Document retrieved successfully"
        )
    except DatabaseError as db_err:
         logger.error(f"Database error retrieving document {document_id}: {db_err}", exc_info=True)
         return await ResponseUtil.from_exception(db_err)
    except ResourceNotFoundError as rnf_err:
         # Allow specific 404 handling
         return await ResponseUtil.from_exception(rnf_err)
    except Exception as e:
        logger.error(f"Unexpected error retrieving document {document_id}: {e}", exc_info=True)
        return await ResponseUtil.from_exception(e)
    
@document_router.get("/{document_id}/download")
async def download_document(
    document_id: str,
    data_service: DataService = Depends(get_data_service),
    current_user: dict = Depends(get_current_user)
):
    """Download a document by ID"""
    try:
        logger.info(f"Download request for document ID {document_id} by user {current_user.get('sub')}")
        
        # First, check if document exists
        document = await data_service.get_document(document_id)
        if document is None:
            logger.warning(f"Document {document_id} not found for download.")
            raise ResourceNotFoundError(
                message="Document not found",
                detail=f"No document found with ID {document_id} to download."
            )
        
        # Get document content
        content = await data_service.get_document_content(document_id)
        if not content:
            logger.error(f"Document content for {document_id} could not be retrieved.")
            raise ResourceNotFoundError(
                message="Document content not found",
                detail=f"Content for document ID {document_id} could not be retrieved."
            )
        
        # Log success
        logger.info(f"Document {document_id} downloaded successfully.")
        
        # Create a Response with the file content
        filename = document.get("filename", f"document-{document_id}.pdf")
        
        # Return file response with proper headers
        return Response(
            content=content,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Content-Length": str(len(content))
            }
        )
    except DatabaseError as db_err:
        logger.error(f"Database error downloading document {document_id}: {db_err}", exc_info=True)
        return await ResponseUtil.from_exception(db_err)
    except ResourceNotFoundError as rnf_err:
        return await ResponseUtil.from_exception(rnf_err)
    except Exception as e:
        logger.error(f"Unexpected error downloading document {document_id}: {e}", exc_info=True)
        return await ResponseUtil.from_exception(e)

@document_router.delete("/{document_id}")
async def delete_document(
    document_id: str,
    data_service: DataService = Depends(get_data_service),
    current_user: dict = Depends(get_current_user)
):
    """Delete a document by ID"""
    try:
        logger.info(f"Delete request for document ID {document_id} by user {current_user.get('sub')}")
        success = await data_service.delete_document(document_id)
        if not success:
            logger.warning(f"Document {document_id} not found for deletion.")
            raise ResourceNotFoundError(
                message="Document not found",
                detail=f"No document found with ID {document_id} to delete."
            )

        logger.info(f"Document {document_id} deleted successfully.")
        # For DELETE, 204 No Content is standard, return minimal success response
        # Although ResponseUtil doesn't strictly handle 204 perfectly (still includes body)
        # it's acceptable here. Or return Response(status_code=204) directly.
        return await ResponseUtil.success_response(
            data={"document_id": document_id, "deleted": True},
            message="Document deleted successfully",
            status_code=status.HTTP_200_OK # Changing to 200 as 204 shouldn't have body
        )
    except DatabaseError as db_err:
         logger.error(f"Database error deleting document {document_id}: {db_err}", exc_info=True)
         return await ResponseUtil.from_exception(db_err)
    except ResourceNotFoundError as rnf_err:
         return await ResponseUtil.from_exception(rnf_err) # Let specific handler create 404
    except Exception as e:
        logger.error(f"Unexpected error deleting document {document_id}: {e}", exc_info=True)
        return await ResponseUtil.from_exception(e)