# backend/app/api/v1/extraction.py

from fastapi import APIRouter, Depends, Query, BackgroundTasks, status
from typing import Dict, Any, Optional, List
import uuid
import logging

from app.utils.response_util import ResponseUtil
from app.utils.auth_utils import get_current_user
from app.core.exceptions import ValidationError, AIModelError, ResourceNotFoundError
from app.services.extraction_service import ExtractionService, ExtractionType
from app.dependencies.services import get_extraction_service

logger = logging.getLogger(__name__)

# Create independent router
extraction_router = APIRouter()

@extraction_router.get("/{document_id}/text")
async def extract_document_text(
    document_id: str,
    use_ai: bool = Query(True, description="Whether to use AI for extraction"),
    extraction_service: ExtractionService = Depends(get_extraction_service),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Extract text from a document"""
    try:
        text = await extraction_service.extract_document_text(
            document_id=document_id,
            use_ai=use_ai
        )
        
        return await ResponseUtil.success_response(
            data={"document_id": document_id, "text": text},
            message="Document text extracted successfully"
        )
    except ValidationError as e:
        raise ResourceNotFoundError(
            message="Document not found or invalid",
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error extracting document text: {str(e)}")
        return await ResponseUtil.from_exception(e)

@extraction_router.get("/{document_id}/metadata")
async def extract_document_metadata(
    document_id: str,
    extraction_service: ExtractionService = Depends(get_extraction_service),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Extract metadata from a document"""
    try:
        metadata = await extraction_service.extract_document_metadata(
            document_id=document_id
        )
        
        # Ensure we're returning a consistent structure
        # Check if metadata is None and provide an empty dict instead
        safe_metadata = metadata if metadata is not None else {}
        
        return await ResponseUtil.success_response(
            data={"document_id": document_id, "metadata": safe_metadata},
            message="Document metadata extracted successfully"
        )
    except ValidationError as e:
        raise ResourceNotFoundError(
            message="Document not found or invalid",
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error extracting document metadata: {str(e)}")
        return await ResponseUtil.from_exception(e)

@extraction_router.get("/{document_id}/structure")
async def extract_document_structure(
    document_id: str,
    extraction_service: ExtractionService = Depends(get_extraction_service),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Extract structured information from a document"""
    try:
        structure = await extraction_service.extract_document_structure(
            document_id=document_id
        )
        
        return await ResponseUtil.success_response(
            data={"document_id": document_id, "structure": structure},
            message="Document structure extracted successfully"
        )
    except ValidationError as e:
        raise ResourceNotFoundError(
            message="Document not found or invalid",
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error extracting document structure: {str(e)}")
        return await ResponseUtil.from_exception(e)

@extraction_router.post("/{document_id}")
async def extract_all_document_info(
    document_id: str,
    background_tasks: BackgroundTasks,
    extraction_service: ExtractionService = Depends(get_extraction_service),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """
    Extract all information from a document (text, metadata, structure)
    in the background and store in the document metadata
    """
    try:
        # Start background tasks for extraction
        process_id = f"extraction_{uuid.uuid4()}"
        
        # Queue the extraction tasks
        background_tasks.add_task(
            extraction_service.extract_document_text,
            document_id=document_id,
            use_ai=True
        )
        
        background_tasks.add_task(
            extraction_service.extract_document_metadata,
            document_id=document_id
        )
        
        background_tasks.add_task(
            extraction_service.extract_document_structure,
            document_id=document_id
        )
        
        return await ResponseUtil.success_response(
            data={"document_id": document_id, "process_id": process_id, "status": "processing"},
            message="Document extraction started",
            status_code=status.HTTP_202_ACCEPTED
        )
    except Exception as e:
        logger.error(f"Error starting document extraction: {str(e)}")
        return await ResponseUtil.from_exception(e)