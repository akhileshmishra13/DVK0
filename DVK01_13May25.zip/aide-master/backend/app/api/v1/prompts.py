# backend/app/api/v1/prompts.py

from fastapi import APIRouter, Depends, status
from typing import Dict, Any, List, Optional
import logging

from app.utils.response_util import ResponseUtil
from app.utils.auth_utils import get_current_user
from app.core.exceptions import ValidationError, ResourceNotFoundError
from app.dependencies.services import get_prompt_system
from app.services.base_service import ServiceStatus

logger = logging.getLogger(__name__)

# Create independent router 
prompt_router = APIRouter()

@prompt_router.get("/categories")
async def get_prompt_categories(
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Get all prompt categories and templates"""
    try:
        prompt_system = get_prompt_system()
        
        # Check if prompt system is initialized properly
        if prompt_system.status != ServiceStatus.RUNNING:
            # Return empty categories if the service isn't running
            return await ResponseUtil.success_response(
                data={},
                message="Prompt service not fully initialized"
            )
            
        categories = await prompt_system.get_categories()
        
        return await ResponseUtil.success_response(
            data=categories,
            message="Prompt categories retrieved successfully"
        )
    except Exception as e:
        logger.error(f"Error retrieving prompt categories: {str(e)}")
        # Return empty categories rather than throwing an error
        return await ResponseUtil.success_response(
            data={},
            message=f"Error retrieving prompt categories: {str(e)}"
        )

@prompt_router.get("/templates")
async def get_all_templates(
    category: Optional[str] = None,
    subcategory: Optional[str] = None,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Get all prompt templates"""
    try:
        prompt_system = get_prompt_system()
        
        # Use the get_all_templates method with filtering
        templates = await prompt_system.get_all_templates(
            category=category,
            subcategory=subcategory
        )
        
        # Convert to list format for consistent response
        template_list = [{"template_id": k, **v} for k, v in templates.items()]
        
        return await ResponseUtil.success_response(
            data=template_list,
            message="Prompt templates retrieved successfully"
        )
    except Exception as e:
        logger.error(f"Error retrieving templates: {str(e)}")
        return await ResponseUtil.from_exception(e)

@prompt_router.get("/templates/{template_id}")
async def get_template(
    template_id: str,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Get a specific prompt template by ID"""
    try:
        prompt_system = get_prompt_system()
        template = await prompt_system.get_template(template_id)
        
        return await ResponseUtil.success_response(
            data=template,
            message="Template retrieved successfully"
        )
    except ValidationError as e:
        raise ResourceNotFoundError(
            message="Template not found",
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"Error retrieving template: {str(e)}")
        return await ResponseUtil.from_exception(e)