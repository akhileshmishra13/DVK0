# backend/app/data/__init__.py
"""
Data directory for prompt templates and other data files
"""