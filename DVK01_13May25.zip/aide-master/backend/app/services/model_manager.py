from typing import Dict, Any, Optional, List, Union
import asyncio
import logging
import json
import base64
import aioboto3
import os
import httpx
import traceback
from app.services.base_service import BaseService, ServiceStatus
from app.core.config import settings
from app.core.exceptions import AIModelError

logger = logging.getLogger(__name__)

class ModelManager(BaseService):
    """
    Service for managing AI model providers and models.
    Handles dynamic model selection and fallbacks.
    """
    
    def __init__(self):
        # --- Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            # Initialize these attributes BEFORE calling super().__init__
            self.bedrock_session = None
            
            # ONE client per distinct provider - no redundancy
            self.openai_client = None      # For OpenAI models (GPT, o-series)
            self.google_ai_client = None   # For Gemini models via Google GenAI SDK
            
            # Initialize model dictionary with all models from settings
            self.models = {
                "primary": settings.PRIMARY_MODEL,
                "fallback": settings.FALLBACK_MODEL,
                "ultra_context": settings.ULTRA_CONTEXT_MODEL,
                "text_extract": settings.TEXT_EXTRACT_MODEL,
                "advanced_reasoning": settings.ADVANCED_REASONING_MODEL if hasattr(settings, 'ADVANCED_REASONING_MODEL') else 'o1'
            }
            
            # Store inference profiles for Bedrock models
            self.inference_profiles = {}
            
            # Build provider mapping dynamically based on model names
            self.model_providers = {}
            for model_type, model_id in self.models.items():
                self.model_providers[model_id] = self._determine_provider(model_id)
            
            # Call super().__init__ AFTER setting subclass attributes
            super().__init__(name="model_manager", dependencies=[])
            
            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "models": self.models,
                "providers": ["bedrock", "google_ai", "openai"],
                "connected": False
            })
            self._initialized_ = True # Mark as initialized
    
    def _determine_provider(self, model_id: str) -> str:
        """
        Determine the provider for a given model ID
        
        Args:
            model_id: The model ID to check
            
        Returns:
            Provider name ("bedrock", "google_ai", or "openai")
        """
        model_lower = model_id.lower()
        
        # Bedrock models (Claude)
        if "anthropic" in model_lower or "claude" in model_lower:
            return "bedrock"
        
        # Gemini models - ALL use google_ai provider
        if "gemini" in model_lower:
            return "google_ai"
        
        # OpenAI models (all families)
        if any(prefix in model_lower for prefix in [
            "gpt-", "o1", "o1-", "o3", "o3-", "text-", "dall-e", "tts-", 
            "whisper", "computer-use"
        ]):
            return "openai"
        
        # Last resort: check for typical OpenAI naming patterns
        if any(suffix in model_lower for suffix in [
            "-preview", "-mini", "-search", "-audio", "-realtime"
        ]):
            return "openai"
        
        # Default fallback
        logger.warning(f"Unknown model ID pattern: {model_id}, defaulting to bedrock")
        return "bedrock"
    
    async def get_model(self, model_type: str) -> str:
        """
        Get model ID by type (primary, fallback, ultra_context, text_extract)
        
        Args:
            model_type: The type of model to retrieve
            
        Returns:
            Model ID string
        """
        return self.models.get(model_type, self.models["primary"])
    
    async def get_provider(self, model_id: str) -> str:
        """
        Get provider for a specific model ID
        
        Args:
            model_id: The model ID
            
        Returns:
            Provider name ("bedrock", "google_ai", or "openai")
        """
        # If already mapped, return from our cache
        if model_id in self.model_providers:
            return self.model_providers[model_id]
        
        # Otherwise determine dynamically
        provider = self._determine_provider(model_id)
        # Cache result for future lookups
        self.model_providers[model_id] = provider
        return provider
    
    async def _find_inference_profile(self, model_id: str) -> Optional[str]:
        """
        Finds the appropriate Inference Profile ID for a given model ID
        
        Args:
            model_id: The base model ID to find a profile for
            
        Returns:
            Optional Inference Profile ID or ARN if found
        """
        if not self.bedrock_session:
            logger.warning("Cannot find inference profile: Bedrock session not initialized")
            return None
        
        try:
            # Create a regular bedrock client (not bedrock-runtime) for listing profiles
            async with self.bedrock_session.client(
                service_name='bedrock',
                region_name=settings.AWS_REGION
            ) as bedrock_client:
                # Use pagination to get all inference profiles
                paginator = bedrock_client.get_paginator('list_inference_profiles')
                
                logger.info(f"Searching for Inference Profiles for model containing '{model_id}'...")
                found_profile = None
                
                async for page in paginator.paginate():
                    for profile in page.get('inferenceProfileSummaries', []):
                        profile_models = profile.get('models', [])
                        profile_id = profile.get('inferenceProfileId')
                        profile_arn = profile.get('inferenceProfileArn')
                        profile_type = profile.get('type')
                        
                        # Check if this profile contains the target model ID within any of its model ARNs
                        is_match = False
                        for model_info in profile_models:
                            model_arn = model_info.get('modelArn', '')
                            # Check if the target model ID is part of the model ARN string
                            if f"foundation-model/{model_id}" in model_arn:
                                is_match = True
                                break  # Found the model in this profile
                        
                        if is_match:
                            logger.info(f"Found Profile: Name='{profile.get('inferenceProfileName')}', ID='{profile_id}', Type='{profile_type}'")
                            # Prefer system-defined profiles for potential cross-region benefits
                            if profile_type == 'SYSTEM_DEFINED':
                                found_profile = profile
                                logger.info(f"Selecting SYSTEM_DEFINED profile.")
                                break  # Stop searching once a system profile is found
                            elif not found_profile:  # If no system profile found yet, take the first match
                                found_profile = profile
                                logger.info(f"Selecting first matching profile (Type: {profile_type}).")
                    
                    if found_profile and found_profile.get('type') == 'SYSTEM_DEFINED':
                        break  # Exit outer loop if system profile found
                
                if found_profile:
                    profile_id = found_profile.get('inferenceProfileId')
                    logger.info(f"Using Inference Profile ID: {profile_id} for model {model_id}")
                    return profile_id
                else:
                    logger.warning(f"No suitable Inference Profile found for {model_id}.")
                    logger.warning("Attempting to use the model ID directly, but this may fail for newer models.")
                    return None
                    
        except Exception as e:
            logger.error(f"Error finding inference profile: {str(e)}")
            return None
    
    async def initialize(self) -> bool:
        """Initialize model clients and connections"""
        try:
            # Initialize AWS Bedrock client
            logger.info("Initializing AWS Bedrock session")
            try:
                # Create an aioboto3 session instead of client
                self.bedrock_session = aioboto3.Session(
                    region_name=settings.AWS_REGION
                )
                logger.info("AWS Bedrock session initialized successfully")
                
                # Discover inference profiles for Claude models
                for model_type, model_id in self.models.items():
                    provider = self.model_providers.get(model_id)
                    if provider == "bedrock" and "claude" in model_id.lower():
                        logger.info(f"Discovering Inference Profile for {model_id}")
                        profile_id = await self._find_inference_profile(model_id)
                        if profile_id:
                            # Store the profile ID for this model
                            self.inference_profiles[model_id] = profile_id
                            logger.info(f"Found Inference Profile {profile_id} for model {model_id}")
                        else:
                            logger.warning(f"No inference profile found for {model_id}, will attempt direct use")
                
            except Exception as e:
                logger.warning(f"Error initializing AWS Bedrock session: {str(e)}")
                # We'll continue even if Bedrock fails, as we can use other providers
            
            # Initialize Google AI client - SINGLE implementation for Gemini
            logger.info("Initializing Google AI client")
            try:
                import google.genai as genai
                # Remove this line: genai.configure(api_key=settings.GOOGLE_API_KEY)
                self.google_ai_client = genai.Client(api_key=settings.GOOGLE_API_KEY)
                logger.info("Google AI client initialized successfully")
            except ImportError as ie:
                logger.error(f"Missing dependency for Google AI client: {str(ie)}")
                logger.warning("Please install google-genai>=1.9.0")
                self.google_ai_client = None
            except Exception as e:
                logger.warning(f"Error initializing Google AI client: {str(e)}")
                self.google_ai_client = None
            
            # Initialize OpenAI client
            logger.info("Initializing OpenAI client")
            try:
                from openai import AsyncOpenAI
                
                # Initialize OpenAI client if API key is available
                if settings.OPENAI_API_KEY:
                    self.openai_client = AsyncOpenAI(
                        api_key=settings.OPENAI_API_KEY
                    )
                    logger.info("OpenAI client initialized successfully (for GPT and o-series models)")
                else:
                    logger.warning("OpenAI API key not configured, OpenAI models will be unavailable")
                
            except ImportError as ie:
                logger.error(f"Missing dependency: {str(ie)}")
                logger.warning("OpenAI package not installed, OpenAI provider will be unavailable")
            except Exception as e:
                logger.warning(f"Error initializing OpenAI client: {str(e)}")
            
            # Set connected status if at least one provider is available
            if self.bedrock_session or self.google_ai_client or self.openai_client:
                self.status_details["connected"] = True
                self.update_status(
                    ServiceStatus.RUNNING,
                    "Model clients initialized successfully"
                )
            else:
                self.update_status(
                    ServiceStatus.ERROR,
                    "All model clients failed to initialize"
                )
                return False
                
            return await super().initialize()
        except Exception as e:
            logger.error(f"Error initializing model clients: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Model initialization error: {str(e)}"
            )
            return False
    
    async def estimate_tokens(self, text: str) -> int:
        """
        Estimate the number of tokens in the text
        
        Args:
            text: The text to estimate tokens for
            
        Returns:
            Estimated token count
        """
        # Simple estimation - approx 4 chars per token
        # For precise estimation, we would use tiktoken or similar
        return len(text) // 4
    
    async def select_model(self, estimated_tokens: int) -> str:
        """
        Select the appropriate model based on token count
        
        Args:
            estimated_tokens: Estimated token count
            
        Returns:
            Model ID to use
        """
        # Large context models have ~1M token context window
        if estimated_tokens > 100000:
            logger.info(f"Using ultra-context model for {estimated_tokens} tokens")
            return await self.get_model("ultra_context")
        else:
            logger.info(f"Using primary model for {estimated_tokens} tokens")
            return await self.get_model("primary")
    
    async def get_completion(self, 
                            prompt: str, 
                            model_id: Optional[str] = None,
                            max_tokens: Optional[int] = None,
                            temperature: Optional[float] = None,
                            response_format: Optional[Dict[str, Any]] = None,
                            files: Optional[List[Dict[str, Any]]] = None,
                            use_grounding: bool = False,
                            system_prompt: Optional[str] = None,
                            use_reasoning: bool = False) -> Dict[str, Any]:
        """
        Get completion from the selected model with automatic fallbacks
        
        Args:
            prompt: The prompt text
            model_id: Optional specific model ID to use
            max_tokens: Maximum tokens to generate (uses provider-specific default if None)
            temperature: Temperature for generation (uses provider-specific default if None)
            response_format: Optional format for structured output
            files: Optional list of files to include
            use_grounding: Whether to use grounding (now applicable to all models)
            system_prompt: Optional system prompt for models that support it
            use_reasoning: Whether to use reasoning (for models that support it)
            
        Returns:
            Completion result
        """
        # Use global default if not specified
        max_tokens = max_tokens or settings.DEFAULT_MAX_TOKENS
        temperature = temperature or settings.DEFAULT_TEMPERATURE
        
        # Select model if not specified
        if not model_id:
            if files:  
                # If files are included, we need to use a model that supports them
                model_id = await self.get_model("ultra_context")
            elif use_reasoning:
                # If reasoning is requested, prioritize a model that supports it
                # Claude 3.7 Sonnet (PRIMARY_MODEL) supports reasoning
                primary_model_id = await self.get_model("primary")
                if "claude-3-7" in primary_model_id.lower():
                    model_id = primary_model_id
                    logger.info(f"Using primary model with reasoning: {model_id}")
                else:
                    # Fallback to another model that might support reasoning
                    model_id = await self.get_model("advanced_reasoning") if "advanced_reasoning" in self.models else await self.get_model("primary")
                    logger.info(f"Using advanced reasoning model: {model_id}")
            else:
                # Base on token count - start with prompt token estimation
                estimated_tokens = await self.estimate_tokens(prompt)
                model_id = await self.select_model(estimated_tokens)
        
        # Determine provider
        provider = await self.get_provider(model_id)
        logger.info(f"Using provider '{provider}' for model '{model_id}'")
        
        # First attempt with the selected model
        try:
            if provider == "bedrock":
                logger.info(f"Getting completion from Bedrock for model {model_id}")
                # Use provider-specific default if specified
                bedrock_max_tokens = max_tokens
                if hasattr(settings, 'BEDROCK_MAX_TOKENS'):
                    bedrock_max_tokens = max_tokens or settings.BEDROCK_MAX_TOKENS
                    
                bedrock_temperature = temperature
                if hasattr(settings, 'BEDROCK_TEMPERATURE'):
                    bedrock_temperature = temperature or settings.BEDROCK_TEMPERATURE
                    
                result = await self._get_bedrock_completion(
                    prompt=prompt,
                    model_id=model_id,
                    max_tokens=bedrock_max_tokens,
                    temperature=bedrock_temperature,
                    response_format=response_format,
                    system_prompt=system_prompt,
                    use_reasoning=use_reasoning
                )
                logger.info(f"Successfully got completion from Bedrock for model {model_id}")
                return result
                
            elif provider == "google_ai":
                logger.info(f"Getting completion from Google AI for model {model_id}")
                # Use provider-specific default if specified
                google_max_tokens = max_tokens
                if hasattr(settings, 'GOOGLE_MAX_TOKENS'):
                    google_max_tokens = max_tokens or settings.GOOGLE_MAX_TOKENS
                    
                google_temperature = temperature
                if hasattr(settings, 'GOOGLE_TEMPERATURE'):
                    google_temperature = temperature or settings.GOOGLE_TEMPERATURE
                    
                result = await self._get_google_ai_completion(
                    prompt=prompt,
                    model_id=model_id,
                    max_tokens=google_max_tokens,
                    temperature=google_temperature,
                    response_format=response_format,
                    files=files,
                    use_grounding=use_grounding  # Always pass through
                )
                logger.info(f"Successfully got completion from Google AI for model {model_id}")
                return result
                
            elif provider == "openai":
                logger.info(f"Getting completion from OpenAI for model {model_id}")
                # Use provider-specific default if specified
                openai_max_tokens = max_tokens
                if hasattr(settings, 'OPENAI_MAX_TOKENS'):
                    openai_max_tokens = max_tokens or settings.OPENAI_MAX_TOKENS
                    
                openai_temperature = temperature
                if hasattr(settings, 'OPENAI_TEMPERATURE'):
                    openai_temperature = temperature or settings.OPENAI_TEMPERATURE
                    
                result = await self._get_openai_completion(
                    prompt=prompt,
                    model_id=model_id,
                    max_tokens=openai_max_tokens,
                    temperature=openai_temperature,
                    response_format=response_format,
                    files=files,
                    system_prompt=system_prompt
                )
                logger.info(f"Successfully got completion from OpenAI for model {model_id}")
                return result
            else:
                raise AIModelError(f"Unknown provider: {provider}")
        except Exception as e:
            logger.error(f"Error with primary model {model_id}: {str(e)}")
            
            # If we're already using a fallback, don't try another fallback
            fallback_model = await self.get_model("fallback")
            if model_id == fallback_model or model_id == await self.get_model("ultra_context"):
                logger.error(f"Fallback not attempted because we're already using fallback or ultra_context model")
                raise AIModelError(f"All model attempts failed: {str(e)}")
            
            # Try fallback
            try:
                fallback_provider = await self.get_provider(fallback_model)
                logger.info(f"Attempting fallback to {fallback_model} using provider {fallback_provider}")
                
                if fallback_provider == "bedrock":
                    # Use provider-specific default if specified
                    bedrock_max_tokens = max_tokens
                    if hasattr(settings, 'BEDROCK_MAX_TOKENS'):
                        bedrock_max_tokens = max_tokens or settings.BEDROCK_MAX_TOKENS
                        
                    bedrock_temperature = temperature
                    if hasattr(settings, 'BEDROCK_TEMPERATURE'):
                        bedrock_temperature = temperature or settings.BEDROCK_TEMPERATURE
                        
                    return await self._get_bedrock_completion(
                        prompt=prompt,
                        model_id=fallback_model,
                        max_tokens=bedrock_max_tokens,
                        temperature=bedrock_temperature,
                        response_format=response_format,
                        system_prompt=system_prompt
                    )
                elif fallback_provider == "google_ai":
                    # Use provider-specific default if specified
                    google_max_tokens = max_tokens
                    if hasattr(settings, 'GOOGLE_MAX_TOKENS'):
                        google_max_tokens = max_tokens or settings.GOOGLE_MAX_TOKENS
                        
                    google_temperature = temperature
                    if hasattr(settings, 'GOOGLE_TEMPERATURE'):
                        google_temperature = temperature or settings.GOOGLE_TEMPERATURE
                        
                    return await self._get_google_ai_completion(
                        prompt=prompt,
                        model_id=fallback_model,
                        max_tokens=google_max_tokens,
                        temperature=google_temperature,
                        response_format=response_format,
                        files=files,
                        use_grounding=use_grounding  # Pass through here too
                    )
                elif fallback_provider == "openai":
                    # Use provider-specific default if specified
                    openai_max_tokens = max_tokens
                    if hasattr(settings, 'OPENAI_MAX_TOKENS'):
                        openai_max_tokens = max_tokens or settings.OPENAI_MAX_TOKENS
                        
                    openai_temperature = temperature
                    if hasattr(settings, 'OPENAI_TEMPERATURE'):
                        openai_temperature = temperature or settings.OPENAI_TEMPERATURE
                        
                    return await self._get_openai_completion(
                        prompt=prompt,
                        model_id=fallback_model,
                        max_tokens=openai_max_tokens,
                        temperature=openai_temperature,
                        response_format=response_format,
                        files=files,
                        system_prompt=system_prompt
                    )
                else:
                    raise AIModelError(f"Unknown provider for fallback: {fallback_provider}")
            except Exception as fallback_error:
                logger.error(f"Fallback model also failed: {str(fallback_error)}")
                raise AIModelError(f"All model attempts failed: {str(e)}, Fallback: {str(fallback_error)}")

    async def _get_bedrock_completion(self, 
                                    prompt: str, 
                                    model_id: str,
                                    max_tokens: Optional[int] = None,
                                    temperature: Optional[float] = None,
                                    response_format: Optional[Dict[str, Any]] = None,
                                    system_prompt: Optional[str] = None,
                                    use_reasoning: bool = False) -> Dict[str, Any]:
        """
        Get completion from AWS Bedrock (using async client)
        
        Args:
            prompt: The prompt text
            model_id: The model ID to use
            max_tokens: Maximum number of tokens to generate (defaults to settings.BEDROCK_MAX_TOKENS)
            temperature: Temperature for generation (defaults to settings.BEDROCK_TEMPERATURE)
            response_format: Optional format for structured output
            system_prompt: Optional system prompt for context setting
            use_reasoning: Whether to enable reasoning mode for Claude 3.7+ models
            
        Returns:
            Completion result with standardized format
        """
        if not self.bedrock_session:
            logger.error("Bedrock session not initialized")
            raise AIModelError("Bedrock session not initialized")
            
        try:
            # Use configured values if not provided
            max_tokens = max_tokens or settings.BEDROCK_MAX_TOKENS
            temperature = temperature or settings.BEDROCK_TEMPERATURE
            
            # Check if we have an inference profile for this model
            effective_model_id = self.inference_profiles.get(model_id, model_id)
            if effective_model_id != model_id:
                logger.info(f"Using inference profile {effective_model_id} for model {model_id}")
            
            # SANITIZE PROMPT FOR BEDROCK - normalize line endings
            prompt = prompt.replace('\r\n', '\n')
            
            # Ensure system prompt doesn't have problematic characters
            if system_prompt:
                system_prompt = system_prompt.replace('\r\n', '\n')
            
            # Create an async client using the session
            async with self.bedrock_session.client(
                service_name='bedrock-runtime',
                region_name=settings.AWS_REGION
            ) as bedrock_client:
                # Determine if it's Claude or other model
                if "claude" in model_id.lower():
                    # Format Claude-specific request - MUST INCLUDE anthropic_version
                    request_body = {
                        "anthropic_version": "bedrock-2023-05-31",  # CRITICAL: Required field
                        "max_tokens": max_tokens,  # CORRECT: Use max_tokens
                        "messages": [
                            {
                                "role": "user",
                                "content": prompt  # Direct string format
                            }
                        ]
                    }
                    
                    # Add system prompt if provided
                    if system_prompt:
                        request_body["system"] = system_prompt
                    
                    # Check if we're enabling reasoning
                    enable_reasoning = use_reasoning and "claude-3-7" in model_id.lower()
                    
                    if enable_reasoning:
                        # When using reasoning, temperature MUST be 1.0 if specified at all
                        # For Claude 3.7, we can either omit temperature (it defaults to 1.0)
                        # or explicitly set it to 1.0
                        request_body["temperature"] = 1.0
                        logger.info("Setting temperature to 1.0 as required when reasoning is enabled")
                        
                        # Claude 3.7 REQUIRES minimum 1024 tokens for reasoning budget
                        reasoning_budget = int(max_tokens * settings.BEDROCK_REASONING_BUDGET_RATIO)
                        reasoning_budget = max(reasoning_budget, 1024)  # MUST be at least 1024
                        reasoning_budget = min(reasoning_budget, max_tokens - 100)  # Keep 100 for response
                        
                        # Add top-level thinking parameter for Claude 3.7+
                        request_body["thinking"] = {
                            "type": "enabled",
                            "budget_tokens": reasoning_budget
                        }
                        logger.info(f"Enabled reasoning mode for Claude 3.7 with budget: {reasoning_budget} tokens (max_tokens: {max_tokens})")
                    else:
                        # Regular completion without reasoning - can use normal temperature
                        request_body["temperature"] = temperature
                        
                        # Add top_p if configuration provides it (only for non-reasoning mode)
                        if hasattr(settings, 'BEDROCK_TOP_P'):
                            request_body["top_p"] = settings.BEDROCK_TOP_P
                    
                    # Add response format if specified
                    if response_format and response_format.get("type") == "json_object":
                        request_body["response_format"] = {"type": "json_object"}
                    
                    # Convert to JSON - log request size for debugging
                    request_json = json.dumps(request_body)
                    logger.debug(f"Bedrock request size: {len(request_json)} bytes")
                    
                    # Make the actual async API call
                    response = await bedrock_client.invoke_model(
                        modelId=effective_model_id,
                        body=request_json
                    )
                    
                    logger.debug(f"Got response from Bedrock for model {effective_model_id}")
                    
                    # Parse the response (async read)
                    body_stream = response['body']
                    response_body_bytes = await body_stream.read()
                    response_body = json.loads(response_body_bytes)
                    
                    # Extract the content
                    output_text = ""
                    reasoning_text = None
                    
                    # Process content blocks - handle both standard text and reasoning outputs
                    if "content" in response_body and isinstance(response_body["content"], list):
                        for block in response_body["content"]:
                            if block.get("type") == "text":
                                output_text = block.get("text", "")
                            elif block.get("type") == "thinking":
                                # FIXED: Use correct key for reasoning text
                                reasoning_text = block.get("thinking", "")
                    elif "completion" in response_body:
                        # Legacy format fallback
                        output_text = response_body.get("completion", "")
                    else:
                        # Final fallback
                        output_text = response_body.get("content", [{}])[0].get("text", "")
                    
                    # Extract usage information
                    usage = response_body.get("usage", {})
                    input_tokens = usage.get("input_tokens", await self.estimate_tokens(prompt))
                    output_tokens = usage.get("output_tokens", await self.estimate_tokens(output_text))
                    
                    # Build result with enhanced metadata
                    result = {
                        "text": output_text,
                        "model": model_id,
                        "provider": "bedrock",
                        "tokens": {
                            "prompt": input_tokens,
                            "completion": output_tokens,
                            "total": input_tokens + output_tokens
                        }
                    }
                    
                    # Add reasoning if available
                    if reasoning_text:
                        result["reasoning"] = reasoning_text
                    
                    return result
                else:
                    # In a real implementation, we would handle other Bedrock models here
                    logger.error(f"Unsupported Bedrock model: {model_id}")
                    raise AIModelError(f"Unsupported Bedrock model: {model_id}")
        except AIModelError:
            # Re-raise AIModelError directly
            raise
        except Exception as e:
            logger.error(f"Bedrock API error: {str(e)}")
            raise AIModelError(f"Bedrock API error: {str(e)}")
    
    async def _get_google_ai_completion(self, 
                                    prompt: str, 
                                    model_id: str,
                                    max_tokens: Optional[int] = None,
                                    temperature: Optional[float] = None,
                                    response_format: Optional[Dict[str, Any]] = None,
                                    files: Optional[List[Dict[str, Any]]] = None,
                                    use_grounding: bool = False) -> Dict[str, Any]:
        """Get completion using Google GenAI SDK for Gemini models
        
        This is the SINGLE implementation for ALL Gemini models, using the Google GenAI SDK.
        Supports all Gemini features including grounding, function calling, etc.
        """
        if not self.google_ai_client:
            logger.error("Google AI client not initialized")
            raise AIModelError("Google AI client not initialized. Check Google API key.")
        
        try:
            logger.info(f"Using Google AI SDK for model: {model_id}")
            
            # Use provider-specific settings if not provided
            max_tokens = max_tokens or settings.GOOGLE_MAX_TOKENS
            temperature = temperature or settings.GOOGLE_TEMPERATURE
            
            # Import required types
            from google.genai.types import GenerateContentConfig, Tool, GoogleSearch
            import re
            
            # Build config with temperature and max tokens
            config = GenerateContentConfig(
                temperature=temperature,
                max_output_tokens=max_tokens
            )
            
            # Add top_p if configured
            if hasattr(settings, 'GOOGLE_TOP_P'):
                config.top_p = settings.GOOGLE_TOP_P
                
            # Add top_k if configured
            if hasattr(settings, 'GOOGLE_TOP_K'):
                config.top_k = settings.GOOGLE_TOP_K
            
            # Add Google Search grounding ONLY when specifically requested
            # This is the key change - only enable grounding when requested
            if use_grounding:
                try:
                    # Create Google Search tool for grounding
                    google_search_tool = Tool(google_search=GoogleSearch())
                    config.tools = [google_search_tool]
                    logger.info("Enabling Google Search grounding for Gemini model")
                except Exception as e:
                    logger.warning(f"Google Search tool not available - grounding disabled: {str(e)}")
            else:
                logger.info("Google Search grounding not requested for this query")
            
            # Format response if requested
            if response_format and response_format.get("type") == "json_object":
                config.response_mime_type = "application/json"
            
            # Process file content if provided
            from google.genai.types import Part
            
            if files:
                # For multimodal content, prepare the parts
                contents = [prompt]
                
                for file_info in files:
                    if file_info.get("mime_type") == "application/pdf":
                        # Decode base64 PDF content
                        pdf_content = base64.b64decode(file_info["content"])
                        
                        # Create a Part for the PDF
                        pdf_part = Part.from_bytes(
                            data=pdf_content,
                            mime_type="application/pdf"
                        )
                        contents.append(pdf_part)
            else:
                # For simple text prompts
                contents = prompt
            
            # Generate content using ASYNC methods
            logger.debug(f"Sending request to Google AI for model {model_id}")
            response = await self.google_ai_client.aio.models.generate_content(
                model=model_id,
                contents=contents,
                config=config
            )
            logger.debug(f"Got response from Google AI for model {model_id}")
            
            # Log response structure for debugging
            logger.debug(f"Response type: {type(response)}")
            
            # CRITICAL: Properly validate response before accessing attributes
            output_text = ""
            
            # First try the .text property
            if hasattr(response, 'text') and response.text is not None:
                output_text = response.text
                logger.debug("Extracted text from response.text property")
            # Then try the candidates structure
            elif hasattr(response, 'candidates') and response.candidates:
                candidate = response.candidates[0]
                if hasattr(candidate, 'content') and candidate.content:
                    if hasattr(candidate.content, 'parts') and candidate.content.parts:
                        for part in candidate.content.parts:
                            if hasattr(part, 'text') and part.text:
                                output_text += part.text
                                logger.debug("Extracted text from response.candidates[0].content.parts")
            
            # If still no text, log warning and use default
            if not output_text:
                logger.warning("Empty response from Google AI API")
                output_text = "No response generated."
            
            # Check for finish_reason SAFETY or other blocking
            blocked = False
            if hasattr(response, 'candidates') and response.candidates:
                candidate = response.candidates[0]
                if hasattr(candidate, 'finish_reason') and candidate.finish_reason == "SAFETY":
                    logger.warning(f"Response blocked due to safety concerns: {candidate.finish_reason}")
                    blocked = True
            
            # Check if grounding was used and extract full metadata
            grounding_used = False
            grounding_metadata = None
            
            if hasattr(response, 'candidates') and response.candidates:
                candidate = response.candidates[0]
                if hasattr(candidate, 'grounding_metadata') and candidate.grounding_metadata:
                    grounding_used = True
                    logger.info("Response was grounded with Google Search")
                    
                    # Extract and process full grounding metadata
                    grounding_metadata = {}
                    
                    # Extract search queries if available
                    if hasattr(candidate.grounding_metadata, 'web_search_queries'):
                        grounding_metadata['web_search_queries'] = candidate.grounding_metadata.web_search_queries
                        logger.debug(f"Search queries: {candidate.grounding_metadata.web_search_queries}")
                    
                    # Extract grounding attributions (sources)
                    if hasattr(candidate.grounding_metadata, 'grounding_attributions'):
                        attributions = candidate.grounding_metadata.grounding_attributions
                        
                        # Enhanced logging for attribution count
                        if attributions and len(attributions) > 0:
                            logger.info(f"Found {len(attributions)} grounding attributions")
                            
                            # Convert attributions to serializable format
                            grounding_metadata['grounding_attributions'] = []
                            for attr in attributions:
                                attribution_dict = {
                                    'source_id': {},
                                    'content_indices': attr.content_indices if hasattr(attr, 'content_indices') else [],
                                    'confidence_score': attr.confidence_score if hasattr(attr, 'confidence_score') else 0.0
                                }
                                
                                # Extract source information
                                if hasattr(attr, 'source_id') and hasattr(attr.source_id, 'web'):
                                    attribution_dict['source_id']['web'] = {
                                        'uri': attr.source_id.web.uri,
                                        'title': attr.source_id.web.title
                                    }
                                
                                # Extract segment information
                                if hasattr(attr, 'segment'):
                                    attribution_dict['segment'] = {
                                        'start_index': attr.segment.start_index if hasattr(attr.segment, 'start_index') else 0,
                                        'end_index': attr.segment.end_index if hasattr(attr.segment, 'end_index') else 0,
                                        'text': getattr(attr.segment, 'text', '')
                                    }
                                    
                                grounding_metadata['grounding_attributions'].append(attribution_dict)
                        else:
                            logger.warning("Response marked as grounded but contained zero attributions")
                            # Always ensure we have an attributions array for UI consistency
                            grounding_metadata['grounding_attributions'] = []
                    else:
                        logger.warning("Response marked as grounded but has no grounding_attributions field")
                        grounding_metadata['grounding_attributions'] = []
                    
                    # Extract rendered HTML content if available
                    if hasattr(candidate.grounding_metadata, 'search_entry_point') and \
                    hasattr(candidate.grounding_metadata.search_entry_point, 'rendered_content'):
                        grounding_metadata['rendered_content'] = candidate.grounding_metadata.search_entry_point.rendered_content
            
            # Create token info estimate
            estimated_prompt_tokens = await self.estimate_tokens(prompt)
            estimated_completion_tokens = await self.estimate_tokens(output_text)
            
            # Return standardized response format
            result = {
                "text": output_text,
                "model": model_id,
                "provider": "google_ai",
                "tokens": {
                    "prompt": estimated_prompt_tokens,
                    "completion": estimated_completion_tokens,
                    "total": estimated_prompt_tokens + estimated_completion_tokens
                }
            }
            
            # Add metadata about response
            if blocked:
                result["blocked"] = True
                result["block_reason"] = "SAFETY"
                
            if grounding_used:
                result["grounding"] = True
                
                # Add citation detection - scan for citation patterns in the text
                if not grounding_metadata or not grounding_metadata.get('grounding_attributions') or len(grounding_metadata.get('grounding_attributions', [])) == 0:
                    # Try to extract citation references from text to help frontend
                    citation_pattern = r'\[(\d+(?:,\s*\d+)*)\]'
                    citation_matches = re.findall(citation_pattern, output_text)
                    
                    if citation_matches:
                        # Initialize grounding_metadata if needed
                        if not grounding_metadata:
                            grounding_metadata = {}
                        
                        # Extract all citation numbers
                        citation_numbers = set()
                        for match in citation_matches:
                            for num in match.split(','):
                                try:
                                    citation_numbers.add(int(num.strip()))
                                except ValueError:
                                    continue
                        
                        # Add citation numbers to metadata
                        if citation_numbers:
                            grounding_metadata['citation_numbers_found'] = sorted(list(citation_numbers))
                            logger.info(f"Found {len(citation_numbers)} citation numbers in response but no attribution data: {sorted(list(citation_numbers))}")
                            
                    # Mark as having no specific attributions
                    result["no_specific_attributions"] = True
                
                # Always ensure we have a grounding_metadata object
                if not grounding_metadata:
                    grounding_metadata = {}
                
                result["grounding_metadata"] = grounding_metadata
            
            return result
        
        except Exception as e:
            logger.error(f"Google AI API error: {str(e)}")
            
            # Add detailed exception info for easier debugging
            logger.error(f"Exception details: {traceback.format_exc()}")
            
            raise AIModelError(f"Google AI API error: {str(e)}")

    async def _get_openai_completion(self, 
                                prompt: str, 
                                model_id: str,
                                max_tokens: Optional[int] = None,
                                temperature: Optional[float] = None,
                                response_format: Optional[Dict[str, Any]] = None,
                                files: Optional[List[Dict[str, Any]]] = None,
                                system_prompt: Optional[str] = None) -> Dict[str, Any]:
        """
        Get completion from OpenAI API
        
        This method handles OpenAI models (GPT, o-series)
        """
        # Check if OpenAI client is available
        if not self.openai_client:
            logger.error("OpenAI client not available")
            raise AIModelError("OpenAI client not available. Check OpenAI API key configuration.")
            
        try:
            # Use provider-specific settings if not provided
            max_tokens = max_tokens or settings.OPENAI_MAX_TOKENS
            temperature = temperature or settings.OPENAI_TEMPERATURE
            
            # Build message content
            # For basic text prompts, use simple messages array
            messages = []
            
            # Add system prompt if provided
            if system_prompt:
                messages.append({"role": "system", "content": system_prompt})
            
            if not files:
                messages.append({"role": "user", "content": prompt})
            else:
                # Handle multimodal content (files)
                content_parts = [{"type": "text", "text": prompt}]
                
                for file_info in files:
                    if file_info.get("mime_type") == "application/pdf":
                        # Convert base64 string PDF to image_url format
                        content_parts.append({
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:application/pdf;base64,{file_info['content']}"
                            }
                        })
                
                # Create structured message with multiple content parts
                messages.append({"role": "user", "content": content_parts})
            
            # Handle JSON response format if requested
            openai_response_format = None
            if response_format and response_format.get("type") == "json_object":
                openai_response_format = {"type": "json_object"}
            
            # Make API call with proper error handling
            try:
                logger.debug(f"Sending request to OpenAI model: {model_id}")
                
                # Create parameters dict based on model type
                params = {
                    "model": model_id,
                    "messages": messages
                }
                
                # Use max_completion_tokens for o1 model instead of max_tokens
                # This is a specific requirement for the o1 model
                if model_id.startswith("o1"):
                    params["max_completion_tokens"] = max_tokens
                else:
                    params["max_tokens"] = max_tokens
                    params["temperature"] = temperature
                    
                    # Add top_p if configured
                    if hasattr(settings, 'OPENAI_TOP_P'):
                        params["top_p"] = settings.OPENAI_TOP_P
                    
                    # Add frequency_penalty if configured
                    if hasattr(settings, 'OPENAI_FREQUENCY_PENALTY'):
                        params["frequency_penalty"] = settings.OPENAI_FREQUENCY_PENALTY
                    
                    # Add presence_penalty if configured
                    if hasattr(settings, 'OPENAI_PRESENCE_PENALTY'):
                        params["presence_penalty"] = settings.OPENAI_PRESENCE_PENALTY
                
                # Add response format only if not using o1
                if not model_id.startswith("o1") and openai_response_format:
                    params["response_format"] = openai_response_format
                
                # Make the API call
                response = await self.openai_client.chat.completions.create(**params)
                
                logger.debug(f"Received response from OpenAI")
                
                # Extract text from response
                output_text = response.choices[0].message.content
                
                # Get token usage information (from response or estimated)
                if hasattr(response, 'usage') and response.usage is not None:
                    token_info = {
                        "prompt": response.usage.prompt_tokens,
                        "completion": response.usage.completion_tokens,
                        "total": response.usage.total_tokens
                    }
                else:
                    # Estimate if not provided by API
                    prompt_tokens = await self.estimate_tokens(prompt)
                    completion_tokens = await self.estimate_tokens(output_text)
                    token_info = {
                        "prompt": prompt_tokens,
                        "completion": completion_tokens,
                        "total": prompt_tokens + completion_tokens
                    }
                
                # Return standardized response
                return {
                    "text": output_text,
                    "model": model_id,
                    "provider": "openai",
                    "tokens": token_info
                }
            except Exception as api_error:
                # Handle specific OpenAI exceptions with more detailed errors
                error_type = type(api_error).__name__
                error_details = str(api_error)
                
                # Log the specific error for debugging
                logger.error(f"{error_type} during OpenAI API call: {error_details}")
                
                # pass all errors through to our general handler
                raise AIModelError(f"OpenAI API error: {error_details}")
            
        except AIModelError:
            # Re-raise already formatted AI model errors
            raise
        except Exception as e:
            logger.error(f"Unexpected error using OpenAI client: {str(e)}")
            raise AIModelError(f"Error using OpenAI: {str(e)}")
    
    async def stop(self) -> bool:
        """Stop and cleanup model clients"""
        try:
            # Close the OpenAI client properly
            if self.openai_client:
                try:
                    logger.info("Closing OpenAI client")
                    await self.openai_client.close()
                except Exception as e:
                    logger.warning(f"Error closing OpenAI client: {str(e)}")
            
            # Reset clients
            self.openai_client = None
            self.google_ai_client = None
            self.bedrock_session = None
            
            self.status_details["connected"] = False
            return await super().stop()
        except Exception as e:
            logger.error(f"Error stopping model manager: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Error stopping model manager: {str(e)}"
            )
            return False

# Create the singleton instance
model_manager = ModelManager()