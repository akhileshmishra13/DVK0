# backend/app/services/extraction_service.py

from typing import Dict, Any, Optional, List, BinaryIO, Union
import logging
import json
import io
import base64
import asyncio
import concurrent.futures # Keep the import
import PyPDF2
import re
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field
from pydantic import ValidationError as PydanticValidationError

from app.services.base_service import BaseService, ServiceStatus
from app.core.config import settings
from app.core.registry import get_service
from app.core.exceptions import AIModelError, ValidationError

logger = logging.getLogger(__name__)

class ExtractionType(str, Enum):
    TEXT = "text"
    STRUCTURE = "structure"
    METADATA = "metadata"

class DocumentMetadata(BaseModel):
    """Model for document metadata extraction"""
    document_type: str = Field(description="Type of document (e.g., Teaser, DQM, CIM, IM, IS)")
    title: str = Field(description="Document title or name")
    date: Optional[str] = Field(None, description="Document date (if available)")
    author: Optional[str] = Field(None, description="Document author or organization (if available)")
    project_name: Optional[str] = Field(None, description="Project name (if available)")
    industry_sector: Optional[str] = Field(None, description="Industry sector (if available)")
    geographic_region: Optional[str] = Field(None, description="Geographic region (if available)")
    key_financial_metrics: Optional[Dict[str, Any]] = Field(None, description="Key financial metrics (if available)")
    transaction_type: Optional[str] = Field(None, description="Transaction type (if available)")
    key_topics: Optional[List[str]] = Field(None, description="Key topics or themes")
    estimated_token_count: int = Field(0, description="Estimated token count of the document")

class DocumentStructure(BaseModel):
    """Model for document structure extraction"""
    sections: List[Dict[str, Any]] = Field(
        description="List of document sections with headings and content")
    tables: List[Dict[str, Any]] = Field(
        description="List of tables in the document with headers and data")
    financial_metrics: Optional[Dict[str, Any]] = Field(
        None, description="Extracted financial metrics")
    key_points: Optional[List[str]] = Field(
        None, description="Key points or highlights from the document")

class ExtractionService(BaseService):
    """
    Service for AI-powered document extraction including text, structure, and metadata
    """

    def __init__(self):
        # --- FIXED: Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            # Initialize thread_pool before calling super().__init__
            self.thread_pool = None
            
            # Call super().__init__ AFTER setting subclass attributes
            super().__init__(name="extraction_service", dependencies=["model_manager", "data_service"])
            
            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "extractions_processed": 0,
                "ai_extraction_success_rate": 100.0,
                "initialized": False
            })
            self._initialized_ = True # Mark as initialized

    async def initialize(self) -> bool:
        """Initialize extraction service"""
        try:
            # Verify dependencies
            model_manager = get_service("model_manager")
            data_service = get_service("data_service")

            if model_manager.status != ServiceStatus.RUNNING:
                logger.warning(f"Model manager service not running: {model_manager.status}")

            if data_service.status != ServiceStatus.RUNNING:
                logger.warning(f"Data service not running: {data_service.status}")

            # Create ThreadPoolExecutor here during initialization
            self.thread_pool = concurrent.futures.ThreadPoolExecutor(max_workers=4)
            logger.info("ThreadPoolExecutor created for ExtractionService.")

            self.status_details["initialized"] = True
            self.update_status(
                ServiceStatus.RUNNING,
                "Extraction service initialized successfully"
            )
            # Call super().initialize() *after* setting status and creating pool
            return await super().initialize()
        except Exception as e:
            logger.error(f"Error initializing extraction service: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Extraction service initialization error: {str(e)}"
            )
            return False

    async def extract_json_from_text(self, text: str) -> Dict[str, Any]:
        """
        Extract valid JSON from text that might contain additional content
        and normalize field names to snake_case
        """
        # Try direct parsing first
        try:
            raw_json = json.loads(text)
            # Convert keys to snake_case
            return await self._normalize_keys(raw_json)
        except json.JSONDecodeError:
            pass
        
        # Look for content between ``` markers (markdown code blocks)
        code_block_match = re.search(r'```(?:json)?(.*?)```', text, re.DOTALL)
        if code_block_match:
            try:
                raw_json = json.loads(code_block_match.group(1).strip())
                return await self._normalize_keys(raw_json)
            except json.JSONDecodeError:
                pass
        
        # Look for content between first { and the final }
        first_brace = text.find('{')
        last_brace = text.rfind('}')
        if first_brace >= 0 and last_brace > first_brace:
            json_substr = text[first_brace:last_brace+1]
            try:
                raw_json = json.loads(json_substr)
                return await self._normalize_keys(raw_json)
            except json.JSONDecodeError:
                pass
        
        # Try to find any JSON object using regex
        json_match = re.search(r'(\{.*\})', text, re.DOTALL)
        if json_match:
            try:
                raw_json = json.loads(json_match.group(1))
                return await self._normalize_keys(raw_json)
            except json.JSONDecodeError:
                pass
        
        # Fallback - return empty dict with error
        logger.error(f"Failed to extract valid JSON from response: {text[:100]}...")
        return {
            "extraction_error": "Could not parse valid JSON from response",
            "document_type": "Unknown"
        }

    async def _normalize_keys(self, data: Any) -> Any:
        """Convert keys from "Title Case With Spaces" to "snake_case" format"""
        if isinstance(data, dict):
            # Create a new dict with normalized keys
            result = {}
            for k, v in data.items():
                snake_key = await self._to_snake_case(k)
                result[snake_key] = await self._normalize_keys(v)
            return result
        elif isinstance(data, list):
            # Process each item in the list
            result = []
            for item in data:
                result.append(await self._normalize_keys(item))
            return result
        else:
            # Return primitive values as-is
            return data

    async def _to_snake_case(self, text: str) -> str:
        """Convert 'Title Case String' to 'title_case_string'"""
        # Convert to lowercase
        s = str(text).lower()
        # Replace spaces with underscores
        s = s.replace(' ', '_')
        # Remove any remaining non-alphanumeric characters (except underscores)
        s = re.sub(r'[^\w_]', '', s)
        return s

    async def store_document_text(self, document_id: str, text: str, extraction_method: str = "python") -> bool:
        """
        Store extracted text in document metadata
        
        Args:
            document_id: The document ID
            text: The extracted text content
            extraction_method: Method used for extraction (python, ai, fallback)
            
        Returns:
            Success status
        """
        try:
            data_service = get_service("data_service")
            
            # Update the document with the extracted text
            await data_service.update_document_metadata(
                document_id=document_id,
                metadata_updates={
                    "text_content": text,
                    "extraction_method": extraction_method,
                    "extraction_timestamp": datetime.utcnow()
                }
            )
            logger.info(f"Stored {len(text)} characters of text for document {document_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to store text for document {document_id}: {str(e)}")
            return False

    async def extract_document_text(self, document_id: str, use_ai: bool = False) -> str:
        """
        Extract text from a document

        Args:
            document_id: The document ID
            use_ai: Whether to use AI for extraction (now defaults to False)

        Returns:
            Extracted text
        """
        try:
            # Get data service and document
            data_service = get_service("data_service")
            document = await data_service.get_document(document_id)

            if not document:
                raise ValidationError(f"Document not found: {document_id}")
                
            # CHECK FOR EXISTING TEXT FIRST - don't re-extract
            if document.get("metadata", {}).get("text_content"):
                logger.info(f"Using cached text content for {document_id}")
                return document["metadata"]["text_content"]

            # Get document content
            content = await data_service.get_document_content(document_id)
            if not content:
                raise ValidationError(f"No content found for document {document_id}")

            filename = document.get("filename", "").lower()

            # CHANGED: Always try PyPDF2 fallback first for PDFs, don't use AI first
            extracted_text = ""
            extraction_method = "python"
            
            if filename.endswith('.pdf'):
                logger.info(f"Extracting text from PDF using PyPDF2 for {document_id}")
                extracted_text = await self._extract_text_fallback(content, filename)
                
                # Only try AI if explicitly requested AND fallback produced limited results
                if use_ai and (not extracted_text or len(extracted_text) < 1000 or "PDF extraction error" in extracted_text):
                    try:
                        logger.info(f"Attempting AI text extraction as fallback for {document_id}")
                        extracted_text = await self._extract_text_with_ai(content, filename, document)
                        extraction_method = "ai"
                    except Exception as e:
                        logger.error(f"AI extraction failed: {str(e)}. Using original PyPDF2 results.")
                        # Keep using the PyPDF2 results
            else:
                # For non-PDF, use text content directly
                extracted_text = content.decode('utf-8', errors='ignore')
                
            # CRITICAL: Store the extracted text
            await self.store_document_text(document_id, extracted_text, extraction_method)
                
            # Update success metrics
            self.status_details["extractions_processed"] = self.status_details.get("extractions_processed", 0) + 1
            logger.info(f"Text extraction successful for {document_id}: {len(extracted_text)} chars")
            
            return extracted_text
            
        except Exception as e:
            logger.error(f"Error extracting text from document {document_id}: {type(e).__name__}: {str(e)}")
            raise # Re-raise the exception to be handled by the calling function/endpoint

    async def extract_document_metadata(self, document_id: str) -> Dict[str, Any]:
        """
        Extract metadata from a document using AI

        Args:
            document_id: The document ID

        Returns:
            Extracted metadata
        """
        try:
            # Get data service and document
            data_service = get_service("data_service")
            document = await data_service.get_document(document_id)

            if not document:
                raise ValidationError(f"Document not found: {document_id}")

            # Check if we already have extracted metadata
            if document.get("metadata", {}).get("extracted_metadata"):
                logger.info(f"Using cached metadata for {document_id}")
                return document["metadata"]["extracted_metadata"]

            # CHANGED: Get stored text content first
            stored_text = document.get("metadata", {}).get("text_content")
            
            # If no stored text, extract it first (with PyPDF2)
            if not stored_text:
                logger.info(f"No stored text found for {document_id}, extracting text first")
                stored_text = await self.extract_document_text(document_id, use_ai=False)
            
            if not stored_text or len(stored_text) < 100:
                logger.warning(f"Insufficient text content for metadata extraction for {document_id}")
                # Fallback to basic content if no text was extracted
                content = await data_service.get_document_content(document_id)
                stored_text = content.decode('utf-8', errors='ignore')[:10000]

            # Extract metadata using AI
            logger.info(f"Extracting metadata with AI for {document_id} from {len(stored_text)} chars of text")
            metadata = await self._extract_metadata_with_ai(stored_text, document.get("filename", ""), document)

            # Store metadata back in the document
            await data_service.update_document_metadata(
                document_id=document_id,
                metadata_updates={"extracted_metadata": metadata}
            )

            # Update metrics
            self.status_details["extractions_processed"] = self.status_details.get("extractions_processed", 0) + 1
            logger.info(f"Metadata extraction successful for {document_id}")

            return metadata
        except Exception as e:
            logger.error(f"Error extracting metadata from document {document_id}: {str(e)}")
            raise

    async def extract_document_structure(self, document_id: str) -> Dict[str, Any]:
        """
        Extract structured information from a document using AI

        Args:
            document_id: The document ID

        Returns:
            Extracted structure information
        """
        try:
            # Get data service and document
            data_service = get_service("data_service")
            document = await data_service.get_document(document_id)

            if not document:
                raise ValidationError(f"Document not found: {document_id}")

            # Check if we already have extracted structure
            if document.get("metadata", {}).get("extracted_structure"):
                logger.info(f"Using cached structure for {document_id}")
                return document["metadata"]["extracted_structure"]

            # CHANGED: Get stored text content first if available
            stored_text = document.get("metadata", {}).get("text_content")
            
            # If no stored text, extract or retrieve document content
            if not stored_text:
                content = await data_service.get_document_content(document_id)
                if not content:
                    raise ValidationError(f"No content found for document {document_id}")
                
                # For structure extraction, we'll still use the raw content
                filename = document.get("filename", "").lower()
                
                # Extract structure using AI with raw content
                logger.info(f"Extracting structure with AI for {document_id}")
                structure = await self._extract_structure_with_ai(content, filename, document)
            else:
                # Use stored text if available (preferred)
                filename = document.get("filename", "").lower()
                structure = await self._extract_structure_from_text(stored_text, filename, document)

            # Store structure back in the document
            await data_service.update_document_metadata(
                document_id=document_id,
                metadata_updates={"extracted_structure": structure}
            )

            # Update metrics
            self.status_details["extractions_processed"] = self.status_details.get("extractions_processed", 0) + 1
            logger.info(f"Structure extraction successful for {document_id}")

            return structure
        except Exception as e:
            logger.error(f"Error extracting structure from document {document_id}: {str(e)}")
            raise

    async def _extract_structure_from_text(self, text: str, filename: str, document: Dict[str, Any]) -> Dict[str, Any]:
        """Extract structure from already extracted text"""
        model_manager = get_service("model_manager")
        prompt_system = get_service("prompt_system")
        
        try:
            # Get structure extraction prompt
            structure_template_id = "system.structure_extraction.structure_extraction"
            prompt = await prompt_system.get_prompt(
                structure_template_id,
                text=text[:20000]  # Limit text size
            )
        except Exception as e:
            logger.error(f"Error getting structure extraction prompt: {e}. Using default.")
            prompt = """Extract the structure of the provided document including:
1. Sections: Identify main sections with their headings, level, and content summary
2. Tables: Extract tables with captions, headers, and data
3. Financial Metrics: Key financial data points
4. Key Points: Important takeaways

Return JSON format with these exact snake_case field names:
{
  "sections": [{"heading": "string", "content": "string", "level": integer}],
  "tables": [{"caption": "string", "headers": ["string"], "data": [["string"]]}],
  "financial_metrics": {"metric_name": "string_value"},
  "key_points": ["string"]
}

Document Content:
""" + text[:20000]
        
        try:
            structure_model_id = await model_manager.get_model("ultra_context")
        except:
            structure_model_id = await model_manager.get_model("primary")
            
        logger.info(f"Using model {structure_model_id} for structure extraction from text")
        
        # Get the provider to set appropriate hyperparameters
        provider = await model_manager.get_provider(structure_model_id)
        
        # Set up provider-specific hyperparameters
        max_tokens = None
        temperature = None
        
        if provider == "google_ai" and hasattr(settings, 'GOOGLE_MAX_TOKENS'):
            max_tokens = settings.GOOGLE_MAX_TOKENS
            temperature = settings.GOOGLE_TEMPERATURE
        elif provider == "bedrock" and hasattr(settings, 'BEDROCK_MAX_TOKENS'):
            max_tokens = settings.BEDROCK_MAX_TOKENS
            temperature = settings.BEDROCK_TEMPERATURE
        elif provider == "openai" and hasattr(settings, 'OPENAI_MAX_TOKENS'):
            max_tokens = settings.OPENAI_MAX_TOKENS
            temperature = settings.OPENAI_TEMPERATURE
        else:
            # Use defaults if provider-specific settings not available
            max_tokens = settings.DEFAULT_MAX_TOKENS
            temperature = settings.DEFAULT_TEMPERATURE
            
        # Ensure the max_tokens is appropriate for the task - structure can be large
        max_tokens = max(max_tokens, 15000)
        
        try:
            completion = await model_manager.get_completion(
                prompt=prompt,
                model_id=structure_model_id,
                max_tokens=max_tokens,
                temperature=temperature
                # No response_format - let provider-specific handling be managed internally
            )
            
            structure_str = completion.get("text", "{}")
            
            # Use the robust JSON parser to handle various formats 
            structure = await self.extract_json_from_text(structure_str)
            
            try:
                validated_structure = DocumentStructure(**structure).dict()
                return validated_structure
            except PydanticValidationError:
                return structure
                
        except Exception as e:
            logger.error(f"Error in structure extraction: {str(e)}")
            return {
                "sections": [], "tables": [], "financial_metrics": {}, "key_points": [],
                "extraction_error": f"Error: {str(e)}"
            }

    async def _extract_text_with_ai(self, content: bytes, filename: str, document: Dict[str, Any]) -> str:
        """Extract text from document using AI models"""
        model_manager = get_service("model_manager")

        # If PDF, use Gemini for extraction
        if filename.endswith('.pdf'):
            # ADDED: Check file size - skip large files (optional)
            if len(content) > 5000000:  # 5MB limit
                logger.warning(f"PDF too large for AI extraction ({len(content)/1024/1024:.2f} MB), using fallback")
                return await self._extract_text_fallback(content, filename)
                
            # Get prompt for text extraction
            prompt_system = get_service("prompt_system")
            try:
                pdf_extract_template_id = "system.pdf_extraction.pdf_extraction"
                logger.info(f"Using prompt template ID: {pdf_extract_template_id}")
                prompt = await prompt_system.get_prompt(
                    pdf_extract_template_id,
                    document_name=filename
                )
            except Exception as e:
                logger.error(f"Error getting PDF extraction prompt: {str(e)}. Using default.")
                prompt = f"Extract the complete text content from this PDF document named {filename}. Preserve all information including tables and structured data. Maintain the original formatting as much as possible."

            # Encode PDF as base64 for Gemini
            base64_pdf = base64.b64encode(content).decode('utf-8')

            try:
                text_extract_model_id = await model_manager.get_model("text_extract")
            except:
                text_extract_model_id = await model_manager.get_model("ultra_context")

            logger.info(f"Using model {text_extract_model_id} for PDF text extraction.")
            
            # Get the provider to set appropriate hyperparameters
            provider = await model_manager.get_provider(text_extract_model_id)
            
            # Set up provider-specific hyperparameters
            max_tokens = None
            temperature = None
            
            if provider == "google_ai" and hasattr(settings, 'GOOGLE_MAX_TOKENS'):
                max_tokens = settings.GOOGLE_MAX_TOKENS
                temperature = settings.GOOGLE_TEMPERATURE
            elif provider == "bedrock" and hasattr(settings, 'BEDROCK_MAX_TOKENS'):
                max_tokens = settings.BEDROCK_MAX_TOKENS
                temperature = settings.BEDROCK_TEMPERATURE
            elif provider == "openai" and hasattr(settings, 'OPENAI_MAX_TOKENS'):
                max_tokens = settings.OPENAI_MAX_TOKENS
                temperature = settings.OPENAI_TEMPERATURE
            else:
                # Use defaults if provider-specific settings not available
                max_tokens = settings.DEFAULT_MAX_TOKENS
                temperature = settings.DEFAULT_TEMPERATURE
                
            # Ensure the max_tokens is appropriate for the task - text extraction can be large
            max_tokens = max(max_tokens, 15000)
            
            try:
                completion = await model_manager.get_completion(
                    prompt=prompt,
                    model_id=text_extract_model_id,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    files=[{
                        "name": filename,
                        "content": base64_pdf,
                        "mime_type": "application/pdf"
                    }]
                )
                
                extracted_text = completion.get("text", "")
                if not extracted_text:
                    logger.warning(f"AI model returned empty text for {filename}")
                    raise ValueError("AI returned empty text")
                    
                return extracted_text
                
            except Exception as e:
                logger.error(f"Error in AI text extraction: {str(e)}")
                raise
        else:
            # For non-PDF, use text content directly
            logger.info(f"Decoding non-PDF file {filename} directly.")
            return content.decode('utf-8', errors='ignore')

    async def _extract_metadata_with_ai(self, text: str, filename: str, document: Dict[str, Any]) -> Dict[str, Any]:
        """Extract metadata from document using AI models"""
        model_manager = get_service("model_manager")
        prompt_system = get_service("prompt_system")

        # Get a metadata extraction prompt
        try:
            metadata_template_id = "system.metadata_extraction.metadata_extraction"
            prompt = await prompt_system.get_prompt(
                metadata_template_id,
                text=text[:15000]  # Use first 15K chars for metadata
            )
        except Exception as e:
            logger.error(f"Error getting metadata extraction prompt: {e}. Using default.")
            prompt = """Extract the following metadata from the document content:
1. Document Type (e.g., Teaser Deck, Deal Qualification Memo, Investment Summary, etc.)
2. Title or Project Name
3. Date (Publication or effective date, if available)
4. Author or Organization (if stated)
5. Industry Sector
6. Geographic Region
7. Key Financial Metrics
8. Transaction Type (if mentioned)
9. Key Topics or Themes (3-5 main subjects)

Return your response as a JSON object with these exact field names (all lowercase with underscores):
{
  "document_type": "Example Type",
  "title": "Example Title",
  "date": "2025-04-07",
  "author": "Example Author",
  "industry_sector": "Example Sector",
  "geographic_region": "Example Region",
  "key_financial_metrics": {"metric1": "value1"},
  "transaction_type": "Example Type",
  "key_topics": ["Topic 1", "Topic 2", "Topic 3"]
}

Document Content:
""" + text[:15000]

        # Use a capable model (Ultra Context should handle JSON well)
        try:
            metadata_model_id = await model_manager.get_model("ultra_context")
        except:
            metadata_model_id = await model_manager.get_model("primary")

        logger.info(f"Using model {metadata_model_id} for metadata extraction.")
        
        # Get the provider to set appropriate hyperparameters
        provider = await model_manager.get_provider(metadata_model_id)
        
        # Set up provider-specific hyperparameters
        max_tokens = None
        temperature = None
        
        if provider == "google_ai" and hasattr(settings, 'GOOGLE_MAX_TOKENS'):
            max_tokens = settings.GOOGLE_MAX_TOKENS
            temperature = settings.GOOGLE_TEMPERATURE
        elif provider == "bedrock" and hasattr(settings, 'BEDROCK_MAX_TOKENS'):
            max_tokens = settings.BEDROCK_MAX_TOKENS
            temperature = settings.BEDROCK_TEMPERATURE
        elif provider == "openai" and hasattr(settings, 'OPENAI_MAX_TOKENS'):
            max_tokens = settings.OPENAI_MAX_TOKENS
            temperature = settings.OPENAI_TEMPERATURE
        else:
            # Use defaults if provider-specific settings not available
            max_tokens = settings.DEFAULT_MAX_TOKENS
            temperature = settings.DEFAULT_TEMPERATURE
        
        try:
            completion = await model_manager.get_completion(
                prompt=prompt,
                model_id=metadata_model_id,
                max_tokens=max_tokens,
                temperature=temperature
                # No response_format - let provider-specific handling be managed internally
            )
            
            # Parse the JSON response using robust parser
            metadata_str = completion.get("text", "{}")
            metadata = await self.extract_json_from_text(metadata_str)

            # Ensure we have a document type
            if not metadata.get("document_type"):
                # Try to infer from filename
                if "teaser" in filename.lower():
                    metadata["document_type"] = "Teaser Deck"
                elif "dqm" in filename.lower():
                    metadata["document_type"] = "Deal Qualification Memo"
                elif "cim" in filename.lower():
                    metadata["document_type"] = "Confidential Investment Memo"
                elif "im" in filename.lower() or "memo" in filename.lower():
                    metadata["document_type"] = "Internal Memo"
                elif "summary" in filename.lower():
                    metadata["document_type"] = "Investment Summary"
                else:
                    metadata["document_type"] = "Unknown"

            # Add estimated token count
            metadata["estimated_token_count"] = await model_manager.estimate_tokens(text)

            # Validate against Pydantic model (optional but recommended)
            try:
                validated_metadata = DocumentMetadata(**metadata).dict()
                return validated_metadata
            except PydanticValidationError:
                return metadata
                
        except Exception as e:
            logger.error(f"Error in metadata extraction: {str(e)}")
            return {
                "document_type": "Unknown",
                "title": filename,
                "extraction_error": f"Error: {str(e)}"
            }

    async def _extract_structure_with_ai(self, content: bytes, filename: str, document: Dict[str, Any]) -> Dict[str, Any]:
        """Extract structure from document using AI models"""
        model_manager = get_service("model_manager")
        prompt_system = get_service("prompt_system")

        # Define the expected JSON schema for the Pydantic model DocumentStructure
        structure_schema = DocumentStructure.model_json_schema()

        # Use the extracted text for structure analysis if not PDF, or pass PDF if model supports it
        if filename.endswith('.pdf'):
            # Encode PDF as base64 for Gemini
            base64_pdf = base64.b64encode(content).decode('utf-8')
            input_content = [{
                "name": filename,
                "content": base64_pdf,
                "mime_type": "application/pdf"
            }]
            # Prompt needs to reference the attached file
            prompt_text_content = f"Analyze the structure of the attached PDF: {filename}"
        else:
            # Use text for non-PDF files
            input_content = None
            prompt_text_content = content.decode('utf-8', errors='ignore')[:20000] # Limit context for structure

        # Get structure extraction prompt
        try:
            structure_template_id = "system.structure_extraction.structure_extraction"
            prompt = await prompt_system.get_prompt(
                structure_template_id,
                text=prompt_text_content
            )
        except Exception as e:
            logger.error(f"Error getting structure extraction prompt: {e}. Using default.")
            prompt = """Extract the structure of the provided document including:
1. Sections: Identify main sections with their headings, level, and content summary
2. Tables: Extract tables with captions, headers, and data
3. Financial Metrics: Key financial data points
4. Key Points: Important takeaways

Return JSON format with these exact snake_case field names:
{
  "sections": [{"heading": "string", "content": "string", "level": integer}],
  "tables": [{"caption": "string", "headers": ["string"], "data": [["string"]]}],
  "financial_metrics": {"metric_name": "string_value"},
  "key_points": ["string"]
}

Document Content/Reference:
""" + prompt_text_content

        # Use a model capable of handling large context and structured output
        try:
            structure_model_id = await model_manager.get_model("ultra_context")
        except:
            structure_model_id = await model_manager.get_model("primary")

        logger.info(f"Using model {structure_model_id} for structure extraction.")
        
        # Get the provider to set appropriate hyperparameters
        provider = await model_manager.get_provider(structure_model_id)
        
        # Set up provider-specific hyperparameters
        max_tokens = None
        temperature = None
        
        if provider == "google_ai" and hasattr(settings, 'GOOGLE_MAX_TOKENS'):
            max_tokens = settings.GOOGLE_MAX_TOKENS
            temperature = settings.GOOGLE_TEMPERATURE
        elif provider == "bedrock" and hasattr(settings, 'BEDROCK_MAX_TOKENS'):
            max_tokens = settings.BEDROCK_MAX_TOKENS
            temperature = settings.BEDROCK_TEMPERATURE
        elif provider == "openai" and hasattr(settings, 'OPENAI_MAX_TOKENS'):
            max_tokens = settings.OPENAI_MAX_TOKENS
            temperature = settings.OPENAI_TEMPERATURE
        else:
            # Use defaults if provider-specific settings not available
            max_tokens = settings.DEFAULT_MAX_TOKENS
            temperature = settings.DEFAULT_TEMPERATURE
            
        # Ensure the max_tokens is appropriate for the task - structure can be large
        max_tokens = max(max_tokens, 15000)
        
        try:
            completion = await model_manager.get_completion(
                prompt=prompt,
                model_id=structure_model_id,
                max_tokens=max_tokens,
                temperature=temperature,
                files=input_content
                # No response_format - let provider-specific handling be managed internally
            )
            
            # Parse the JSON response using the robust parser
            structure_str = completion.get("text", "{}")
            structure = await self.extract_json_from_text(structure_str)

            # Validate against Pydantic model (optional)
            try:
                validated_structure = DocumentStructure(**structure).dict()
                return validated_structure
            except PydanticValidationError:
                return structure
                
        except Exception as e:
            logger.error(f"Error in structure extraction: {str(e)}")
            return {
                "sections": [], "tables": [], "financial_metrics": {}, "key_points": [],
                "extraction_error": f"Error: {str(e)}"
            }

    async def _extract_text_fallback(self, content: bytes, filename: str) -> str:
        """Extract text using fallback methods (PyPDF2 for PDF)"""
        logger.info(f"Using fallback text extraction for {filename}")
        if filename.endswith('.pdf'):
            # Ensure thread_pool is available before using it
            if not self.thread_pool:
                 logger.error("ThreadPoolExecutor not available for fallback PDF extraction.")
                 raise RuntimeError("ExtractionService fallback mechanism is not properly initialized.")

            return await self._extract_text_from_pdf_async(content)
        elif filename.endswith(('.docx', '.doc')):
            logger.warning(f"Fallback extraction not implemented for {filename}")
            return f"Document type not yet supported for extraction: {filename}"
        elif filename.endswith(('.txt', '.csv', '.md')): # Added markdown
            logger.info(f"Decoding text-based file {filename} directly.")
            return content.decode('utf-8', errors='ignore')
        else:
            logger.warning(f"Unsupported file type for fallback extraction: {filename}")
            return f"Unsupported file type for text extraction: {filename}"

    async def _extract_text_from_pdf_async(self, content: bytes) -> str:
        """Extract text from PDF content using PyPDF2 in a thread pool"""
        loop = asyncio.get_event_loop()
        # --- FIX: Ensure self.thread_pool exists before using ---
        if not self.thread_pool:
            logger.error("Cannot run PDF extraction fallback: ThreadPoolExecutor is not initialized.")
            raise RuntimeError("ThreadPoolExecutor not available for PDF fallback.")

        logger.info("Running PyPDF2 extraction in thread pool.")
        try:
            extracted_text = await loop.run_in_executor(
                self.thread_pool,
                self._extract_text_from_pdf_sync,
                content
            )
            logger.info("PyPDF2 extraction completed.")
            return extracted_text
        except Exception as e:
            logger.error(f"Error during PyPDF2 execution in thread pool: {e}")
            return f"PDF extraction error in fallback: {e}"


    def _extract_text_from_pdf_sync(self, content: bytes) -> str:
        """Synchronous PDF processing function to run in thread pool"""
        try:
            pdf_file = io.BytesIO(content)
            pdf_reader = PyPDF2.PdfReader(pdf_file)

            text_parts = []
            for page_num in range(len(pdf_reader.pages)):
                try:
                    page = pdf_reader.pages[page_num]
                    page_text = page.extract_text()
                    if page_text: # Only append if text was extracted
                         text_parts.append(page_text)
                except Exception as page_error:
                     logger.warning(f"Error extracting text from PDF page {page_num + 1}: {page_error}")
                     text_parts.append(f"[Error extracting page {page_num + 1}]")


            if not text_parts:
                 logger.warning("PyPDF2 extracted no text from the PDF.")
                 return "[Warning: No text could be extracted using PyPDF2]"

            return "\n\n".join(text_parts) # Use double newline as page separator
        except PyPDF2.errors.PdfReadError as pdf_err:
             logger.error(f"PyPDF2 error reading PDF: {pdf_err}")
             return f"PDF Read Error (PyPDF2): {pdf_err}"
        except Exception as e:
            logger.error(f"Unexpected error during synchronous PDF extraction: {str(e)}")
            return f"Unexpected PDF extraction error: {str(e)}"

    async def stop(self) -> bool:
        """Stop the extraction service"""
        try:
            # Shutdown thread pool
            if self.thread_pool:
                logger.info("Shutting down ExtractionService thread pool.")
                self.thread_pool.shutdown(wait=False) # Don't wait indefinitely
                self.thread_pool = None # Clear the reference

            return await super().stop()
        except Exception as e:
            logger.error(f"Error stopping extraction service: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Error stopping extraction service: {str(e)}"
            )
            return False

# Create the singleton instance
extraction_service = ExtractionService()