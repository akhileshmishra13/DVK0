# backend/app/services/event_handler.py
from typing import Dict, Any, Optional, List
import logging
import uuid
from datetime import datetime
from enum import Enum 
import pymongo # Import pymongo for errors
from motor.motor_asyncio import AsyncIOMotorDatabase # Import for type hint
from pydantic import ValidationError as PydanticValidationError # Alias to avoid confusion

from app.services.base_service import BaseService, ServiceStatus
from app.core.registry import get_service
from app.core.exceptions import DatabaseError

logger = logging.getLogger(__name__)

class ProcessStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class EventType(str, Enum):
    PROGRESS = "progress"
    ERROR = "error"
    INFO = "info"
    COMPLETION = "completion"

class EventHandler(BaseService):
    """
    Service for handling event tracking and process status in MongoDB
    """

    def __init__(self):
        # --- Apply consistent singleton initialization pattern ---
        if not hasattr(self, '_initialized_'):
            self.db: Optional[AsyncIOMotorDatabase] = None

            # Call super().__init__ AFTER setting subclass attributes
            super().__init__(name="event_handler", dependencies=["data_service"])

            # Update status details AFTER super init sets up the dict
            self.status_details.update({
                "processes_tracked": 0,
                "initialized": False
            })
            self._initialized_ = True # Mark as initialized

    async def initialize(self) -> bool:
        """Initialize event handler, ensuring database connection and collection setup"""
        try:
            # Get data_service from registry
            data_service = get_service("data_service")

            # --- FIX: Correct boolean check for db object ---
            # Ensure DataService is running AND has a valid db instance
            if data_service.status != ServiceStatus.RUNNING or data_service.db is None:
                 error_msg = f"DataService is not running ({data_service.status}) or database not initialized."
                 logger.error(error_msg)
                 raise RuntimeError(error_msg) # Raise specific error
            self.db = data_service.db
            logger.info("EventHandler obtained database instance from DataService.")

            # Create collection if it doesn't exist
            collection_name = "process_tracking"
            if collection_name not in await self.db.list_collection_names():
                await self.db.create_collection(collection_name)
                logger.info(f"Created MongoDB collection: {collection_name}")

            # Ensure indexes exist
            try:
                await self.db.process_tracking.create_index([("process_id", 1)], unique=True, background=True)
                await self.db.process_tracking.create_index([("status", 1)], background=True)
                await self.db.process_tracking.create_index([("created_at", -1)], background=True)
                logger.info("Ensured indexes exist on process_tracking collection.")
            except pymongo.errors.OperationFailure as e:
                 if "Index already exists" not in str(e) and "index options" not in str(e).lower(): # Handle slightly different error messages
                     logger.warning(f"Index creation warning (non-critical): {str(e)}")
                 else:
                     logger.info("Indexes on process_tracking already exist or cannot be modified.")
            except Exception as e:
                 logger.warning(f"Index creation warning (non-critical): {str(e)}")


            # Get process count
            process_count = await self.db.process_tracking.count_documents({})
            self.status_details["processes_tracked"] = process_count
            self.status_details["initialized"] = True

            # Call super().initialize() BEFORE update_status for consistent logging
            initialized_base = await super().initialize()
            if not initialized_base:
                 return False

            self.update_status(
                ServiceStatus.RUNNING,
                f"Event handler initialized with {process_count} tracked processes"
            )
            return True
        except RuntimeError as e:
             logger.error(f"Dependency error initializing EventHandler: {e}")
             self.update_status(ServiceStatus.ERROR, f"Dependency error: {e}")
             return False
        except Exception as e:
            logger.error(f"Error initializing event handler: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Event handler initialization error: {str(e)}"
            )
            return False

    async def create_process(self,
                             process_id: str,
                             process_type: str,
                             user_id: Optional[str] = None,
                             metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Create a new process tracking record
        """
        if self.db is None: # Check instance variable
             raise DatabaseError("Database not initialized. Cannot create process.")

        now = datetime.utcnow()
        process = {
            "process_id": process_id,
            "process_type": process_type,
            "user_id": user_id,
            "status": ProcessStatus.PENDING.value, # Use enum value
            "percentage": 0,
            "current_step": "Initializing",
            "metadata": metadata or {},
            "events": [
                {
                    "event_type": EventType.INFO.value, # Use enum value
                    "timestamp": now,
                    "message": "Process created",
                    "data": {}
                }
            ],
            "created_at": now,
            "updated_at": now
        }

        try:
            await self.db.process_tracking.insert_one(process)
            current_tracked = self.status_details.get("processes_tracked", 0)
            self.status_details["processes_tracked"] = current_tracked + 1

            logger.info(f"Created process tracking for process_id={process_id}, type={process_type}")
            # Return the created process dict (MongoDB doesn't add _id on insert_one return)
            # Remove internal _id before returning if it was somehow added
            process.pop("_id", None)
            return process
        except pymongo.errors.DuplicateKeyError:
            logger.error(f"Process with ID {process_id} already exists.")
            raise DatabaseError(f"Process ID {process_id} conflict.")
        except Exception as e:
            logger.error(f"Error creating process {process_id}: {e}")
            raise DatabaseError(f"Failed to create process: {e}")

    async def update_process(self,
                             process_id: str,
                             status: Optional[ProcessStatus] = None,
                             percentage: Optional[int] = None,
                             current_step: Optional[str] = None,
                             metadata_updates: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Update a process tracking record
        Returns the updated document or None if not found/error.
        """
        if self.db is None: # Check instance variable
             raise DatabaseError("Database not initialized. Cannot update process.")

        update_fields = {"updated_at": datetime.utcnow()}
        if status is not None:
            update_fields["status"] = status.value # Use enum value
        if percentage is not None:
            # Clamp percentage between 0 and 100
            update_fields["percentage"] = max(0, min(100, percentage))
        if current_step is not None:
            update_fields["current_step"] = current_step

        # Handle metadata updates safely
        update_pipeline = {"$set": update_fields}
        if metadata_updates:
            # Use dot notation for updating nested fields within metadata
            for key, value in metadata_updates.items():
                 # Basic check to prevent illegal keys, more robust validation might be needed
                 if not key.startswith('$') and '.' not in key:
                     update_pipeline["$set"][f"metadata.{key}"] = value
                 else:
                      logger.warning(f"Skipping potentially unsafe metadata key update: '{key}'")


        try:
            result = await self.db.process_tracking.update_one(
                {"process_id": process_id},
                update_pipeline # Use the pipeline with $set
            )

            if result.matched_count == 0:
                logger.warning(f"Process {process_id} not found for update.")
                return None

            logger.info(f"Updated process {process_id}: status={status}, percentage={percentage}, step={current_step}")
            # Fetch and return the updated document
            return await self.get_process(process_id)
        except Exception as e:
             logger.error(f"Error updating process {process_id}: {e}")
             # Optionally raise DatabaseError here
             return None # Indicate update failure


    async def add_event(self,
                         process_id: str,
                         event_type: EventType,
                         message: str,
                         data: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Add an event to a process. Returns the added event dict or None if failed.
        """
        if self.db is None: # Check instance variable
            raise DatabaseError("Database not initialized. Cannot add event.")

        event = {
            "event_id": str(uuid.uuid4()), # Add unique ID to events
            "event_type": event_type.value, # Use enum value
            "timestamp": datetime.utcnow(),
            "message": message,
            "data": data or {}
        }

        try:
            result = await self.db.process_tracking.update_one(
                {"process_id": process_id},
                {
                    "$push": {"events": {"$each": [event], "$slice": -100}}, # Keep last 100 events
                    "$set": {"updated_at": event["timestamp"]}
                }
            )

            if result.matched_count == 0:
                logger.warning(f"Process {process_id} not found for adding event.")
                return None

            logger.info(f"Added {event_type} event to process {process_id}: {message}")
            return event
        except Exception as e:
            logger.error(f"Error adding event to process {process_id}: {e}")
            # Optionally raise DatabaseError here
            return None


    async def get_process(self, process_id: str) -> Optional[Dict[str, Any]]:
        """
        Get process details by ID
        """
        if self.db is None: # Check instance variable
            logger.error("Database not initialized in EventHandler.")
            return None

        try:
            process = await self.db.process_tracking.find_one({"process_id": process_id})
            if not process:
                logger.warning(f"Process {process_id} not found.")
                return None

            # Convert ObjectId to str for JSON serialization
            if "_id" in process:
                 process["_id"] = str(process["_id"])
            return process
        except Exception as e:
             logger.error(f"Error retrieving process {process_id}: {e}")
             return None # Return None on error


    async def list_processes(self,
                            user_id: Optional[str] = None,
                            process_type: Optional[str] = None,
                            status: Optional[ProcessStatus] = None,
                            sort: Dict[str, Any] = None,
                            limit: int = 100) -> List[Dict[str, Any]]:
        """
        List processes with filtering and sorting

        Args:
            user_id: Filter by user ID
            process_type: Filter by process type
            status: Filter by process status
            sort: Sort parameters (e.g., {"created_at": -1})
            limit: Max number of results

        Returns:
            List of process records
        """
        if self.db is None: # Check instance variable
             raise DatabaseError("Database not initialized. Cannot list processes.")

        query = {}
        if user_id:
            query["user_id"] = user_id
        if process_type:
            query["process_type"] = process_type
        if status:
            query["status"] = status.value # Use enum value

        # Default sort by created_at descending
        sort_criteria = sort or {"created_at": -1}

        try:
            cursor = self.db.process_tracking.find(query).sort(
                 list(sort_criteria.items()) # Convert dict to list of tuples for sort
            ).limit(limit)

            processes = await cursor.to_list(length=limit)

            # Convert ObjectId to str for JSON serialization
            for process in processes:
                 if "_id" in process:
                     process["_id"] = str(process["_id"])

            return processes
        except Exception as e:
             logger.error(f"Error listing processes: {e}")
             raise DatabaseError(f"Failed to list processes: {e}")

    async def count_processes(self,
                            user_id: Optional[str] = None,
                            process_type: Optional[str] = None,
                            status: Optional[ProcessStatus] = None) -> int:
        """
        Count processes with optional filtering

        Args:
            user_id: Filter by user ID
            process_type: Filter by process type
            status: Filter by process status

        Returns:
            Total count of matching processes
        """
        if self.db is None: # Check instance variable
             raise DatabaseError("Database not initialized. Cannot count processes.")

        query = {}
        if user_id:
            query["user_id"] = user_id
        if process_type:
            query["process_type"] = process_type
        if status:
            query["status"] = status.value # Use enum value

        try:
            count = await self.db.process_tracking.count_documents(query)
            return count
        except Exception as e:
             logger.error(f"Error counting processes: {e}")
             raise DatabaseError(f"Failed to count processes: {e}")

    async def stop(self) -> bool:
        """Stop the event handler"""
        try:
            # No specific cleanup needed as DB connection is managed by DataService
            self.db = None # Clear DB reference
            return await super().stop()
        except Exception as e:
            logger.error(f"Error stopping event handler: {str(e)}")
            self.update_status(
                ServiceStatus.ERROR,
                f"Error stopping event handler: {str(e)}"
            )
            return False


# Create the singleton instance
event_handler = EventHandler()