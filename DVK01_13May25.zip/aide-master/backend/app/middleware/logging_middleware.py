# backend/app/middleware/logging_middleware.py
import time
import uuid
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from app.utils.logging_context import LoggingContext
from app.core.registry import get_service

class LoggingMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    
    async def dispatch(self, request: Request, call_next):
        # Generate a request ID
        request_id = str(uuid.uuid4())
        request.state.request_id = request_id
        
        # Extract correlation ID from headers if present, or use request ID
        correlation_id = request.headers.get("x-correlation-id", request_id)
        
        # Try to get user ID from auth token
        user_id = None
        if "authorization" in request.headers:
            # In a real implementation, we would extract the user ID from the token
            # For now, we'll just set a placeholder
            user_id = "authenticated_user"
        
        # Start timing the request
        start_time = time.time()
        
        # Get the logging service
        try:
            logging_service = get_service("logging_service")
        except KeyError:
            # If logging service is not yet registered, we can't log
            return await call_next(request)
        
        # Create a logging context for this request
        with LoggingContext(request_id=request_id, user_id=user_id, correlation_id=correlation_id):
            # Log the request
            logging_service.log(
                "info",
                f"Request {request.method} {request.url.path}",
                "http",
                request_id=request_id,
                user_id=user_id,
                correlation_id=correlation_id,
                headers={k: v for k, v in request.headers.items() if k.lower() not in ['authorization', 'cookie']}
            )
            
            # Process the request
            try:
                response = await call_next(request)
                
                # Calculate processing time
                process_time = time.time() - start_time
                
                # Log the response
                logging_service.log(
                    "info",
                    f"Response {response.status_code} completed in {process_time:.4f}s",
                    "http",
                    request_id=request_id,
                    user_id=user_id,
                    correlation_id=correlation_id,
                    status_code=response.status_code,
                    process_time=f"{process_time:.4f}s"
                )
                
                # Add request ID and correlation ID to response headers
                response.headers["X-Request-ID"] = request_id
                response.headers["X-Correlation-ID"] = correlation_id
                
                return response
            except Exception as e:
                # Log the exception
                logging_service.log(
                    "error",
                    f"Error processing request: {str(e)}",
                    "http",
                    request_id=request_id,
                    user_id=user_id,
                    correlation_id=correlation_id,
                    error=str(e),
                    error_type=type(e).__name__
                )
                # Re-raise the exception
                raise