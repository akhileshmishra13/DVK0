#!/bin/bash
# Quick access to MongoDB shell and tools for development
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$SCRIPT_DIR/docdb_dev.py" "$@"
