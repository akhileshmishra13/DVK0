#!/usr/bin/env python3
"""
DocumentDB Interactive Shell - Development Version
-------------------------------------------------
Provides interactive access to the AIDE local MongoDB database.
Follows the same pattern as the production docdb_shell.py
"""
import os
import sys
import json
import argparse
import code
from datetime import datetime
from pymongo import MongoClient
from bson import json_util

def interactive_shell():
    """Launch an interactive MongoDB shell"""
    print("Connecting to local MongoDB database...")
    
    # Connect using the same URL as the application
    mongodb_url = "mongodb://aideusr:aidepwd@localhost:27017"
    db_name = "aide_db"
    
    print(f"Connected to: localhost:27017")
    print(f"Database: {db_name}")
    
    # Connect with proper settings
    client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
    db = client[db_name]
    
    # Add helper functions - same as in the production script
    def list_collections():
        """List all collections with document counts"""
        collections = db.list_collection_names()
        result = []
        for coll in sorted(collections):
            count = db[coll].count_documents({})
            result.append({"collection": coll, "documents": count})
        return result

    def list_documents(collection="fs.files", limit=10, query=None, projection=None):
        """List documents in a collection with optional query and projection"""
        if query is None:
            query = {}
        if projection is None:
            projection = {"_id": 1}
        
        return list(db[collection].find(query, projection).limit(limit))

    def pretty(obj):
        """Pretty print an object"""
        return json.dumps(json.loads(json_util.dumps(obj)), indent=2)

    def stats():
        """Get database stats"""
        return db.command("dbstats")

    def collection_stats(collection="fs.files"):
        """Get collection stats"""
        return db.command("collStats", collection)

    def help():
        """Show available helper functions"""
        print("\nAvailable helper functions:")
        print("  list_collections() - List all collections with document counts")
        print("  list_documents(collection='fs.files', limit=10, query=None, projection=None)")
        print("  pretty(obj) - Pretty print an object")
        print("  stats() - Get database stats")
        print("  collection_stats(collection) - Get collection stats")
        print("  help() - Show this help")
        print("\nAvailable variables:")
        print("  client - MongoDB client")
        print("  db - Database object")
        print("\nExample queries:")
        print("  db.fs.files.find_one()")
        print("  list(db.fs.files.find({'filename': 'Project Atlas Teaser.pdf'}))")
        print("  db.fs.files.update_one({'filename': 'Project Phoenix IM.pdf'}, {'$set': {'new_field': 'value'}})")

    print("\n=== AIDE MongoDB Interactive Shell (Development) ===")
    help()
    print("\nPress Ctrl+D to exit")

    # Start interactive shell
    code.interact(local=locals())

def main():
    parser = argparse.ArgumentParser(description="MongoDB interactive shell for development")
    parser.add_argument("--collections", action="store_true", help="List collections")
    parser.add_argument("--documents", action="store_true", help="List documents")
    parser.add_argument("--stats", action="store_true", help="Show database stats")
    
    args = parser.parse_args()
    
    # Connect using the same URL as the application
    mongodb_url = "mongodb://aideusr:aidepwd@localhost:27017"
    db_name = "aide_db"
    
    if args.collections:
        # Just list collections
        client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
        db = client[db_name]
        
        collections = db.list_collection_names()
        for coll in sorted(collections):
            count = db[coll].count_documents({})
            print(f"{coll}: {count} documents")
    elif args.documents:
        # List documents
        client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
        db = client[db_name]
        
        print("Documents in fs.files:")
        for doc in db.fs.files.find():
            try:
                doc_type = doc.get('metadata', {}).get('extracted_metadata', {}).get('document_type', 'Unknown')
                print(f"- {doc.get('filename', 'Unnamed')} ({doc_type})")
                print(f"  Uploaded: {doc.get('uploadDate', 'Unknown')}")
                print(f"  Size: {doc.get('length', 0)} bytes")
                print(f"  ID: {doc.get('_id', 'Unknown')}")
                print()
            except Exception as e:
                print(f"Error processing document: {e}")
    elif args.stats:
        # Show stats
        client = MongoClient(f"{mongodb_url}/{db_name}?authSource=admin")
        db = client[db_name]
        
        stats = db.command("dbStats")
        print("Database Stats:")
        print(f"Database: {stats['db']}")
        print(f"Collections: {stats['collections']}")
        print(f"Views: {stats['views']}")
        print(f"Objects: {stats['objects']}")
        print(f"Data Size: {stats['dataSize']} bytes")
        print(f"Storage Size: {stats['storageSize']} bytes")
        print(f"Indexes: {stats['indexes']}")
        print(f"Index Size: {stats['indexSize']} bytes")
    else:
        # Default to interactive shell
        interactive_shell()

if __name__ == "__main__":
    main()
