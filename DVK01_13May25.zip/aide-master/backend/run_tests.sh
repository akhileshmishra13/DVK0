#!/bin/bash
# Simple script to run tests with the correct Python path

# Set PYTHONPATH to current directory
export PYTHONPATH=.

# Run all tests except completion
if [ "$1" == "all" ]; then
  pytest tests/ -v
# Run only completion tests
elif [ "$1" == "completion" ]; then
  pytest -m completion -v
# Run all tests except completion
elif [ "$1" == "standard" ]; then
  pytest -m "not completion" -v
# Run specific test file
else
  pytest $1 -v
fi