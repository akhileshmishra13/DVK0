import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { documentApi, extractErrorMessage } from '../services/apiService';
import { estimateTokensFromFileSize } from '../config/documentConfig';

// Async thunks
export const fetchDocuments = createAsyncThunk(
  'documents/fetchDocuments',
  async (_, { rejectWithValue }) => {
    try {
      const response = await documentApi.getDocuments();
      
      // Add token estimation for each document if not provided
      const documentsWithTokens = (response.data?.data || []).map(doc => {
        if (!doc.token_count && doc.length) {
          doc.token_count = estimateTokensFromFileSize(doc.length);
        }
        return doc;
      });
      
      return documentsWithTokens;
    } catch (error) {
      return rejectWithValue(extractErrorMessage(error));
    }
  }
);

export const uploadDocument = createAsyncThunk(
  'documents/uploadDocument',
  async (file, { rejectWithValue }) => {
    try {
      const response = await documentApi.uploadDocument(file);
      
      // Add token estimation to the response data if not provided by the backend
      if (response.data && response.data.data && !response.data.data.token_count) {
        response.data.data.token_count = estimateTokensFromFileSize(file.size);
      }
      
      return response.data;
    } catch (error) {
      return rejectWithValue(extractErrorMessage(error));
    }
  }
);

export const deleteDocument = createAsyncThunk(
  'documents/deleteDocument',
  async (documentId, { rejectWithValue, dispatch }) => {
    try {
      await documentApi.deleteDocument(documentId);
      dispatch(fetchDocuments());
      
      // Also remove from selected documents
      dispatch(removeSelectedDocument(documentId));
      return documentId;
    } catch (error) {
      return rejectWithValue(extractErrorMessage(error));
    }
  }
);

const initialState = {
  documents: [],
  selectedDocuments: [],
  isLoading: false,
  error: null,
  totalTokens: 0
};

const documentSlice = createSlice({
  name: 'documents',
  initialState,
  reducers: {
    setDocuments: (state, action) => {
      state.documents = action.payload;
    },
    addSelectedDocument: (state, action) => {
      // Check if document is already in the array to prevent duplicates
      const docId = action.payload.id || action.payload.document_id;
      if (!state.selectedDocuments.some(doc => (doc.id || doc.document_id) === docId)) {
        // Ensure we have a token count
        if (!action.payload.token_count && action.payload.length) {
          action.payload.token_count = estimateTokensFromFileSize(action.payload.length);
        }
        
        state.selectedDocuments.push(action.payload);
        state.totalTokens += action.payload.token_count || 0;
      }
    },
    removeSelectedDocument: (state, action) => {
      const documentId = action.payload;
      const doc = state.selectedDocuments.find(d => 
        (d.id === documentId) || (d.document_id === documentId)
      );
      if (doc) {
        state.totalTokens -= doc.token_count || 0;
      }
      state.selectedDocuments = state.selectedDocuments.filter(doc => 
        (doc.id !== documentId) && (doc.document_id !== documentId)
      );
    },
    setLoading: (state, action) => {
      state.isLoading = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },
    clearSelectedDocuments: (state) => {
      state.selectedDocuments = [];
      state.totalTokens = 0;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchDocuments.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchDocuments.fulfilled, (state, action) => {
        state.isLoading = false;
        state.documents = action.payload;
      })
      .addCase(fetchDocuments.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(uploadDocument.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(uploadDocument.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(uploadDocument.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })

      .addCase(deleteDocument.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteDocument.fulfilled, (state) => {
        state.isLoading = false;
      })
      .addCase(deleteDocument.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  }
});

export const {
  setDocuments,
  addSelectedDocument,
  removeSelectedDocument,
  setLoading,
  setError,
  clearSelectedDocuments
} = documentSlice.actions;

export default documentSlice.reducer;