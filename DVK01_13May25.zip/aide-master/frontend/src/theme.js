// frontend/src/theme.js

import { createTheme, responsiveFontSizes } from '@mui/material/styles';

// Deep dark AI color palette
const colors = {
  primary: {
    main: '#3A72F8', // Vibrant blue
    light: '#61A0FF',
    dark: '#2851D8',
    contrastText: '#FFFFFF',
  },
  secondary: {
    main: '#2DD4BF', // Teal accent
    light: '#7EEEDD',
    dark: '#00A99D',
    contrastText: '#FFFFFF',
  },
  background: {
    default: '#0A101F', // Very dark blue
    paper: '#111827', // Dark blue-gray
    dark: '#080E1A', // Even darker
    gradient: 'linear-gradient(90deg, rgba(58,114,248,0.08) 0%, rgba(45,212,191,0.08) 100%)',
  },
  text: {
    primary: '#E2E8F0',
    secondary: '#94A3B8',
    disabled: '#64748B',
  },
  success: {
    main: '#10B981',
    light: '#6EE7B7',
    dark: '#059669',
  },
  info: {
    main: '#3B82F6',
    light: '#93C5FD',
    dark: '#1D4ED8',
  },
  warning: {
    main: '#F59E0B',
    light: '#FCD34D',
    dark: '#D97706',
  },
  error: {
    main: '#EF4444',
    light: '#FCA5A5',
    dark: '#B91C1C',
  },
  divider: 'rgba(99, 117, 149, 0.2)',
};

// Create the base theme
let theme = createTheme({
  palette: {
    mode: 'dark',
    ...colors,
  },
  typography: {
    fontFamily: '"Inter", "SF Pro Display", "Roboto", "Helvetica", "Arial", sans-serif',
    h1: {
      fontSize: '2.5rem',
      fontWeight: 700,
      lineHeight: 1.2,
      letterSpacing: '-0.01em',
      color: colors.text.primary,
    },
    h2: {
      fontSize: '2rem',
      fontWeight: 700,
      lineHeight: 1.2,
      letterSpacing: '-0.01em',
      color: colors.text.primary,
    },
    h3: {
      fontSize: '1.5rem',
      fontWeight: 600,
      lineHeight: 1.2,
      letterSpacing: '-0.01em',
      color: colors.text.primary,
    },
    h4: {
      fontSize: '1.25rem',
      fontWeight: 600,
      lineHeight: 1.2,
      color: colors.text.primary,
    },
    h5: {
      fontSize: '1.1rem',
      fontWeight: 500,
      lineHeight: 1.2,
      color: colors.text.primary,
    },
    h6: {
      fontSize: '1rem',
      fontWeight: 500,
      lineHeight: 1.2,
      color: colors.text.primary,
    },
    subtitle1: {
      fontSize: '1rem',
      fontWeight: 500,
      lineHeight: 1.5,
      color: colors.text.secondary,
    },
    subtitle2: {
      fontSize: '0.875rem',
      fontWeight: 500,
      lineHeight: 1.4,
      color: colors.text.secondary,
    },
    body1: {
      fontSize: '1rem',
      lineHeight: 1.5,
      color: colors.text.primary,
    },
    body2: {
      fontSize: '0.875rem',
      lineHeight: 1.5,
      color: colors.text.primary,
    },
    button: {
      fontSize: '0.875rem',
      fontWeight: 600,
      lineHeight: 1.75,
      textTransform: 'none',
    },
  },
  shape: {
    borderRadius: 12,
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          backgroundColor: colors.background.default,
          color: colors.text.primary,
        }
      }
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundColor: colors.background.paper,
          backgroundImage: 'none',
          color: colors.text.primary,
          borderRadius: 16,
        }
      }
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: 'rgba(17, 24, 39, 0.8)',
          backdropFilter: 'blur(8px)',
          borderBottom: '1px solid rgba(99, 117, 149, 0.2)',
        }
      }
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: colors.background.dark,
          backgroundImage: 'none',
          borderRight: 'none',
        }
      }
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          borderBottom: '1px solid rgba(99, 117, 149, 0.2)',
        }
      }
    },
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: colors.background.paper,
          backgroundImage: 'none',
        }
      }
    },
    MuiCardContent: {
      styleOverrides: {
        root: {
          backgroundColor: colors.background.paper,
          backgroundImage: 'none',
        }
      }
    },
    MuiDialog: {
      styleOverrides: {
        paper: {
          backgroundColor: colors.background.paper,
          backgroundImage: 'none',
        }
      }
    },
    MuiPopover: {
      styleOverrides: {
        paper: {
          backgroundColor: colors.background.paper,
          backgroundImage: 'none',
        }
      }
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          borderColor: 'rgba(99, 117, 149, 0.2)',
        }
      }
    },
  },
});

// Make typography responsive
theme = responsiveFontSizes(theme);

export default theme;
