// frontend/src/config/modelConfig.js

import React from 'react';
import GrainIcon from '@mui/icons-material/Grain';
import TerminalIcon from '@mui/icons-material/Terminal';
import AssessmentIcon from '@mui/icons-material/Assessment';
import BarChartIcon from '@mui/icons-material/BarChart';
import PublicIcon from '@mui/icons-material/Public';
import PsychologyIcon from '@mui/icons-material/Psychology';

const modelConfig = [
  {
    type: 'primary',
    displayName: 'Google Gemini 2.5',
    actualModelName: 'gemini-2.5-flash-preview-04-17',
    description: 'Latest model with most advanced reasoning capabilities',
    color: '#4285F4', // Google blue
    icon: <GrainIcon />,
    context: 'Best for complex analysis and complex deal documents',
    contextWindow: 1000000,
    maxOutputTokens: 30000,
    features: ['Most advanced reasoning', 'Deep analysis'],
    provider: 'Google',
    recommended: true
  },
  {
    type: 'advanced_reasoning',
    displayName: 'Anthropic Claude 3.7',
    actualModelName: 'anthropic.claude-3-7-sonnet-20250219-v1:0',
    description: 'Advanced structured reasoning for complex analysis',
    color: '#8B5CF6',
    icon: <PsychologyIcon />,
    context: 'Thoughtful, refined evaluation via the best Bedrock model',
    contextWindow: 200000,
    maxOutputTokens: 30000,
    features: ['Sophisticated evaluation', 'Nuanced review'],
    provider: 'Bedrock (Anthropic)'
  },
  {
    type: 'fallback',
    displayName: 'OpenAI o1',
    actualModelName: 'o1', 
    description: 'Strong reasoning and analytical capabilities',
    color: '#3A72F8',
    icon: <TerminalIcon />,
    context: 'Strong fallback for complex reasoning tasks',
    contextWindow: 200000,
    maxOutputTokens: 30000,
    features: ['Strong reasoning', 'Exceptionally efficient'],
    provider: 'OpenAI'
  },
  {
    type: 'ultra_context',
    displayName: 'Ultra-Long Context',
    actualModelName: 'gemini-2.0-flash-001',
    description: 'Massive document handling capacity',
    color: '#8B5CF6',
    icon: <AssessmentIcon />,
    context: 'Best for analyzing multiple large documents',
    contextWindow: 1000000,
    maxOutputTokens: 30000,
    features: ['Multi-document analysis', 'Comprehensive comparison'],
    provider: 'Google'
  },
  {
    type: 'text_extract',
    displayName: 'Fast Text Extraction',
    actualModelName: 'gemini-2.0-flash-001',
    description: 'Optimized for document extraction',
    color: '#F59E0B',
    icon: <BarChartIcon />,
    context: 'Best for rapid document processing',
    contextWindow: 1000000,
    maxOutputTokens: 30000,
    features: ['Rapid extraction', 'Document structure analysis'],
    provider: 'Google'
  }
];

export default modelConfig;