// frontend/src/services/authService.js
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

// Set API URL based on environment
const API_URL = process.env.NODE_ENV === 'development' 
  ? 'http://localhost:8000'  // Development
  : '';                      // Production (relative URL)

// Session timeout in seconds (3 hours)
const SESSION_TIMEOUT = 3 * 60 * 60;

class AuthService {
  async login(email, password) {
    try {
      const response = await axios.post(`${API_URL}/auth/login/`, {
        email,
        password
      });
      
      // Handle different response formats
      if (response.data && response.data.status === "success" && response.data.data) {
        const { access_token, id_token, refresh_token } = response.data.data;
        this.setTokens(access_token, id_token, refresh_token);
        return response.data;
      } else if (response.data && response.data.access_token) {
        const { access_token, id_token, refresh_token } = response.data;
        this.setTokens(access_token, id_token, refresh_token);
        return { status: "success", data: response.data };
      }
      
      throw new Error('Login failed: Invalid response format');
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  }

  logout() {
    localStorage.removeItem('aide_access_token');
    localStorage.removeItem('aide_id_token');
    localStorage.removeItem('aide_refresh_token');
    localStorage.removeItem('aide_user');
    localStorage.removeItem('aide_last_activity');
  }

  setTokens(accessToken, idToken, refreshToken) {
    // Store tokens
    localStorage.setItem('aide_access_token', accessToken);
    if (idToken) localStorage.setItem('aide_id_token', idToken);
    if (refreshToken) localStorage.setItem('aide_refresh_token', refreshToken);
    
    // Record current timestamp as last activity
    this.updateLastActivity();
    
    // Store user data
    let user = {
      email: 'john@deepvertical.ai',
      name: 'John',
    };
    
    // Extract user data from the id token if possible
    if (idToken) {
      try {
        const decoded = jwtDecode(idToken);
        user = {
          email: decoded.email || user.email,
          name: decoded.name || user.name,
          sub: decoded.sub
        };
      } catch (error) {
        console.warn('Failed to decode token:', error);
      }
    }
    
    localStorage.setItem('aide_user', JSON.stringify(user));
  }

  updateLastActivity() {
    localStorage.setItem('aide_last_activity', Date.now().toString());
  }

  getLastActivity() {
    const lastActivity = localStorage.getItem('aide_last_activity');
    return lastActivity ? parseInt(lastActivity, 10) : null;
  }

  hasSessionTimedOut() {
    const lastActivity = this.getLastActivity();
    if (!lastActivity) return true;
    
    const now = Date.now();
    return (now - lastActivity) > (SESSION_TIMEOUT * 1000);
  }

  isTokenExpired(token) {
    if (!token) return true;
    
    try {
      const decoded = jwtDecode(token);
      const currentTime = Date.now() / 1000;
      return decoded.exp < currentTime;
    } catch (error) {
      console.warn('Failed to check token expiration:', error);
      return true;
    }
  }

  getCurrentUser() {
    const userStr = localStorage.getItem('aide_user');
    if (!userStr) return null;
    return JSON.parse(userStr);
  }

  getAccessToken() {
    return localStorage.getItem('aide_access_token');
  }

  isAuthenticated() {
    const token = this.getAccessToken();
    
    // Check if token exists
    if (!token) return false;
    
    // Check if token is expired
    if (this.isTokenExpired(token)) {
      this.logout();
      return false;
    }
    
    // Check if session has timed out
    if (this.hasSessionTimedOut()) {
      this.logout();
      return false;
    }
    
    return true;
  }
}

const authServiceInstance = new AuthService();
export default authServiceInstance;