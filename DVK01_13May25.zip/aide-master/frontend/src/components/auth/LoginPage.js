// frontend/src/components/auth/LoginPage.js
import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  TextField,
  Typography,
  Paper,
  Container,
  Alert,
  CircularProgress,
  IconButton,
  InputAdornment,
  Fade
} from '@mui/material';
import { login, clearError } from '../../store/authSlice';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import SecurityIcon from '@mui/icons-material/Security';

// Neural network animation component
const NeuralAnimation = () => (
  <Box
    component="div"
    sx={{
      position: 'absolute',
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      top: 0,
      left: 0,
      zIndex: 0,
      opacity: 0.4,
      '& .dot': {
        position: 'absolute',
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(58,114,248,0.8) 0%, rgba(58,114,248,0) 70%)',
      }
    }}
  >
    {Array.from({ length: 12 }).map((_, i) => (
      <Box
        key={i}
        className="dot"
        sx={{
          width: () => Math.random() * 160 + 40,
          height: () => Math.random() * 160 + 40,
          left: () => Math.random() * 100 + '%',
          top: () => Math.random() * 100 + '%',
          opacity: () => Math.random() * 0.5 + 0.1,
          animation: `pulse ${Math.random() * 8 + 8}s infinite alternate`,
          animationDelay: `${Math.random() * 5}s`,
          filter: 'blur(40px)',
          transform: 'translate(-50%, -50%)',
        }}
      />
    ))}
    <style jsx="true">{`
      @keyframes pulse {
        0% {
          transform: translate(-50%, -50%) scale(0.8);
          opacity: 0.3;
        }
        100% {
          transform: translate(-50%, -50%) scale(1.2);
          opacity: 0.6;
        }
      }
    `}</style>
  </Box>
);

// Neural network connection lines
const NeuralConnections = () => (
  <Box
    component="div"
    sx={{
      position: 'absolute',
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      top: 0,
      left: 0,
      zIndex: 0,
      opacity: 0.15
    }}
  >
    <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="connectGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3A72F8" />
          <stop offset="100%" stopColor="#2DD4BF" />
        </linearGradient>
      </defs>
      {Array.from({ length: 15 }).map((_, i) => {
        const x1 = Math.random() * 100;
        const y1 = Math.random() * 100;
        const x2 = Math.random() * 100;
        const y2 = Math.random() * 100;
        return (
          <line 
            key={i} 
            x1={`${x1}%`} 
            y1={`${y1}%`} 
            x2={`${x2}%`} 
            y2={`${y2}%`} 
            stroke="url(#connectGradient)" 
            strokeWidth="1"
            strokeOpacity="0.5"
          >
            <animate 
              attributeName="strokeOpacity"
              values="0.2;0.5;0.2"
              dur={`${Math.random() * 5 + 5}s`}
              repeatCount="indefinite"
            />
          </line>
        );
      })}
    </svg>
  </Box>
);

// Main Login Component
const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const { isLoading, error, isAuthenticated } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  useEffect(() => {
    // Clear any previous errors
    dispatch(clearError());
    
    // Redirect if already authenticated
    if (isAuthenticated) {
      navigate('/');
    }
  }, [dispatch, isAuthenticated, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    dispatch(login({ email, password }));
  };

  const handleTogglePassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Container component="main" maxWidth="sm" sx={{ height: '100vh', display: 'flex', alignItems: 'center' }}>
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          width: '100%',
          position: 'relative',
          zIndex: 1,
        }}
      >
        {/* Logo and Brand */}
        <Fade in={true} timeout={1000}>
          <Box 
            sx={{ 
              mb: 4, 
              display: 'flex', 
              flexDirection: 'column', 
              alignItems: 'center',
              position: 'relative'
            }}
          >
            <Box 
              sx={{ 
                width: 80, 
                height: 80, 
                borderRadius: '50%', 
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                background: 'linear-gradient(135deg, rgba(58,114,248,0.4) 0%, rgba(45,212,191,0.4) 100%)',
                boxShadow: '0 0 40px rgba(58,114,248,0.4)',
                mb: 2,
                position: 'relative',
                '&::before': {
                  content: '""',
                  position: 'absolute',
                  top: '-3px',
                  left: '-3px',
                  right: '-3px',
                  bottom: '-3px',
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg, #3A72F8 0%, #2DD4BF 100%)',
                  zIndex: -1,
                  opacity: 0.6,
                }
              }}
            >
              <SecurityIcon sx={{ fontSize: 40, color: '#fff' }} />
            </Box>
            <Typography 
              component="h1" 
              variant="h3" 
              sx={{ 
                fontWeight: 700, 
                background: 'linear-gradient(90deg, #3A72F8 0%, #2DD4BF 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                position: 'relative',
                textShadow: '0 0 20px rgba(58,114,248,0.3)',
                letterSpacing: '-0.02em'
              }}
            >
              KEPPEL AIDE
            </Typography>
            <Typography 
              variant="subtitle1" 
              sx={{ 
                color: 'rgba(255,255,255,0.7)',
                mt: 1,
                letterSpacing: '0.05em',
                textTransform: 'uppercase',
                fontSize: '0.8rem'
              }}
            >
              AI Deal Evaluation System
            </Typography>
          </Box>
        </Fade>

        <Fade in={true} timeout={1500}>
          <Paper
            elevation={8}
            sx={{
              p: 4,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              borderRadius: 3,
              width: '100%',
              backgroundColor: 'rgba(17, 24, 39, 0.75)',
              backdropFilter: 'blur(12px)',
              border: '1px solid rgba(99, 117, 149, 0.2)',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.3)',
              position: 'relative',
              overflow: 'hidden',
              zIndex: 1,
            }}
          >
            {/* Background effects */}
            <NeuralAnimation />
            <NeuralConnections />
            
            <Typography 
              variant="h5" 
              sx={{ 
                mb: 4, 
                fontWeight: 600, 
                color: '#E2E8F0',
                position: 'relative',
                zIndex: 2
              }}
            >
              Sign In
            </Typography>
            
            {error && (
              <Fade in={true}>
                <Alert 
                  severity="error" 
                  sx={{ 
                    mb: 3, 
                    width: '100%',
                    backgroundColor: 'rgba(239, 68, 68, 0.15)',
                    border: '1px solid rgba(239, 68, 68, 0.3)',
                    '& .MuiAlert-icon': {
                      color: 'rgba(239, 68, 68, 0.8)'
                    }
                  }}
                >
                  {error}
                </Alert>
              </Fade>
            )}
            
            <Box 
              component="form" 
              onSubmit={handleSubmit} 
              sx={{ 
                mt: 1, 
                width: '100%',
                position: 'relative',
                zIndex: 2
              }}
            >
              <TextField
                margin="normal"
                required
                fullWidth
                id="email"
                label="Email Address"
                name="email"
                autoComplete="email"
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 2,
                    transition: 'all 0.2s ease-in-out',
                    '& fieldset': {
                      borderColor: 'rgba(255, 255, 255, 0.2)',
                      borderWidth: 1,
                    },
                    '&:hover fieldset': {
                      borderColor: 'rgba(58, 114, 248, 0.5)',
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: '#3A72F8',
                      borderWidth: 2,
                      boxShadow: '0 0 8px rgba(58, 114, 248, 0.4)'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: 'rgba(255, 255, 255, 0.7)',
                    '&.Mui-focused': {
                      color: '#61A0FF'
                    }
                  },
                  '& .MuiInputBase-input': {
                    color: '#E2E8F0',
                    padding: '16px 14px',
                  },
                  mb: 2,
                }}
                InputProps={{
                  sx: {
                    '&::placeholder': {
                      color: 'rgba(255, 255, 255, 0.5)',
                    }
                  }
                }}
              />
              
              <TextField
                margin="normal"
                required
                fullWidth
                name="password"
                label="Password"
                type={showPassword ? 'text' : 'password'}
                id="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 2,
                    transition: 'all 0.2s ease-in-out',
                    '& fieldset': {
                      borderColor: 'rgba(255, 255, 255, 0.2)',
                      borderWidth: 1,
                    },
                    '&:hover fieldset': {
                      borderColor: 'rgba(58, 114, 248, 0.5)',
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: '#3A72F8',
                      borderWidth: 2,
                      boxShadow: '0 0 8px rgba(58, 114, 248, 0.4)'
                    }
                  },
                  '& .MuiInputLabel-root': {
                    color: 'rgba(255, 255, 255, 0.7)',
                    '&.Mui-focused': {
                      color: '#61A0FF'
                    }
                  },
                  '& .MuiInputBase-input': {
                    color: '#E2E8F0',
                    padding: '16px 14px',
                  },
                  mb: 1,
                }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleTogglePassword}
                        edge="end"
                        sx={{ color: 'rgba(255, 255, 255, 0.7)' }}
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              
              <Button
                type="submit"
                fullWidth
                variant="contained"
                disabled={isLoading}
                sx={{ 
                  mt: 4, 
                  mb: 2, 
                  p: 1.5,
                  height: 56,
                  fontSize: '1rem',
                  fontWeight: 600,
                  borderRadius: 2,
                  background: 'linear-gradient(90deg, #3A72F8 0%, #2DD4BF 100%)',
                  boxShadow: '0 4px 20px rgba(58, 114, 248, 0.25)',
                  transition: 'all 0.3s ease-in-out',
                  position: 'relative',
                  overflow: 'hidden',
                  '&::before': {
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: '-100%',
                    width: '100%',
                    height: '100%',
                    background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 50%, transparent 100%)',
                    transition: 'all 0.6s ease-in-out',
                  },
                  '&:hover': {
                    boxShadow: '0 8px 25px rgba(58, 114, 248, 0.4)',
                    transform: 'translateY(-2px)',
                    '&::before': {
                      left: '100%',
                    }
                  },
                  '&:active': {
                    transform: 'translateY(1px)',
                    boxShadow: '0 2px 10px rgba(58, 114, 248, 0.3)',
                  },
                  '&.Mui-disabled': {
                    background: 'linear-gradient(90deg, rgba(58, 114, 248, 0.5) 0%, rgba(45, 212, 191, 0.5) 100%)',
                  }
                }}
              >
                {isLoading ? (
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <CircularProgress 
                      size={24} 
                      thickness={4} 
                      sx={{ 
                        color: 'white',
                        mr: 1,
                        animationDuration: '0.5s'
                      }} 
                    />
                    <Typography>Authenticating...</Typography>
                  </Box>
                ) : 'Sign In'}
              </Button>
              
              <Box sx={{ mt: 3, textAlign: 'center' }}>
                <Typography variant="caption" sx={{ color: 'rgba(255, 255, 255, 0.5)' }}>
                  Keppel AIDE — AI-Powered Deal Evaluation
                </Typography>
              </Box>
            </Box>
          </Paper>
        </Fade>

        {/* Footer with AI status effect */}
        <Fade in={true} timeout={2000}>
          <Box sx={{ mt: 3, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Box 
              sx={{ 
                width: 10, 
                height: 10, 
                borderRadius: '50%', 
                backgroundColor: '#10B981',
                boxShadow: '0 0 10px #10B981',
                animation: 'pulse 2s infinite',
                mr: 1.5
              }}
            />
            <Typography variant="body2" sx={{ color: 'rgba(255, 255, 255, 0.7)' }}>
              AI System Active • Secure Connection
            </Typography>
            <style jsx="true">{`
              @keyframes pulse {
                0% {
                  box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7);
                }
                70% {
                  box-shadow: 0 0 0 10px rgba(16, 185, 129, 0);
                }
                100% {
                  box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
                }
              }
            `}</style>
          </Box>
        </Fade>
      </Box>
    </Container>
  );
};

export default LoginPage;