// src/components/layout/MainLayout.js
import React from 'react';
import { Outlet } from 'react-router-dom';
import { Box, CssBaseline } from '@mui/material';
import Sidebar from './Sidebar';
import { useTheme } from '@mui/material/styles';

const MainLayout = () => {
  const theme = useTheme();
  
  return (
    <Box sx={{ 
      display: 'flex', 
      backgroundColor: theme.palette.background.default,
      color: theme.palette.text.primary,
      minHeight: '100vh',
      width: '100%'
    }}>
      <CssBaseline />
      <Sidebar />
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: { xs: 2, md: 3 },
          // Remove top margin since we removed the header
          mt: 0,
          ml: 0,
          backgroundColor: theme.palette.background.default,
          color: theme.palette.text.primary,
        }}
      >
        <Outlet />
      </Box>
    </Box>
  );
};

export default MainLayout;