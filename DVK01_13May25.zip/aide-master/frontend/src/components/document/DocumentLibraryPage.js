// frontend/src/components/document/DocumentLibraryPage.js

import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { fetchDocuments, uploadDocument, deleteDocument } from '../../store/documentSlice';
import { 
  Box, 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  Button, 
  IconButton, 
  Chip,
  TextField,
  InputAdornment,
  Menu,
  MenuItem,
  Fade,
  Alert,
  Snackbar,
  CircularProgress,
  LinearProgress,
  Skeleton,
  Paper,
  useTheme,
  Tooltip,
  Badge,
  Divider,
  Grow,
  Avatar,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Container,
  alpha
} from '@mui/material';

// Icons
import SearchIcon from '@mui/icons-material/Search';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import FilterListIcon from '@mui/icons-material/FilterList';
import SortIcon from '@mui/icons-material/Sort';
import VisibilityIcon from '@mui/icons-material/Visibility';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PendingIcon from '@mui/icons-material/Pending';
import ArticleIcon from '@mui/icons-material/Article';
import DescriptionIcon from '@mui/icons-material/Description';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ClearIcon from '@mui/icons-material/Clear';
import AddIcon from '@mui/icons-material/Add';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import NewReleasesIcon from '@mui/icons-material/NewReleases';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import AssignmentTurnedInIcon from '@mui/icons-material/AssignmentTurnedIn';
import MemoryIcon from '@mui/icons-material/Memory';
import DataObjectIcon from '@mui/icons-material/DataObject';
import PublicIcon from '@mui/icons-material/Public';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import MarkEmailReadIcon from '@mui/icons-material/MarkEmailRead';
import DashboardIcon from '@mui/icons-material/Dashboard';
import TuneIcon from '@mui/icons-material/Tune';
import AirplayIcon from '@mui/icons-material/Airplay';
import BorderStyleIcon from  '@mui/icons-material/BorderStyle';

import DocumentViewer from './DocumentViewer';
import CompletionProgress from '../common/CompletionProgress';
import { documentApi, extractionApi } from '../../services/apiService';
import { DOCUMENT_TYPES, PROCESSING, UI, DOC_STATUS, estimateTokensFromFileSize } from '../../config/documentConfig';
import modelConfig from '../../config/modelConfig';

// Document card component
const DocumentCard = ({ document, onView, onDelete, onSendToDealEvaluation, onDownload, theme }) => {
  const navigate = useNavigate();
  const [actionsMenuAnchorEl, setActionsMenuAnchorEl] = useState(null);
  const [hoverState, setHoverState] = useState(false);
  
  // Extract document metadata with proper fallbacks
  const extractedMetadata = document.metadata?.extracted_metadata;
  const docType = extractedMetadata?.document_type || '';
  
  // Get proper color and icon based on document type
  const typeConfig = DOCUMENT_TYPES[docType] || {
    color: '#6B7280',
    icon: <InsertDriveFileIcon fontSize="small" />,
    description: 'Document'
  };
  
  // Process status with visual indicators
  const isProcessed = Boolean(extractedMetadata || document.metadata?.extraction_complete);
  
  // Format upload date with robust error handling
  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      // Check if date is valid
      if (isNaN(date.getTime())) return 'Recently uploaded';
      
      return date.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (e) {
      return 'Recently uploaded';
    }
  };
  
  // Ensure we have proper file size
  const fileSize = document.length 
    ? `${(document.length / 1024 / 1024).toFixed(2)} MB` 
    : '';
  
  // Extract metadata fields with fallbacks
  const keyTopics = extractedMetadata?.key_topics || [];
  const industries = extractedMetadata?.industries || [];
  const regions = extractedMetadata?.regions || [];
  const allTags = [...industries, ...regions].filter(Boolean);
  
  // Generate dynamic card style based on document type
  const cardStyle = docType && DOCUMENT_TYPES[docType] ? {
    accentColor: typeConfig.color,
    bgGradient: `linear-gradient(145deg, ${alpha(typeConfig.color, 0.07)} 0%, rgba(0,0,0,0) 100%)`,
    glowColor: typeConfig.color,
    borderAccent: `1px solid ${alpha(typeConfig.color, 0.2)}`
  } : {
    accentColor: theme.palette.primary.main,
    bgGradient: 'linear-gradient(145deg, rgba(58,114,248,0.05) 0%, rgba(0,0,0,0) 100%)',
    glowColor: theme.palette.primary.main,
    borderAccent: `1px solid ${alpha(theme.palette.primary.main, 0.15)}`
  };
  
  const handleActionMenuOpen = (event) => {
    event.stopPropagation();
    setActionsMenuAnchorEl(event.currentTarget);
  };

  const handleActionMenuClose = () => {
    setActionsMenuAnchorEl(null);
  };
  
  return (
    <Grow in={true} timeout={300}>
      <Card 
        onMouseEnter={() => setHoverState(true)}
        onMouseLeave={() => setHoverState(false)}
        sx={{ 
          borderRadius: 3, 
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          transition: 'all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1)',
          border: cardStyle.borderAccent,
          position: 'relative',
          overflow: 'hidden',
          bgcolor: 'rgba(9, 14, 26, 0.65)',
          background: cardStyle.bgGradient,
          backdropFilter: 'blur(10px)',
          boxShadow: hoverState 
            ? `0 12px 28px -5px ${alpha(cardStyle.accentColor, 0.2)}, 0 0 10px ${alpha(cardStyle.accentColor, 0.1)}` 
            : '0 4px 20px rgba(0,0,0,0.15)',
          transform: hoverState ? 'translateY(-4px) scale(1.01)' : 'translateY(0) scale(1)',
          '&:hover': {
            '& .doc-actions': {
              opacity: 1
            },
            '& .card-accent': {
              height: '5px'
            },
            '& .card-shine': {
              opacity: 0.07,
              transform: 'translateY(-20%) rotate(5deg)'
            }
          }
        }}
      >
        {/* Shine effect overlay - animated on hover */}
        <Box 
          className="card-shine"
          sx={{ 
            position: 'absolute',
            top: 0,
            left: -200,
            right: 0,
            height: '300%',
            width: '200%',
            background: `linear-gradient(90deg, transparent 0%, ${alpha(cardStyle.accentColor, 0.15)} 25%, ${alpha('#ffffff', 0.2)} 50%, ${alpha(cardStyle.accentColor, 0.15)} 75%, transparent 100%)`,
            opacity: 0,
            transform: 'translateY(-100%) rotate(5deg)',
            transition: 'all 0.7s cubic-bezier(0.25, 0.8, 0.25, 1)',
            zIndex: 1,
            pointerEvents: 'none'
          }}
        />
        
        {/* Ambient glow effect at corners */}
        <Box 
          sx={{ 
            position: 'absolute',
            top: -50,
            right: -50,
            width: 150,
            height: 150,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${alpha(cardStyle.accentColor, 0.15)} 0%, transparent 70%)`,
            opacity: 0.5,
            pointerEvents: 'none'
          }}
        />
        
        {/* Document Type Indicator Bar - with dynamic color */}
        <Box 
          className="card-accent"
          sx={{ 
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '4px',
            background: docType 
              ? `linear-gradient(to right, ${cardStyle.accentColor}, ${alpha(cardStyle.accentColor, 0.7)})`
              : 'linear-gradient(90deg, #3A72F8 0%, #2DD4BF 100%)',
            opacity: 0.95,
            zIndex: 2,
            transition: 'height 0.2s ease'
          }}
        />
        
        {/* Status Indicator - with animation */}
        <Box 
          sx={{ 
            position: 'absolute', 
            top: 12, 
            right: 12, 
            zIndex: 2,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 30,
            height: 30,
            borderRadius: '50%',
            backgroundColor: isProcessed 
              ? alpha(UI.COLORS.success, 0.1)
              : alpha(UI.COLORS.info, 0.1),
            border: `1px solid ${isProcessed 
              ? alpha(UI.COLORS.success, 0.3)
              : alpha(UI.COLORS.info, 0.3)}`,
            boxShadow: `0 0 10px ${alpha(isProcessed ? UI.COLORS.success : UI.COLORS.info, 0.2)}`,
            transition: 'all 0.2s ease',
          }}
        >
          {isProcessed ? (
            <CheckCircleIcon sx={{ fontSize: 16, color: UI.COLORS.success }} />
          ) : (
            <CircularProgress size={14} sx={{ 
              color: theme.palette.primary.main,
              animation: 'ripple 1.2s infinite ease-in-out',
              '@keyframes ripple': {
                '0%': {
                  boxShadow: `0 0 0 0 ${alpha(theme.palette.primary.main, 0.3)}`
                },
                '70%': {
                  boxShadow: `0 0 0 6px ${alpha(theme.palette.primary.main, 0)}`
                },
                '100%': {
                  boxShadow: `0 0 0 0 ${alpha(theme.palette.primary.main, 0)}`
                }
              }
            }} />
          )}
        </Box>
        
        {/* Document Icon & Type Indicator - with dynamic styling */}
        <Box 
          sx={{
            px: 2.5,
            pt: 2.5,
            pb: 1.5,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-start',
            position: 'relative',
          }}
        >
          <Avatar 
            sx={{ 
              bgcolor: alpha(cardStyle.accentColor, 0.15),
              color: cardStyle.accentColor,
              mr: 1.5,
              width: 40,
              height: 40,
              border: `1px solid ${alpha(cardStyle.accentColor, 0.2)}`,
              boxShadow: `0 2px 8px ${alpha(cardStyle.accentColor, 0.15)}`,
              transition: 'all 0.2s ease'
            }}
          >
            {typeConfig.icon}
          </Avatar>
          
          <Box>
            <Chip 
              label={docType || 'Document'}
              size="small"
              sx={{ 
                bgcolor: alpha(cardStyle.accentColor, 0.15),
                color: cardStyle.accentColor,
                fontWeight: 600,
                fontSize: '0.7rem',
                mb: 0.5,
                height: 22,
                border: `1px solid ${alpha(cardStyle.accentColor, 0.2)}`,
                boxShadow: `0 2px 4px ${alpha(cardStyle.accentColor, 0.1)}`,
              }}
            />
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', fontSize: '0.7rem' }}>
              {docType ? typeConfig.description : 'Awaiting classification'}
            </Typography>
          </Box>
        </Box>
        
        <CardContent sx={{ flexGrow: 1, px: 2.5, pt: 0, pb: 1.5 }}>
          <Typography 
            variant="subtitle1" 
            component="div" 
            sx={{ 
              fontWeight: 600,
              mb: 0.5,
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              display: '-webkit-box',
              WebkitLineClamp: 2,
              WebkitBoxOrient: 'vertical',
              height: '2.4em',
              fontSize: '0.95rem',
              lineHeight: 1.3
            }}
          >
            {document.filename}
          </Typography>
          
          <Typography 
            variant="caption" 
            color="text.secondary"
            sx={{ 
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              mb: 1.5,
              fontSize: '0.7rem'
            }}
          >
            <span>Uploaded: {formatDate(document.upload_date)}</span>
            {fileSize && (
              <>
                <Box sx={{ width: 3, height: 3, borderRadius: '50%', bgcolor: 'text.disabled' }} />
                <span>{fileSize}</span>
              </>
            )}
          </Typography>
          
          {/* Key topics section with enhanced styling */}
          <Box sx={{ mb: 1, minHeight: 22 }}>
            {keyTopics.length > 0 ? (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {keyTopics.slice(0, 3).map((topic, i) => (
                  <Chip
                    key={`topic-${i}`}
                    label={topic}
                    size="small"
                    variant="outlined"
                    sx={{ 
                      height: 20, 
                      fontSize: '0.65rem',
                      '& .MuiChip-label': { px: 0.8 },
                      borderColor: alpha(theme.palette.primary.main, 0.3),
                      color: alpha(theme.palette.primary.light, 0.9)
                    }}
                  />
                ))}
              </Box>
            ) : isProcessed ? (
              <Box sx={{ 
                display: 'flex', 
                alignItems: 'center', 
                height: 22,
                px: 1,
                py: 0.5,
                borderRadius: 1,
                bgcolor: alpha(theme.palette.divider, 0.05),
                border: `1px dashed ${alpha(theme.palette.divider, 0.2)}`,
                width: 'fit-content'
              }}>
                <Typography variant="caption" sx={{ 
                  fontSize: '0.65rem', 
                  color: alpha(theme.palette.text.secondary, 0.7),
                  fontStyle: 'italic'
                }}>
                  No key topics identified
                </Typography>
              </Box>
            ) : null}
          </Box>
          
          {/* Industry/Region Tags with enhanced styling */}
          <Box sx={{ minHeight: 24, mt: 'auto' }}>
            {allTags.length > 0 && (
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                {allTags.slice(0, 3).map((tag, i) => (
                  <Chip
                    key={`tag-${i}`}
                    label={tag}
                    size="small"
                    sx={{ 
                      height: 22, 
                      fontSize: '0.7rem',
                      bgcolor: alpha(cardStyle.accentColor, 0.1),
                      color: cardStyle.accentColor,
                      border: `1px solid ${alpha(cardStyle.accentColor, 0.2)}`,
                      '& .MuiChip-label': { px: 1 }
                    }}
                  />
                ))}
              </Box>
            )}
          </Box>
        </CardContent>
        
        <Divider sx={{ opacity: 0.1 }} />
        
        <CardActions sx={{ px: 1, py: 0.5 }}>
          <Box 
            className="doc-actions"
            sx={{ 
              display: 'flex', 
              width: '100%',
              justifyContent: 'space-between',
              opacity: 0.9,
              transition: 'opacity 0.2s ease-in-out'
            }}
          >
            <Button
              size="small"
              startIcon={<VisibilityIcon fontSize="small" />}
              onClick={() => onView(document)}
              sx={{ 
                textTransform: 'none',
                fontSize: '0.75rem',
                minWidth: 'auto',
                borderRadius: 1.5,
                color: theme.palette.text.primary,
                '&:hover': {
                  bgcolor: alpha(theme.palette.primary.main, 0.1)
                }
              }}
            >
              View
            </Button>
            
            <Box sx={{ display: 'flex' }}>
              <Tooltip title="More actions">
                <IconButton
                  size="small"
                  onClick={handleActionMenuOpen}
                  sx={{ 
                    mr: 0.5,
                    color: theme.palette.text.primary,
                    '&:hover': {
                      bgcolor: alpha(theme.palette.primary.main, 0.1)
                    }
                  }}
                >
                  <MoreVertIcon fontSize="small" />
                </IconButton>
              </Tooltip>
              
              <Menu
                anchorEl={actionsMenuAnchorEl}
                open={Boolean(actionsMenuAnchorEl)}
                onClose={handleActionMenuClose}
                anchorOrigin={{
                  vertical: 'bottom',
                  horizontal: 'right',
                }}
                transformOrigin={{
                  vertical: 'top',
                  horizontal: 'right',
                }}
                PaperProps={{
                  sx: {
                    width: 200,
                    borderRadius: 2,
                    mt: 1,
                    boxShadow: '0 8px 24px rgba(0,0,0,0.25)',
                    border: `1px solid ${alpha(theme.palette.divider, 0.1)}`
                  }
                }}
              >
                <MenuItem 
                  onClick={() => {
                    onDownload(document);
                    handleActionMenuClose();
                  }}
                  sx={{ py: 1.5 }}
                >
                  <ListItemIcon>
                    <FileDownloadIcon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText primary="Download" />
                </MenuItem>
                <MenuItem 
                  onClick={() => {
                    onDelete(document);
                    handleActionMenuClose();
                  }}
                  sx={{ py: 1.5, color: theme.palette.error.main }}
                >
                  <ListItemIcon>
                    <DeleteOutlineIcon fontSize="small" sx={{ color: theme.palette.error.main }} />
                  </ListItemIcon>
                  <ListItemText primary="Delete" />
                </MenuItem>
              </Menu>
              
              <Button 
                size="small"
                variant="contained"
                disableElevation
                startIcon={isProcessed ? <OpenInNewIcon fontSize="small" /> : <AutoAwesomeIcon fontSize="small" />}
                onClick={() => onSendToDealEvaluation(document)}
                disabled={!isProcessed}
                sx={{ 
                  textTransform: 'none',
                  fontSize: '0.75rem',
                  background: isProcessed
                    ? `linear-gradient(90deg, ${alpha(cardStyle.accentColor, 0.9)} 0%, ${cardStyle.accentColor} 100%)`
                    : alpha(theme.palette.primary.main, 0.1),
                  color: isProcessed
                    ? 'white'
                    : alpha(theme.palette.primary.main, 0.7),
                  px: 1.5,
                  borderRadius: 1.5,
                  border: isProcessed 
                    ? 'none' 
                    : `1px solid ${alpha(theme.palette.primary.main, 0.3)}`,
                  boxShadow: isProcessed 
                    ? `0 4px 8px ${alpha(cardStyle.accentColor, 0.3)}` 
                    : 'none',
                  '&:hover': {
                    background: isProcessed
                      ? `linear-gradient(90deg, ${alpha(cardStyle.accentColor, 1)} 0%, ${alpha(cardStyle.accentColor, 0.8)} 100%)`
                      : alpha(theme.palette.primary.main, 0.2),
                    boxShadow: isProcessed 
                      ? `0 6px 12px ${alpha(cardStyle.accentColor, 0.4)}` 
                      : 'none',
                  }
                }}
              >
                {isProcessed ? 'Analyze' : 'Processing...'}
              </Button>
            </Box>
          </Box>
        </CardActions>
      </Card>
    </Grow>
  );
};

// Delete confirmation dialog
const DeleteConfirmationDialog = ({ open, onClose, onConfirm, document }) => {
  const theme = useTheme();
  
  return (
    <Dialog 
      open={open} 
      onClose={onClose}
      maxWidth="xs"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 3 }
      }}
    >
      <DialogTitle sx={{ pt: 3 }}>
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          Delete Document
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <NewReleasesIcon color="error" sx={{ mr: 1.5, fontSize: 24 }} />
          <Typography variant="body1">
            Are you sure you want to delete <strong>{document?.filename}</strong>?
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary">
          This action cannot be undone. The document and all its analysis data will be permanently removed.
        </Typography>
      </DialogContent>
      <DialogActions sx={{ pb: 3, px: 3 }}>
        <Button 
          onClick={onClose} 
          variant="outlined"
          sx={{ borderRadius: 2 }}
        >
          Cancel
        </Button>
        <Button 
          onClick={onConfirm} 
          variant="contained" 
          color="error"
          sx={{ borderRadius: 2, ml: 2 }}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

// Enhanced Progress Tracking Dialog
const ProcessingDetailsDialog = ({ open, onClose, processLogs, onForceRefresh }) => {
  const theme = useTheme();
  
  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: { borderRadius: 3 }
      }}
    >
      <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', pt: 3 }}>
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          AI Processing Details
        </Typography>
        <Chip 
          size="small" 
          icon={<AutoAwesomeIcon sx={{ fontSize: '0.75rem !important' }} />}
          label="Real-time AI logs" 
          sx={{ 
            bgcolor: theme.palette.primary.main + '10',
            color: theme.palette.primary.main,
            '& .MuiChip-icon': { color: theme.palette.primary.main }
          }}
        />
      </DialogTitle>
      <DialogContent sx={{ pb: 3 }}>
        <List sx={{ 
          maxHeight: 400, 
          overflowY: 'auto',
          border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
          borderRadius: 2,
          bgcolor: alpha(theme.palette.background.paper, 0.2)
        }}>
          {processLogs.length > 0 ? (
            processLogs.map((log, index) => (
              <Fade key={index} in={true} timeout={300 + (index * 100)}>
                <ListItem 
                  sx={{ 
                    py: 1,
                    px: 2,
                    borderBottom: index < processLogs.length - 1 ? `1px solid ${alpha(theme.palette.divider, 0.2)}` : 'none',
                    transition: 'all 0.2s ease',
                    '&:hover': {
                      bgcolor: alpha(theme.palette.background.paper, 0.2)
                    }
                  }}
                >
                  <ListItemIcon sx={{ minWidth: 36 }}>
                    {log.type === 'info' && (
                      <InfoOutlinedIcon fontSize="small" sx={{ color: theme.palette.info.main }} />
                    )}
                    {log.type === 'model' && (
                      <MemoryIcon fontSize="small" sx={{ color: theme.palette.primary.main }} />
                    )}
                    {log.type === 'extract' && (
                      <DataObjectIcon fontSize="small" sx={{ color: theme.palette.warning.main }} />
                    )}
                    {log.type === 'ground' && (
                      <PublicIcon fontSize="small" sx={{ color: theme.palette.secondary.main }} />
                    )}
                    {log.type === 'error' && (
                      <ErrorOutlineIcon fontSize="small" sx={{ color: theme.palette.error.main }} />
                    )}
                    {log.type === 'success' && (
                      <CheckCircleIcon fontSize="small" sx={{ color: theme.palette.success.main }} />
                    )}
                  </ListItemIcon>
                  <ListItemText 
                    primary={log.message} 
                    secondary={log.timestamp}
                    primaryTypographyProps={{ 
                      variant: 'body2', 
                      sx: { fontWeight: 500, wordBreak: 'break-word' } 
                    }}
                    secondaryTypographyProps={{ 
                      variant: 'caption', 
                      sx: { fontSize: '0.65rem', color: 'text.secondary' } 
                    }}
                  />
                </ListItem>
              </Fade>
            ))
          ) : (
            <ListItem>
              <ListItemText 
                primary="Waiting for processing logs..." 
                primaryTypographyProps={{ variant: 'body2', color: 'text.secondary', sx: { textAlign: 'center' } }}
              />
            </ListItem>
          )}
        </List>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button 
          onClick={onForceRefresh} 
          variant="outlined" 
          color="primary"
          sx={{ borderRadius: 2, mr: 'auto' }}
        >
          Refresh Documents
        </Button>
        <Button onClick={onClose} variant="outlined" sx={{ borderRadius: 2 }}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const DocumentLibraryPage = () => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const containerRef = useRef(null);
  const { documents, isLoading } = useSelector((state) => state.documents);
  
  // State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDocumentType, setSelectedDocumentType] = useState('all');
  const [sortOption, setSortOption] = useState('date_desc');
  const [filterAnchorEl, setFilterAnchorEl] = useState(null);
  const [sortAnchorEl, setSortAnchorEl] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'info' });
  const [uploadError, setUploadError] = useState(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [documentToDelete, setDocumentToDelete] = useState(null);
  const [uploadedDocumentId, setUploadedDocumentId] = useState(null);
  const [processLogs, setProcessLogs] = useState([]);
  const [processingDetailsOpen, setProcessingDetailsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState("Preparing upload...");
  
  // Document type filters based on the types defined in DOCUMENT_TYPES
  const documentTypes = [
    { value: 'all', label: 'All Types' },
    ...Object.entries(DOCUMENT_TYPES).map(([type, config]) => ({
      value: type,
      label: type,
      color: config.color
    })).filter((item, index, self) => 
      index === self.findIndex((t) => t.value === item.value)
    ) // Remove duplicates
  ];
  
  // Sort options
  const sortOptions = [
    { value: 'date_desc', label: 'Newest First' },
    { value: 'date_asc', label: 'Oldest First' },
    { value: 'name_asc', label: 'Name (A to Z)' },
    { value: 'name_desc', label: 'Name (Z to A)' },
    { value: 'type', label: 'Document Type' }
  ];
  
  useEffect(() => {
    loadDocuments();
    
    // Set up drag and drop for the entire container
    const container = containerRef.current;
    if (container) {
      container.addEventListener('dragenter', handleDragIn);
      container.addEventListener('dragleave', handleDragOut);
      container.addEventListener('dragover', handleDrag);
      container.addEventListener('drop', handleDrop);
    }
    
    return () => {
      // Clean up event listeners
      if (container) {
        container.removeEventListener('dragenter', handleDragIn);
        container.removeEventListener('dragleave', handleDragOut);
        container.removeEventListener('dragover', handleDrag);
        container.removeEventListener('drop', handleDrop);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  
  // Poll for extraction status if we have an uploaded document ID
  useEffect(() => {
    let intervalId;
    let pollCount = 0;
    const MAX_POLLS = PROCESSING.MAX_POLLS; // Using constant from config
    
    if (uploadedDocumentId && isUploading) {
      // Add first log entry
      addProcessLog('info', 'Document upload complete, starting AI processing');
      
      // Set up polling for extraction status
      intervalId = setInterval(async () => {
        try {
          pollCount++;
          
          // Log polling attempt if taking a long time
          if (pollCount > 10 && pollCount % 5 === 0) {
            addProcessLog('info', `Still waiting for processing to complete (attempt ${pollCount})...`);
          }
          
          // Force completion after MAX_POLLS
          if (pollCount >= MAX_POLLS) {
            addProcessLog('info', 'Processing timeout reached, assuming completion');
            setCurrentStep("Processing complete (timeout)");
            setUploadProgress(100);
            clearInterval(intervalId);
            setTimeout(() => {
              setIsUploading(false);
              dispatch(fetchDocuments());
            }, 1000);
            return;
          }
          
          const response = await extractionApi.getDocumentMetadata(uploadedDocumentId);
          
          // FIX: Correctly access the metadata from the response structure
          // The API returns: { status, data: { document_id, metadata }, ... }
          const extractedMetadata = response.data?.data?.metadata;
          
          // Check if extraction is complete - metadata should exist in successful extraction
          if (extractedMetadata) {
            addProcessLog('success', 'AI processing complete');
            setCurrentStep("Processing complete");
            setUploadProgress(100);
            clearInterval(intervalId);
            setTimeout(() => {
              setIsUploading(false);
              dispatch(fetchDocuments());
            }, 1000);
            return;
          }
          
          // Get document directly to check process status as alternative
          try {
            const docResponse = await documentApi.getDocument(uploadedDocumentId);
            const docData = docResponse.data?.data;
            
            if (docData?.metadata?.extracted_metadata || 
                docData?.metadata?.extraction_complete) {
              addProcessLog('success', 'Document processing detected as complete');
              setCurrentStep("Processing complete");
              setUploadProgress(100);
              clearInterval(intervalId);
              setTimeout(() => {
                setIsUploading(false);
                dispatch(fetchDocuments());
              }, 1000);
              return;
            }
            
            // Check for process status in document metadata
            const status = docData?.metadata?.extraction_status;
            if (status) {
              if (status.current_step && status.current_step !== currentStep) {
                setCurrentStep(status.current_step);
                
                // Add log for the step
                let logType = 'info';
                if (status.current_step.includes('model')) logType = 'model';
                if (status.current_step.includes('extract')) logType = 'extract';
                if (status.current_step.includes('ground')) logType = 'ground';
                addProcessLog(logType, status.current_step);
              }
              
              if (status.percentage) {
                setUploadProgress(status.percentage);
              }
            }
          } catch (docError) {
            console.warn("Error checking document status:", docError);
          }
          
        } catch (error) {
          console.error("Error checking extraction status:", error);
          addProcessLog('error', `Error checking status: ${error.message || 'Unknown error'}`);
          
          // After several retries with errors, assume completion to avoid UI being stuck
          if (pollCount > 5) {
            addProcessLog('warning', 'Continuing despite errors in status check');
            setCurrentStep("Processing complete (assumed)");
            setUploadProgress(100);
            clearInterval(intervalId);
            setTimeout(() => {
              setIsUploading(false);
              dispatch(fetchDocuments());
            }, 1000);
          }
        }
      }, PROCESSING.POLL_INTERVAL);
    }
    
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [uploadedDocumentId, isUploading, dispatch, currentStep]);
  
  const addProcessLog = (type, message) => {
    setProcessLogs(prev => [
      ...prev,
      {
        type,
        message,
        timestamp: new Date().toLocaleTimeString()
      }
    ]);
  };
  
  const loadDocuments = async () => {
    dispatch(fetchDocuments());
  };
  
  // Filter and sort documents
  const filteredAndSortedDocuments = () => {
    // First, filter documents
    let filtered = [...documents]; 
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(doc => 
        doc.filename.toLowerCase().includes(query) || 
        doc.metadata?.extracted_metadata?.document_type?.toLowerCase().includes(query) ||
        doc.metadata?.extracted_metadata?.title?.toLowerCase().includes(query) ||
        (doc.metadata?.extracted_metadata?.key_topics || []).some(topic => 
          topic.toLowerCase().includes(query)
        )
      );
    }
    
    if (selectedDocumentType !== 'all') {
      filtered = filtered.filter(doc => 
        doc.metadata?.extracted_metadata?.document_type === selectedDocumentType
      );
    }
    
    // Then, sort documents
    return [...filtered].sort((a, b) => { 
      switch (sortOption) {
        case 'date_asc':
          return new Date(a.upload_date) - new Date(b.upload_date);
        case 'date_desc':
          return new Date(b.upload_date) - new Date(a.upload_date);
        case 'name_asc':
          return a.filename.localeCompare(b.filename);
        case 'name_desc':
          return b.filename.localeCompare(a.filename);
        case 'type':
          const typeA = a.metadata?.extracted_metadata?.document_type || '';
          const typeB = b.metadata?.extracted_metadata?.document_type || '';
          return typeA.localeCompare(typeB);
        default:
          return new Date(b.upload_date) - new Date(a.upload_date);
      }
    });
  };
    
  // Handlers for filter menu
  const handleFilterMenuOpen = (event) => {
    setFilterAnchorEl(event.currentTarget);
  };
  
  const handleFilterMenuClose = () => {
    setFilterAnchorEl(null);
  };
  
  // Handlers for sort menu
  const handleSortMenuOpen = (event) => {
    setSortAnchorEl(event.currentTarget);
  };
  
  const handleSortMenuClose = () => {
    setSortAnchorEl(null);
  };
  
  // File upload handlers
  const handleFileChange = (event) => {
    const files = event.target.files;
    
    if (files && files.length > 0) {
      handleUpload(files[0]);
    }
  };
  
  const handleUpload = async (file) => {
    // Reset process logs
    setProcessLogs([]);
    
    // Check if file is a PDF
    if (!file.type.includes('pdf')) {
      setSnackbar({
        open: true,
        message: 'Only PDF files are supported',
        severity: 'error'
      });
      return;
    }
    
    setIsUploading(true);
    setUploadProgress(0);
    setUploadError(null);
    setCurrentStep("Preparing to upload...");
    addProcessLog('info', `Uploading ${file.name} (${(file.size/1024/1024).toFixed(2)} MB)`);
    
    // Estimate tokens for this file
    const estimatedTokens = estimateTokensFromFileSize(file.size);
    addProcessLog('model', `Estimated token count: ${estimatedTokens.toLocaleString()}`);
    
    // Get the model that will be used for processing
    const extractModel = modelConfig.find(m => m.type === 'text_extract');
    
    // Check if file might exceed context window
    if (estimatedTokens > extractModel.contextWindow) {
      addProcessLog('warning', `File may exceed ${extractModel.displayName} context window (${extractModel.contextWindow.toLocaleString()} tokens)`);
    }
    
    try {
      // Show upload phases
      setCurrentStep("Uploading document...");
      addProcessLog('info', 'Sending file to server');
      
      // Upload progress simulation - just for visual feedback during actual upload
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += 5;
        if (progress >= 50) {
          clearInterval(progressInterval);
        } else {
          setUploadProgress(progress);
        }
      }, 200);
      
      const resultAction = await dispatch(uploadDocument(file));
      
      clearInterval(progressInterval);
      
      if (uploadDocument.fulfilled.match(resultAction)) {
        setUploadProgress(60);
        
        // Get document ID from result
        const documentId = resultAction.payload?.data?.document_id;
        
        if (documentId) {
          setUploadedDocumentId(documentId);
          addProcessLog('info', `Document ID: ${documentId}`);
          setCurrentStep("Starting AI extraction...");
          
          // Automatically open processing details
          setProcessingDetailsOpen(true);
          
          setSnackbar({
            open: true,
            message: 'Document uploaded successfully! AI processing started...',
            severity: 'success'
          });
        } else {
          throw new Error('Document ID not found in response');
        }
      } else {
        const errorDetails = resultAction.payload || resultAction.error?.message || 'Upload failed';
        setUploadError(errorDetails);
        addProcessLog('error', `Upload failed: ${errorDetails}`);
        setSnackbar({
          open: true,
          message: typeof errorDetails === 'string' ? errorDetails : JSON.stringify(errorDetails),
          severity: 'error'
        });
        setIsUploading(false);
      }
    } catch (err) {
      const errorMessage = err.message || 'Upload failed';
      setUploadError(errorMessage);
      addProcessLog('error', `Error: ${errorMessage}`);
      setSnackbar({
        open: true,
        message: errorMessage,
        severity: 'error'
      });
      setIsUploading(false);
    }
  };
  
  // Drag and drop handlers
  const handleDragIn = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setDragActive(true);
    }
  };
  
  const handleDragOut = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };
  
  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!dragActive) setDragActive(true);
  };
  
  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      // Only take the first file for now - could enhance to handle multiple
      handleUpload(e.dataTransfer.files[0]);
    }
  };
  
  // Document actions
  const handleViewDocument = (document) => {
    setSelectedDocument(document);
    setViewDialogOpen(true);
  };
  
  const handleDeleteDocument = (document) => {
    setDocumentToDelete(document);
    setDeleteDialogOpen(true);
  };
  
  const confirmDeleteDocument = async () => {
    try {
      if (!documentToDelete) return;
      
      const resultAction = await dispatch(deleteDocument(documentToDelete.document_id));
      
      if (deleteDocument.fulfilled.match(resultAction)) {
        setSnackbar({
          open: true,
          message: 'Document deleted successfully',
          severity: 'success'
        });
      } else {
        setSnackbar({
          open: true,
          message: resultAction.payload || 'Delete failed',
          severity: 'error'
        });
      }
    } catch (err) {
      setSnackbar({
        open: true,
        message: err.message || 'Delete failed',
        severity: 'error'
      });
    } finally {
      setDeleteDialogOpen(false);
      setDocumentToDelete(null);
    }
  };
  
  const handleDownloadDocument = async (docItem) => {
    try {
      setSnackbar({
        open: true,
        message: 'Downloading document...',
        severity: 'info'
      });
      
      // Use the API client which includes auth headers
      const response = await documentApi.downloadDocument(docItem.document_id);
      
      // Create a blob URL from the response
      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      
      // Download using the blob URL
      const a = document.createElement('a');
      a.href = url;
      a.download = docItem.filename || 'document.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      // Clean up
      window.URL.revokeObjectURL(url);
      
    } catch (error) {
      console.error("Download failed:", error);
      setSnackbar({
        open: true,
        message: `Download failed: ${error.message}`,
        severity: 'error'
      });
    }
  };
  
  const handleSendToDealEvaluation = (document) => {
    navigate('/assistant', { state: { document } });
  };
  
  // Reset filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedDocumentType('all');
    setSortOption('date_desc');
  };
  
  // Document statistics
  const totalDocuments = documents.length;
  const processedCount = documents.filter(d => 
    d.metadata?.extracted_metadata || d.metadata?.extraction_complete
  ).length;
  
  return (
    <Box ref={containerRef} sx={{ position: 'relative', minHeight: '85vh' }}>
      {/* Drag overlay - only shown when dragging */}
      {dragActive && (
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backdropFilter: 'blur(4px)',
            backgroundColor: alpha(theme.palette.background.paper, 0.7),
            zIndex: 10,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column',
            borderRadius: 3,
            border: `2px dashed ${theme.palette.primary.main}`
          }}
        >
          <Box
            sx={{
              width: 80,
              height: 80,
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: `linear-gradient(135deg, ${alpha(theme.palette.primary.main, 0.1)} 0%, ${alpha(theme.palette.secondary.main, 0.1)} 100%)`,
              mb: 3,
              border: `1px solid ${alpha(theme.palette.primary.main, 0.3)}`
            }}
          >
            <UploadFileIcon sx={{ fontSize: 36, color: theme.palette.primary.main }} />
          </Box>
          <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>
            Drop PDF to Upload
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 400, textAlign: 'center' }}>
            Files will be automatically processed with AI to extract key information
          </Typography>
        </Box>
      )}
    
      {/* Header with Title */}
      <Box 
        sx={{ 
          mb: 4,
          borderRadius: '0 0 24px 24px',
          position: 'relative',
          overflow: 'hidden'
        }}
      >
        <Box sx={{ 
          p: 4, 
          background: `linear-gradient(135deg, ${alpha('#3A72F8', 0.15)} 0%, ${alpha('#2DD4BF', 0.15)} 100%)`,
          borderRadius: '0 0 24px 24px',
          border: `1px solid ${alpha('#ffffff', 0.1)}`,
          backdropFilter: 'blur(5px)'
        }}>
          <Container maxWidth="xl" sx={{ px: { xs: 0, sm: 2 }}}>
            <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, justifyContent: 'space-between', alignItems: { xs: 'flex-start', md: 'center' }, gap: 2 }}>
              <Box>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <BorderStyleIcon sx={{ mr: 1.5, color: theme.palette.primary.main, fontSize: 32 }} />
                  <Typography variant="h4" sx={{ fontWeight: 600 }}>
                    Document Library
                  </Typography>
                </Box>
              </Box>
              
              <Box sx={{ display: 'flex', gap: 2, mt: { xs: 2, md: 0 }, alignItems: 'center' }}>
                <Box sx={{ 
                  display: 'flex', 
                  alignItems: 'center',
                  gap: 1.5,
                  px: 2,
                  py: 1,
                  borderRadius: 2,
                  background: `linear-gradient(135deg, ${alpha(theme.palette.success.main, 0.15)} 0%, ${alpha(theme.palette.success.main, 0.05)} 100%)`,
                  border: `1px solid ${alpha(theme.palette.success.main, 0.15)}`
                }}>
                  <DoneAllIcon sx={{ fontSize: 18, color: theme.palette.success.main }} />
                  <Typography variant="body2" sx={{ fontWeight: 500, whiteSpace: 'nowrap' }}>
                    <Box component="span" sx={{ color: theme.palette.success.main }}>{processedCount}</Box>
                    <Box component="span" sx={{ color: 'text.secondary' }}>/{totalDocuments} Documents Processed</Box>
                  </Typography>
                </Box>
                
                <Button
                  variant="contained"
                  startIcon={<UploadFileIcon />}
                  onClick={() => fileInputRef.current.click()}
                  disabled={isUploading}
                  sx={{ 
                    py: 1.2,
                    px: 3, 
                    borderRadius: 2,
                    background: 'linear-gradient(90deg, #3A72F8 0%, #2DD4BF 100%)',
                    fontWeight: 500,
                    '&:hover': {
                      background: 'linear-gradient(90deg, #2851D8 0%, #00A99D 100%)'
                    }
                  }}
                >
                  {isUploading ? 'Uploading...' : 'Upload Document'}
                </Button>
                <input
                  ref={fileInputRef}
                  id="file-upload-input"
                  type="file"
                  accept="application/pdf,.pdf"
                  onChange={handleFileChange}
                  style={{ display: 'none' }}
                />
              </Box>
            </Box>
          </Container>
        </Box>
      </Box>
      
      <Container maxWidth="xl" sx={{ px: { xs: 2, sm: 4 } }}>
        {/* Upload Progress */}
        {isUploading && (
          <Box sx={{ position: 'relative', mb: 4 }}>
            <CompletionProgress 
              percentage={uploadProgress} 
              currentStep={currentStep}
              isComplete={uploadProgress >= 100}
              error={uploadError}
              onManualClose={() => {
                addProcessLog('info', 'Progress bar manually closed by user');
                setIsUploading(false);
                // Fetch documents to refresh the list
                dispatch(fetchDocuments());
              }}
            />
            
            <Button
              variant="text"
              size="small"
              onClick={() => setProcessingDetailsOpen(true)}
              sx={{ 
                position: 'absolute', 
                right: 8, 
                top: 8,
                fontSize: '0.75rem',
                textTransform: 'none'
              }}
            >
              View Details
            </Button>
          </Box>
        )}
        
        {/* Search and Filter Bar */}
        <Paper
          elevation={0}
          sx={{ 
            p: 2, 
            borderRadius: 3, 
            mb: 4,
            border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
            background: alpha(theme.palette.background.paper, 0.3),
            backdropFilter: 'blur(10px)',
            position: 'relative',
            overflow: 'hidden'
          }}
        >
          <Box sx={{ 
            position: 'absolute', 
            top: 0, 
            left: 0, 
            right: 0, 
            height: '2px',
            background: 'linear-gradient(90deg, #3A72F8 0%, #2DD4BF 100%)',
            opacity: 0.8
          }} />
          
          <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', flex: 1, minWidth: '250px' }}>
              <TextField
                placeholder="Search documents..."
                variant="outlined"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                fullWidth
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon sx={{ color: alpha(theme.palette.text.primary, 0.4) }} />
                    </InputAdornment>
                  ),
                  endAdornment: searchQuery ? (
                    <InputAdornment position="end">
                      <IconButton 
                        size="small" 
                        onClick={() => setSearchQuery('')}
                        edge="end"
                        sx={{ mr: -0.5 }}
                      >
                        <ClearIcon fontSize="small" />
                      </IconButton>
                    </InputAdornment>
                  ) : null,
                }}
                sx={{ 
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 2,
                    bgcolor: alpha(theme.palette.background.default, 0.5),
                    '& fieldset': {
                      borderColor: alpha(theme.palette.divider, 0.2),
                    },
                    '&:hover fieldset': {
                      borderColor: alpha(theme.palette.divider, 0.3),
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: theme.palette.primary.main,
                    },
                  },
                  '& .MuiInputBase-input': {
                    py: 1.25
                  }
                }}
                size="small"
              />
            </Box>
            
            <Button
              variant="outlined"
              startIcon={<FilterListIcon />}
              onClick={handleFilterMenuOpen}
              sx={{ 
                borderRadius: 2,
                textTransform: 'none',
                minWidth: '140px',
                justifyContent: 'space-between',
                px: 2,
                py: 1.2,
                borderColor: alpha(theme.palette.divider, 0.3),
                color: theme.palette.text.primary,
                '&:hover': {
                  borderColor: theme.palette.primary.main,
                  bgcolor: alpha(theme.palette.primary.main, 0.05)
                }
              }}
              endIcon={<ArrowDropDownIcon />}
              size="small"
            >
              {selectedDocumentType === 'all' ? 'All Types' : 
               documentTypes.find(t => t.value === selectedDocumentType)?.label || 'Filter'}
            </Button>
            
            <Menu
              anchorEl={filterAnchorEl}
              open={Boolean(filterAnchorEl)}
              onClose={handleFilterMenuClose}
              TransitionComponent={Fade}
              sx={{ 
                '& .MuiPaper-root': { 
                  width: 200, 
                  maxHeight: 300, 
                  borderRadius: 2,
                  mt: 1,
                  boxShadow: '0 8px 20px rgba(0,0,0,0.15)',
                  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`
                } 
              }}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              {documentTypes.map((type) => (
                <MenuItem 
                  key={type.value} 
                  onClick={() => {
                    setSelectedDocumentType(type.value);
                    handleFilterMenuClose();
                  }}
                  selected={selectedDocumentType === type.value}
                  sx={{ 
                    borderRadius: 1,
                    m: 0.5,
                    py: 1,
                    px: 1.5,
                    '&.Mui-selected': {
                      bgcolor: alpha(theme.palette.primary.main, 0.1),
                    }
                  }}
                >
                  {type.value !== 'all' && (
                    <Box 
                      sx={{ 
                        width: 8, 
                        height: 8, 
                        borderRadius: '50%', 
                        bgcolor: type.color || theme.palette.primary.main,
                        mr: 1.5,
                        flexShrink: 0
                      }} 
                    />
                  )}
                  {type.label}
                </MenuItem>
              ))}
            </Menu>
            
            <Button
              variant="outlined"
              startIcon={<SortIcon />}
              onClick={handleSortMenuOpen}
              sx={{ 
                borderRadius: 2,
                textTransform: 'none',
                minWidth: '140px',
                justifyContent: 'space-between',
                px: 2,
                py: 1.2,
                borderColor: alpha(theme.palette.divider, 0.3),
                color: theme.palette.text.primary,
                '&:hover': {
                  borderColor: theme.palette.primary.main,
                  bgcolor: alpha(theme.palette.primary.main, 0.05)
                }
              }}
              endIcon={<ArrowDropDownIcon />}
              size="small"
            >
              {sortOptions.find(o => o.value === sortOption)?.label || 'Sort'}
            </Button>
            
            <Menu
              anchorEl={sortAnchorEl}
              open={Boolean(sortAnchorEl)}
              onClose={handleSortMenuClose}
              TransitionComponent={Fade}
              sx={{ 
                '& .MuiPaper-root': { 
                  width: 200, 
                  maxHeight: 300, 
                  borderRadius: 2,
                  mt: 1,
                  boxShadow: '0 8px 20px rgba(0,0,0,0.15)',
                  border: `1px solid ${alpha(theme.palette.divider, 0.1)}`
                } 
              }}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              {sortOptions.map((option) => (
                <MenuItem 
                  key={option.value} 
                  onClick={() => {
                    setSortOption(option.value);
                    handleSortMenuClose();
                  }}
                  selected={sortOption === option.value}
                  sx={{ 
                    borderRadius: 1,
                    m: 0.5,
                    py: 1,
                    px: 1.5,
                    '&.Mui-selected': {
                      bgcolor: alpha(theme.palette.primary.main, 0.1),
                    }
                  }}
                >
                  {option.label}
                </MenuItem>
              ))}
            </Menu>
            
            {(searchQuery || selectedDocumentType !== 'all' || sortOption !== 'date_desc') && (
              <Tooltip title="Reset filters">
                <Button
                  size="small"
                  variant="outlined"
                  onClick={handleResetFilters}
                  sx={{
                    minWidth: 'auto',
                    borderRadius: 2,
                    p: 1,
                    ml: 'auto',
                    borderColor: alpha(theme.palette.divider, 0.3)
                  }}
                >
                  <ClearIcon fontSize="small" />
                </Button>
              </Tooltip>
            )}
          </Box>
        </Paper>
        
        {/* Document Grid */}
        <Box sx={{ mb: 6 }}>
          {isLoading ? (
            <Grid container spacing={3}>
              {[1, 2, 3, 4, 5, 6].map((item) => (
                <Grid item xs={12} sm={6} md={4} xl={3} key={item}>
                  <Card sx={{ 
                    borderRadius: 2, 
                    height: '100%', 
                    background: alpha(theme.palette.background.paper, 0.3),
                    border: `1px solid ${alpha(theme.palette.divider, 0.2)}`
                  }}>
                    <Box sx={{ p: 2.5 }}>
                      <Skeleton variant="circular" width={40} height={40} />
                    </Box>
                    <CardContent>
                      <Skeleton variant="text" width="80%" height={32} />
                      <Skeleton variant="text" width="60%" height={24} />
                      <Box sx={{ mt: 1 }}>
                        <Skeleton variant="rectangular" width={80} height={24} sx={{ borderRadius: 1 }} />
                      </Box>
                    </CardContent>
                    <CardActions>
                      <Skeleton variant="text" width="40%" height={36} />
                      <Box sx={{ flexGrow: 1 }} />
                      <Skeleton variant="text" width="30%" height={36} />
                    </CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          ) : filteredAndSortedDocuments().length === 0 ? (
            <Paper 
              sx={{ 
                p: 6, 
                textAlign: 'center', 
                borderRadius: 3,
                background: alpha(theme.palette.background.paper, 0.3),
                backdropFilter: 'blur(10px)',
                border: `1px dashed ${alpha(theme.palette.divider, 0.3)}`
              }}
            >
              <Box sx={{ 
                width: 80,
                height: 80,
                borderRadius: '50%',
                background: `linear-gradient(135deg, ${alpha(theme.palette.background.paper, 0.3)} 0%, ${alpha(theme.palette.background.paper, 0.1)} 100%)`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mx: 'auto',
                mb: 3,
                border: `1px solid ${alpha(theme.palette.divider, 0.2)}`
              }}>
                <ArticleIcon sx={{ fontSize: 40, color: alpha(theme.palette.text.secondary, 0.7) }} />
              </Box>
              <Typography variant="h6" gutterBottom>
                No documents found
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mb: 4, maxWidth: 450, mx: 'auto' }}>
                {searchQuery || selectedDocumentType !== 'all' ? 
                  'Try adjusting your search or filters' : 
                  'Upload documents to get started with AI analysis. Our system will extract key information automatically.'}
              </Typography>
              <Button
                variant="contained"
                startIcon={<UploadFileIcon />}
                onClick={() => fileInputRef.current.click()}
                sx={{ 
                  py: 1.5, 
                  px: 3, 
                  borderRadius: 2,
                  background: 'linear-gradient(90deg, #3A72F8 0%, #2DD4BF 100%)',
                  boxShadow: '0 4px 14px rgba(58, 114, 248, 0.25)',
                  fontWeight: 500
                }}
              >
                Upload Document
              </Button>
            </Paper>
          ) : (
            <Grid container spacing={3}>
              {filteredAndSortedDocuments().map((doc) => (
                <Grid item xs={12} sm={6} md={4} xl={3} key={doc.document_id}>
                  <DocumentCard 
                    document={doc}
                    onView={handleViewDocument}
                    onDelete={handleDeleteDocument}
                    onDownload={handleDownloadDocument}
                    onSendToDealEvaluation={handleSendToDealEvaluation}
                    theme={theme}
                  />
                </Grid>
              ))}
            </Grid>
          )}
        </Box>
      </Container>
      
      {/* Document Viewer Dialog */}
      {selectedDocument && (
        <DocumentViewer
          open={viewDialogOpen}
          onClose={() => setViewDialogOpen(false)}
          document={selectedDocument}
        />
      )}
      
      {/* Delete Confirmation Dialog */}
      <DeleteConfirmationDialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        onConfirm={confirmDeleteDocument}
        document={documentToDelete}
      />
      
      {/* Processing Details Dialog */}
      <ProcessingDetailsDialog
        open={processingDetailsOpen}
        onClose={() => setProcessingDetailsOpen(false)}
        processLogs={processLogs}
        onForceRefresh={() => {
          dispatch(fetchDocuments());
          setIsUploading(false);
          setProcessingDetailsOpen(false);
        }}
      />
      
      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert 
          onClose={() => setSnackbar({ ...snackbar, open: false })} 
          severity={snackbar.severity}
          variant="filled"
          sx={{ 
            width: '100%',
            borderRadius: 2,
            boxShadow: '0 8px 16px rgba(0,0,0,0.2)',
            py: 1
          }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default DocumentLibraryPage;