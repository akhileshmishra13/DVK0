// frontend/src/components/document/DocumentSelector.js

import React, { useState, useEffect } from 'react';
import { 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions,
  Button,
  Typography,
  Box,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Checkbox,
  TextField,
  InputAdornment,
  IconButton,
  Divider,
  Chip,
  CircularProgress,
  useTheme,
  Alert,
  MenuItem,
  Tooltip,
  LinearProgress
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import CloseIcon from '@mui/icons-material/Close';
import ClearIcon from '@mui/icons-material/Clear';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import FilterListIcon from '@mui/icons-material/FilterList';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningIcon from '@mui/icons-material/Warning';
import ErrorIcon from '@mui/icons-material/Error';
import DataObjectIcon from '@mui/icons-material/DataObject';
import { useDispatch, useSelector } from 'react-redux';
import { fetchDocuments } from '../../store/documentSlice';
import { estimateTokensFromFileSize, UI } from '../../config/documentConfig';
import modelConfig from '../../config/modelConfig';

const DocumentSelector = ({ open, onClose, onSelectDocuments, initialSelectedIds = [] }) => {
  const theme = useTheme();
  const dispatch = useDispatch();
  const { documents, isLoading } = useSelector((state) => state.documents);
  
  const [selectedDocIds, setSelectedDocIds] = useState(new Set(initialSelectedIds));
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState('all');
  const [totalTokens, setTotalTokens] = useState(0);
  
  // Get the model context window limits
  const primaryModel = modelConfig.find(m => m.type === 'primary');
  const ultraContextModel = modelConfig.find(m => m.type === 'ultra_context');
  const contextWindowLimit = primaryModel?.contextWindow || 200000;
  const ultraContextWindowLimit = ultraContextModel?.contextWindow || 1000000;
  
  useEffect(() => {
    if (open) {
      dispatch(fetchDocuments());
    }
  }, [open, dispatch]);
  
  useEffect(() => {
    setSelectedDocIds(new Set(initialSelectedIds));
  }, [initialSelectedIds]);
  
  // Update token calculation when selection changes
  useEffect(() => {
    // Calculate total tokens from selected documents
    const tokenCount = documents
      .filter(doc => selectedDocIds.has(doc.document_id || doc.id))
      .reduce((total, doc) => {
        // Use existing token count if available, otherwise estimate
        const docTokens = doc.token_count || estimateTokensFromFileSize(doc.length || 0);
        return total + docTokens;
      }, 0);
      
    setTotalTokens(tokenCount);
  }, [selectedDocIds, documents]);
  
  const handleToggleDocument = (documentId) => {
    const newSelectedIds = new Set(selectedDocIds);
    if (newSelectedIds.has(documentId)) {
      newSelectedIds.delete(documentId);
    } else {
      newSelectedIds.add(documentId);
    }
    setSelectedDocIds(newSelectedIds);
  };
  
  const handleConfirm = () => {
    const selectedDocs = documents.filter(doc => 
      selectedDocIds.has(doc.document_id || doc.id)
    );
    onSelectDocuments(selectedDocs);
    onClose();
  };
  
  const filteredDocuments = () => {
    return documents.filter(doc => {
      // Search filter
      const matchesSearch = searchQuery === '' || 
        doc.filename.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (doc.metadata?.extracted_metadata?.document_type || '').toLowerCase().includes(searchQuery.toLowerCase());
      
      // Document type filter
      const matchesFilter = filter === 'all' || 
        (doc.metadata?.extracted_metadata?.document_type || '').toLowerCase() === filter.toLowerCase();
      
      // Processed filter
      const isProcessed = doc.metadata?.extracted_metadata || doc.metadata?.extraction_complete;
      const matchesProcessed = filter !== 'processed' || isProcessed;
      
      return matchesSearch && matchesFilter && matchesProcessed;
    });
  };
  
  // Get unique document types for filter
  const documentTypes = [
    { value: 'all', label: 'All Documents' },
    { value: 'processed', label: 'Processed Only' },
    ...Array.from(new Set(
      documents
        .filter(doc => doc.metadata?.extracted_metadata?.document_type)
        .map(doc => doc.metadata.extracted_metadata.document_type)
    )).map(type => ({ value: type.toLowerCase(), label: type }))
  ];
  
  // Get token usage percentage for display
  const primaryTokenPercentage = Math.min(100, (totalTokens / contextWindowLimit) * 100);
  const ultraTokenPercentage = Math.min(100, (totalTokens / ultraContextWindowLimit) * 100);
  
  return (
    <Dialog 
      open={open} 
      onClose={onClose}
      maxWidth="md"
      fullWidth
      PaperProps={{
        sx: { 
          borderRadius: 3,
          height: '70vh',
          display: 'flex',
          flexDirection: 'column'
        }
      }}
    >
      <DialogTitle sx={{ 
        px: 3, 
        py: 2, 
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center',
        borderBottom: `1px solid ${theme.palette.divider}`
      }}>
        <Typography variant="h6" sx={{ display: 'flex', alignItems: 'center' }}>
          Select Documents
          <Chip 
            label={`${selectedDocIds.size} selected`}
            size="small"
            color="primary"
            sx={{ ml: 2, height: 20, fontSize: '0.7rem' }}
          />
        </Typography>
        <IconButton size="small" onClick={onClose}>
          <CloseIcon fontSize="small" />
        </IconButton>
      </DialogTitle>
      
      <Box sx={{ px: 3, py: 2, borderBottom: `1px solid ${theme.palette.divider}` }}>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <TextField
            placeholder="Search documents..."
            size="small"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            sx={{ flexGrow: 1 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
              endAdornment: searchQuery ? (
                <InputAdornment position="end">
                  <IconButton size="small" onClick={() => setSearchQuery('')}>
                    <ClearIcon fontSize="small" />
                  </IconButton>
                </InputAdornment>
              ) : null,
              sx: { borderRadius: 2 }
            }}
          />
          
          <TextField
            select
            size="small"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            sx={{ minWidth: 150 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <FilterListIcon fontSize="small" />
                </InputAdornment>
              ),
              sx: { borderRadius: 2 }
            }}
          >
            {documentTypes.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
        </Box>
      </Box>
      
      <DialogContent sx={{ p: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {isLoading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
            <CircularProgress size={40} />
          </Box>
        ) : filteredDocuments().length === 0 ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', p: 3 }}>
            <Alert severity="info" sx={{ width: '100%' }}>
              No documents match your search criteria. Try adjusting your filters.
            </Alert>
          </Box>
        ) : (
          <List sx={{ 
            overflow: 'auto',
            height: '100%',
            '&::-webkit-scrollbar': {
              width: '6px',
            },
            '&::-webkit-scrollbar-thumb': {
              backgroundColor: 'rgba(255, 255, 255, 0.1)',
              borderRadius: '3px',
            }
          }}>
            {filteredDocuments().map((doc) => {
              const docId = doc.document_id || doc.id;
              const isSelected = selectedDocIds.has(docId);
              const isProcessed = doc.metadata?.extracted_metadata || doc.metadata?.extraction_complete;
              
              // Token estimation for this document
              const docTokens = doc.token_count || estimateTokensFromFileSize(doc.length || 0);
              
              return (
                <ListItem 
                  key={docId}
                  sx={{ 
                    py: 1,
                    borderBottom: `1px solid ${theme.palette.divider}`,
                    '&:hover': { bgcolor: 'rgba(255,255,255,0.03)' }
                  }}
                >
                  <ListItemIcon>
                    <Checkbox 
                      edge="start" 
                      checked={isSelected}
                      onChange={() => handleToggleDocument(docId)}
                    />
                  </ListItemIcon>
                  
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                          {doc.filename}
                        </Typography>
                        {isProcessed && (
                          <Tooltip title="Processed">
                            <CheckCircleIcon color="success" sx={{ ml: 1, fontSize: 16 }} />
                          </Tooltip>
                        )}
                      </Box>
                    }
                    secondary={
                      <Box sx={{ display: 'flex', flexDirection: 'column', mt: 0.5 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          {doc.metadata?.extracted_metadata?.document_type && (
                            <Chip
                              size="small"
                              label={doc.metadata.extracted_metadata.document_type}
                              sx={{ 
                                mr: 1, 
                                height: 20, 
                                fontSize: '0.7rem',
                                bgcolor: 'rgba(58, 114, 248, 0.15)',
                                color: theme.palette.primary.light
                              }}
                            />
                          )}
                          <Typography variant="caption" color="text.secondary">
                            {new Date(doc.upload_date).toLocaleDateString()} • {(doc.length / 1024 / 1024).toFixed(2)} MB
                          </Typography>
                          <Chip
                            icon={<DataObjectIcon sx={{ fontSize: '0.7rem !important' }} />}
                            label={`~${docTokens.toLocaleString()} tokens`}
                            size="small"
                            sx={{ 
                              height: 20, 
                              fontSize: '0.65rem',
                              bgcolor: 'rgba(0, 0, 0, 0.2)',
                              '& .MuiChip-icon': { color: theme.palette.info.light }
                            }}
                          />
                        </Box>
                      </Box>
                    }
                  />
                  
                  <Box>
                    <IconButton 
                      size="small" 
                      onClick={() => handleToggleDocument(docId)}
                      color={isSelected ? "primary" : "default"}
                      sx={{ 
                        border: isSelected ? `1px solid ${theme.palette.primary.main}30` : `1px solid ${theme.palette.divider}`,
                        borderRadius: 1.5,
                        p: 1
                      }}
                    >
                      <InsertDriveFileIcon fontSize="small" />
                    </IconButton>
                  </Box>
                </ListItem>
              );
            })}
          </List>
        )}
      </DialogContent>
      
      <Box sx={{ 
        px: 3, 
        pt: 2, 
        borderTop: `1px solid ${theme.palette.divider}`, 
        bgcolor: 'background.default' 
      }}>
        {/* Token usage display with progress bar */}
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
            <Typography variant="caption" color="text.secondary">
              Primary Model: {totalTokens.toLocaleString()} / {contextWindowLimit.toLocaleString()} tokens
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {primaryTokenPercentage.toFixed(1)}%
            </Typography>
          </Box>
          <LinearProgress 
            variant="determinate" 
            value={primaryTokenPercentage} 
            sx={{ 
              height: 6, 
              borderRadius: 3,
              bgcolor: 'rgba(255,255,255,0.05)',
              '& .MuiLinearProgress-bar': {
                bgcolor: primaryTokenPercentage > 90 ? UI.COLORS.error : 
                        primaryTokenPercentage > 70 ? UI.COLORS.warning : 
                        UI.COLORS.success
              }
            }}
          />
          
          {totalTokens > contextWindowLimit && (
            <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
              <ErrorIcon fontSize="small" color="error" sx={{ mr: 0.5, fontSize: 16 }} />
              <Typography variant="caption" color="error.main">
                Exceeds primary model context window.
              </Typography>
            </Box>
          )}
          
          {totalTokens > contextWindowLimit * 0.7 && totalTokens <= contextWindowLimit && (
            <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
              <WarningIcon fontSize="small" color="warning" sx={{ mr: 0.5, fontSize: 16 }} />
              <Typography variant="caption" color="warning.main">
                Approaching primary model context limit. Consider using Ultra Context model.
              </Typography>
            </Box>
          )}
        </Box>
        
        <Box sx={{ mb: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 0.5 }}>
            <Typography variant="caption" color="text.secondary">
              Ultra Context Model: {totalTokens.toLocaleString()} / {ultraContextWindowLimit.toLocaleString()} tokens
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {ultraTokenPercentage.toFixed(1)}%
            </Typography>
          </Box>
          <LinearProgress 
            variant="determinate" 
            value={ultraTokenPercentage} 
            sx={{ 
              height: 6, 
              borderRadius: 3,
              bgcolor: 'rgba(255,255,255,0.05)',
              '& .MuiLinearProgress-bar': {
                bgcolor: ultraTokenPercentage > 90 ? UI.COLORS.error : 
                        ultraTokenPercentage > 70 ? UI.COLORS.warning : 
                        UI.COLORS.success
              }
            }}
          />
        </Box>
      </Box>
      
      <DialogActions sx={{ px: 3, py: 2 }}>
        <Button 
          onClick={onClose} 
          variant="outlined"
          sx={{ borderRadius: 2 }}
        >
          Cancel
        </Button>
        <Button 
          onClick={handleConfirm} 
          variant="contained"
          disabled={selectedDocIds.size === 0}
          sx={{ 
            ml: 2, 
            borderRadius: 2,
            background: UI.GRADIENTS.primary
          }}
        >
          Add {selectedDocIds.size} Document{selectedDocIds.size !== 1 ? 's' : ''}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DocumentSelector;