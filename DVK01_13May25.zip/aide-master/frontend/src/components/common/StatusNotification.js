import React, { useState, useEffect, useRef } from 'react';
import { Box, Typography, Fade, useTheme, alpha, Paper, Collapse, IconButton } from '@mui/material';
import GrainIcon from '@mui/icons-material/Grain';
import PsychologyIcon from '@mui/icons-material/Psychology';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';

const StatusNotification = ({ 
  currentEvent,
  isProcessing,
  processingState = {},
  showReasoning = false
}) => {
  const theme = useTheme();
  const [visible, setVisible] = useState(false);
  const [expandReasoning, setExpandReasoning] = useState(false);
  const timerRef = useRef(null);
  
  useEffect(() => {
    // Only show notifications when there's a current event
    if (currentEvent && isProcessing) {
      // Clear any existing timers
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
      
      // Show the notification
      setVisible(true);
      
      // Set timer to hide the notification after 3 seconds
      timerRef.current = setTimeout(() => {
        setVisible(false);
      }, 3000);
    } else {
      setVisible(false);
    }
    
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [currentEvent, isProcessing]);

  // If nothing to show or not processing, don't render
  if (!visible && !showReasoning) {
    return null;
  }
  
  // Check if we have reasoning steps to display
  const hasReasoning = processingState?.reasoning || 
                      (processingState?.events && 
                       processingState.events.some(event => event.data?.reasoning));
  
  // Find the reasoning data
  const reasoningText = hasReasoning ? 
    processingState?.reasoning || 
    processingState?.events?.find(event => event.data?.reasoning)?.data?.reasoning :
    null;
  
  return (
    <>
      {visible && (
        <Fade in={visible}>
          <Box
            sx={{
              position: 'absolute',
              top: '20%',
              left: '50%',
              transform: 'translateX(-50%)',
              zIndex: 2000,
              backgroundColor: alpha(theme.palette.background.paper, 0.9),
              backdropFilter: 'blur(10px)',
              borderRadius: '24px',
              py: 1.25,
              px: 2.5,
              minWidth: 180,
              maxWidth: 440,
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)',
              border: `1px solid ${alpha(theme.palette.divider, 0.2)}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <Typography
              sx={{
                color: alpha(theme.palette.common.white, 0.95),
                fontSize: '0.95rem',
                fontWeight: 500,
                textAlign: 'center',
                py: 0.5
              }}
            >
              {currentEvent}
            </Typography>
          </Box>
        </Fade>
      )}
      
      {showReasoning && hasReasoning && (
        <Paper
          sx={{
            position: 'absolute',
            bottom: 20,
            right: 20,
            zIndex: 1900,
            maxWidth: '50%',
            width: expandReasoning ? '50%' : 'auto',
            minWidth: 300,
            borderRadius: 2,
            overflow: 'hidden',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2)',
            border: `1px solid ${alpha(theme.palette.primary.main, 0.2)}`,
            background: alpha(theme.palette.background.paper, 0.95),
            backdropFilter: 'blur(10px)'
          }}
        >
          <Box 
            sx={{ 
              display: 'flex', 
              justifyContent: 'space-between', 
              alignItems: 'center',
              p: 1.5,
              backgroundColor: alpha(theme.palette.primary.main, 0.1),
              borderBottom: expandReasoning ? `1px solid ${alpha(theme.palette.primary.main, 0.2)}` : 'none'
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <PsychologyIcon sx={{ color: theme.palette.primary.main, mr: 1 }} />
              <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                Model Reasoning Process
              </Typography>
            </Box>
            <IconButton size="small" onClick={() => setExpandReasoning(!expandReasoning)}>
              {expandReasoning ? <ExpandMoreIcon /> : <ChevronRightIcon />}
            </IconButton>
          </Box>
          
          <Collapse in={expandReasoning}>
            <Box 
              sx={{ 
                p: 2, 
                maxHeight: '400px', 
                overflowY: 'auto',
                whiteSpace: 'pre-wrap',
                fontFamily: 'monospace',
                fontSize: '0.8rem',
                color: alpha('#fff', 0.8)
              }}
            >
              {reasoningText}
            </Box>
          </Collapse>
        </Paper>
      )}
    </>
  );
};

export default StatusNotification;