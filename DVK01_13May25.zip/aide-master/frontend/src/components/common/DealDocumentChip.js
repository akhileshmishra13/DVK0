// src/components/common/DealDocumentChip.js

import React from 'react';
import { Chip, Box, Avatar, useTheme } from '@mui/material';
import DescriptionIcon from '@mui/icons-material/Description';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import BarChartIcon from '@mui/icons-material/BarChart';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';

const DealDocumentChip = ({ document, onDelete }) => {
  const theme = useTheme();
  
  // Determine icon and color based on document type
  const getDocumentIcon = () => {
    const docType = document.metadata?.extracted_metadata?.document_type;
    
    if (docType === 'Teaser Deck') {
      return <DescriptionIcon sx={{ fontSize: 14, color: theme.palette.info.main }} />;
    } else if (docType === 'Deal Qualification Memo' || docType === 'DQM') {
      return <InsertDriveFileIcon sx={{ fontSize: 14, color: theme.palette.primary.main }} />;
    } else if (docType === 'Confidential Investment Memo' || docType === 'CIM') {
      return <InsertDriveFileIcon sx={{ fontSize: 14, color: theme.palette.warning.main }} />;
    } else if (docType === 'Financial Analysis') {
      return <BarChartIcon sx={{ fontSize: 14, color: theme.palette.success.main }} />;
    }
    
    return <PictureAsPdfIcon sx={{ fontSize: 14, color: '#EF4444' }} />;
  };
  
  const getChipColor = () => {
    const docType = document.metadata?.extracted_metadata?.document_type;
    
    if (docType === 'Teaser Deck') {
      return theme.palette.info.main;
    } else if (docType === 'Deal Qualification Memo' || docType === 'DQM') {
      return theme.palette.primary.main;
    } else if (docType === 'Confidential Investment Memo' || docType === 'CIM') {
      return theme.palette.warning.main;
    } else if (docType === 'Financial Analysis') {
      return theme.palette.success.main;
    }
    
    return theme.palette.error.main;
  };
  
  const color = getChipColor();
  
  // Get the document ID consistently - using the most likely field
  const docId = document.id || document.document_id;
  
  const handleDelete = () => {
    if (onDelete && docId) {
      onDelete(docId);
    }
  };
  
  return (
    <Chip
      avatar={
        <Avatar sx={{ bgcolor: `${color}20 !important`, color: `${color} !important` }}>
          {getDocumentIcon()}
        </Avatar>
      }
      label={document.filename}
      onDelete={handleDelete}
      sx={{
        bgcolor: `${color}10`,
        border: `1px solid ${color}20`,
        borderRadius: 6,
        '& .MuiChip-label': {
          px: 1,
          fontSize: '0.75rem'
        },
        '& .MuiChip-deleteIcon': {
          color: `${color}80`,
          '&:hover': {
            color: color
          }
        }
      }}
    />
  );
};

export default DealDocumentChip;