// frontend/src/components/common/CompletionProgress.jsx
import React, { useState, useEffect } from 'react';
import { Box, LinearProgress, Typography, Fade, Paper, Button, alpha, useTheme } from '@mui/material';
import GrainIcon from '@mui/icons-material/Grain';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';
import DoneIcon from '@mui/icons-material/Done';
import CloseIcon from '@mui/icons-material/Close';
import PsychologyIcon from '@mui/icons-material/Psychology';

const CompletionProgress = ({ 
  percentage, 
  currentStep, 
  isComplete, 
  error, 
  expanded = true,
  onManualClose = null,
  isThinking = false,
  thinkingPhase = ''
}) => {
  const theme = useTheme();
  const [showCloseOption, setShowCloseOption] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [elapsedTimeFormatted, setElapsedTimeFormatted] = useState('00:00');
  
  // Show close option after 30 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowCloseOption(true);
    }, 30000);
    
    return () => clearTimeout(timer);
  }, []);
  
  // Track elapsed time
  useEffect(() => {
    if (!isComplete && !error) {
      const timer = setInterval(() => {
        setElapsedTime(prev => {
          const newTime = prev + 1;
          // Format time as MM:SS
          const minutes = Math.floor(newTime / 60);
          const seconds = newTime % 60;
          setElapsedTimeFormatted(`${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
          return newTime;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [isComplete, error]);

  const getStatusIcon = () => {
    if (error) {
      return <ErrorOutlineIcon sx={{ color: theme.palette.error.main, mr: 1, fontSize: 16 }} />;
    }
    
    if (isComplete) {
      return <DoneIcon sx={{ color: theme.palette.success.main, mr: 1, fontSize: 16 }} />;
    }
    
    if (isThinking) {
      return <PsychologyIcon sx={{ color: theme.palette.primary.main, mr: 1, fontSize: 16 }} />;
    }
    
    return <GrainIcon sx={{ color: theme.palette.primary.main, mr: 1, fontSize: 16 }} />;
  };
  
  const getStatusColor = () => {
    if (error) return theme.palette.error.main;
    if (isComplete) return theme.palette.success.main;
    return theme.palette.primary.main;
  };
  
  // Get dynamic description based on elapsed time
  const getLongRunningMessage = () => {
    if (elapsedTime > 300) { // Over 5 minutes
      return "Processing large documents with deep analysis - this can take 10+ minutes for thorough results.";
    } else if (elapsedTime > 120) { // Over 2 minutes
      return "Large document analysis in progress. Using thinking models for thorough analysis.";
    } else if (elapsedTime > 60) { // Over 1 minute
      return "Processing continues. Large documents require more time for quality analysis.";
    }
    return null;
  };
  
  const longRunningMessage = getLongRunningMessage();
  
  return (
    <Fade in={true}>
      <Paper
        elevation={0}
        sx={{ 
          borderRadius: 2,
          overflow: 'hidden',
          backgroundColor: alpha(getStatusColor(), 0.08),
          border: '1px solid',
          borderColor: alpha(getStatusColor(), 0.15),
          mb: 3
        }}
      >
        <Box sx={{ 
          px: 3, 
          py: 1.5,
          position: 'relative'
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              {getStatusIcon()}
              <Typography variant="body2" sx={{ fontWeight: 500, color: getStatusColor() }}>
                {error 
                  ? "Error processing request" 
                  : isComplete 
                    ? "Processing complete" 
                    : isThinking && thinkingPhase
                      ? `${thinkingPhase.charAt(0).toUpperCase() + thinkingPhase.slice(1)} phase`
                      : currentStep || "Processing..."}
              </Typography>
              
              {/* Show elapsed time for long-running processes */}
              {!isComplete && !error && elapsedTime > 15 && (
                <Typography variant="caption" sx={{ ml: 2, fontFamily: 'monospace', color: 'text.secondary' }}>
                  {elapsedTimeFormatted} elapsed
                </Typography>
              )}
            </Box>
            <Typography variant="body2" sx={{ fontWeight: 500 }}>
              {Math.round(percentage)}%
            </Typography>
          </Box>
          
          <LinearProgress 
            variant={isComplete ? "determinate" : isThinking ? "indeterminate" : "determinate"}
            value={percentage}
            sx={{ 
              height: 6, 
              borderRadius: 3,
              backgroundColor: alpha(getStatusColor(), 0.1),
              '& .MuiLinearProgress-bar': {
                backgroundColor: getStatusColor(),
                borderRadius: 3
              }
            }} 
          />
          
          {/* Show long-running message for extended processing */}
          {longRunningMessage && !isComplete && !error && (
            <Typography 
              variant="caption" 
              sx={{ 
                display: 'block', 
                mt: 1,
                color: 'text.secondary',
                fontStyle: 'italic'
              }}
            >
              {longRunningMessage}
            </Typography>
          )}
          
          {/* Add manual close option that shows after delay */}
          {showCloseOption && onManualClose && !isComplete && (
            <Button
              size="small"
              startIcon={<CloseIcon />}
              onClick={onManualClose}
              sx={{ 
                mt: 1,
                fontSize: '0.7rem',
                textTransform: 'none',
                position: 'absolute',
                bottom: 8,
                right: 8
              }}
            >
              Close Progress
            </Button>
          )}
        </Box>
      </Paper>
    </Fade>
  );
};

export default CompletionProgress;