// frontend/src/components/prompts/PromptLibrary.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { 
  Box, 
  Typography, 
  Paper, 
  Fade, 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  CardActions,
  Button,
  Chip,
  IconButton,
  Tooltip,
  TextField,
  InputAdornment,
  CircularProgress,
  Tabs,
  Tab,
  Divider,
  alpha,
  useTheme,
  Avatar,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Skeleton,
  Collapse,
  Badge
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import BookmarkBorderIcon from '@mui/icons-material/BookmarkBorder';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import FilterAltIcon from '@mui/icons-material/FilterAlt';
import LineStyleIcon from '@mui/icons-material/LineStyle';
import HomeIcon from '@mui/icons-material/Home';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import DescriptionIcon from '@mui/icons-material/Description';
import BusinessIcon from '@mui/icons-material/Business';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import CheckIcon from '@mui/icons-material/Check';
import TuneIcon from '@mui/icons-material/Tune';
import DashboardIcon from '@mui/icons-material/Dashboard';
import AccountTreeIcon from '@mui/icons-material/AccountTree';
import TimelineIcon from '@mui/icons-material/Timeline';
import GroupWorkIcon from '@mui/icons-material/GroupWork';
import { promptApi } from '../../services/apiService';

const PromptLibraryPage = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  
  // States
  const [categories, setCategories] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [savedTemplates, setSavedTemplates] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeTab, setActiveTab] = useState(0);
  const [copiedId, setCopiedId] = useState(null);
  
  // Load prompt categories
  useEffect(() => {
    fetchPromptCategories();
    
    // Load saved templates from localStorage
    const saved = localStorage.getItem('savedPromptTemplates');
    if (saved) {
      try {
        setSavedTemplates(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse saved templates", e);
      }
    }
  }, []);
  
  const fetchPromptCategories = async () => {
    try {
      setLoading(true);
      const response = await promptApi.getCategories();
      if (response.data && response.data.status === 'success') {
        setCategories(response.data.data);
        setError(null);
      } else {
        setError('Failed to load prompt categories');
      }
    } catch (err) {
      setError(err.message || 'Error fetching prompt categories');
    } finally {
      setLoading(false);
    }
  };
  
  // Handle template selection and navigation to assistant
  const handleSelectTemplate = (template) => {
    navigate('/assistant', { state: { template } });
  };
  
  // Toggle saving a template
  const toggleSaveTemplate = (templateId) => {
    let newSavedTemplates;
    if (savedTemplates.includes(templateId)) {
      newSavedTemplates = savedTemplates.filter(id => id !== templateId);
    } else {
      newSavedTemplates = [...savedTemplates, templateId];
    }
    setSavedTemplates(newSavedTemplates);
    localStorage.setItem('savedPromptTemplates', JSON.stringify(newSavedTemplates));
  };
  
  // Filter templates based on search and category
  const getFilteredTemplates = () => {
    const allTemplates = [];
    
    // If viewing favorites tab
    if (activeTab === 1) {
      Object.entries(categories).forEach(([categoryKey, subcategories]) => {
        Object.entries(subcategories).forEach(([subcategoryKey, templates]) => {
          templates.forEach(template => {
            if (savedTemplates.includes(template.template_id)) {
              if (searchQuery === '' || 
                  template.display_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  template.description.toLowerCase().includes(searchQuery.toLowerCase())) {
                allTemplates.push({
                  ...template,
                  category: categoryKey,
                  subcategory: subcategoryKey
                });
              }
            }
          });
        });
      });
      return allTemplates;
    }
    
    // Regular category filtering
    Object.entries(categories).forEach(([categoryKey, subcategories]) => {
      if (selectedCategory === 'all' || categoryKey === selectedCategory) {
        Object.entries(subcategories).forEach(([subcategoryKey, templates]) => {
          templates.forEach(template => {
            if (searchQuery === '' || 
                template.display_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                (template.required_variables && template.required_variables.some(v => 
                  v.toLowerCase().includes(searchQuery.toLowerCase())
                ))) {
              allTemplates.push({
                ...template,
                category: categoryKey,
                subcategory: subcategoryKey
              });
            }
          });
        });
      }
    });
    
    return allTemplates;
  };
  
  // Get category-specific gradient colors
  const getCategoryGradient = (category) => {
    const gradients = {
      'deal_evaluation': 'linear-gradient(135deg, #3A72F8 0%, #2DD4BF 100%)',
      'document_analysis': 'linear-gradient(135deg, #8B5CF6 0%, #EC4899 100%)',
      'system': 'linear-gradient(135deg, #6366F1 0%, #0EA5E9 100%)',
      'all': 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)'
    };
    
    return gradients[category] || 'linear-gradient(135deg, #4F46E5 0%, #7C3AED 100%)';
  };
  
  // Get category icon
  const getCategoryIcon = (category) => {
    switch (category) {
      case 'deal_evaluation':
        return <BusinessIcon />;
      case 'document_analysis':
        return <DescriptionIcon />;
      case 'financial_analysis':
        return <TimelineIcon />;
      case 'strategic_assessment':
        return <AccountTreeIcon />;
      case 'system':
        return <LineStyleIcon />;
      case 'all':
        return <DashboardIcon />;
      default:
        return <LocalOfferIcon />;
    }
  };
  
  // Group templates by subcategory
  const groupBySubcategory = (templates) => {
    return templates.reduce((groups, template) => {
      const key = template.subcategory;
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(template);
      return groups;
    }, {});
  };
  
  const handleCopyTemplateId = (id) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };
  
  const filteredTemplates = getFilteredTemplates();
  const groupedTemplates = groupBySubcategory(filteredTemplates);
  
  // Template Card component
  const TemplateCard = ({ template }) => (
    <Card 
      sx={{ 
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        bgcolor: alpha(theme.palette.background.paper, 0.3),
        backdropFilter: 'blur(10px)',
        borderRadius: 2,
        transition: 'all 0.3s ease',
        boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
        border: `1px solid ${alpha('#ffffff', 0.05)}`,
        position: 'relative',
        overflow: 'hidden',
        '&::before': {
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: '3px',
          background: getCategoryGradient(template.category),
          opacity: 0.7,
        },
        '&:hover': {
          transform: 'translateY(-5px)',
          boxShadow: '0 12px 25px rgba(0,0,0,0.15)',
          '&::before': {
            opacity: 1,
          }
        }
      }}
    >
      <Box 
        sx={{ 
          position: 'absolute', 
          top: 12, 
          right: 12, 
          zIndex: 2 
        }}
      >
        <Tooltip title={savedTemplates.includes(template.template_id) ? "Remove from saved" : "Save template"}>
          <IconButton 
            size="small" 
            onClick={(e) => {
              e.stopPropagation();
              toggleSaveTemplate(template.template_id);
            }}
            sx={{ 
              bgcolor: alpha(theme.palette.background.paper, 0.7),
              backdropFilter: 'blur(5px)',
              '&:hover': {
                bgcolor: alpha(theme.palette.background.paper, 0.9),
              }
            }}
          >
            {savedTemplates.includes(template.template_id) ? (
              <BookmarkIcon fontSize="small" color="primary" />
            ) : (
              <BookmarkBorderIcon fontSize="small" />
            )}
          </IconButton>
        </Tooltip>
      </Box>
      
      <CardContent sx={{ flexGrow: 1, pt: 2, pb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 1.5 }}>
          <Avatar
            sx={{
              bgcolor: `${alpha(theme.palette.primary.main, 0.1)}`,
              color: theme.palette.primary.main,
              width: 32,
              height: 32,
              mr: 1.5,
              '& .MuiSvgIcon-root': {
                fontSize: 16
              }
            }}
          >
            {getCategoryIcon(template.category)}
          </Avatar>
          <Box sx={{ mt: -0.5, pr: 3 }}>
            <Typography 
              variant="subtitle1" 
              sx={{ 
                fontWeight: 600, 
                mb: 0.5,
                fontSize: '0.95rem',
                lineHeight: 1.3
              }}
            >
              {template.display_name}
            </Typography>
            
            <Chip
              size="small"
              label={template.category.replace(/_/g, ' ')}
              sx={{ 
                textTransform: 'capitalize',
                height: 18,
                bgcolor: `${alpha(theme.palette.primary.main, 0.1)}`,
                color: theme.palette.primary.main,
                fontWeight: 500,
                fontSize: '0.6rem',
                '& .MuiChip-label': { px: 1 }
              }}
            />
          </Box>
        </Box>
        
        <Typography 
          variant="body2" 
          color="text.secondary" 
          sx={{ 
            mb: 2,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            height: '3em',
            fontSize: '0.85rem'
          }}
        >
          {template.description}
        </Typography>
        
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.8, mt: 1, mb: 0.5 }}>
          {template.required_variables?.slice(0, 4).map((variable) => (
            <Chip 
              key={variable} 
              label={variable.replace(/_/g, ' ')}
              size="small" 
              sx={{ 
                height: 18,
                fontSize: '0.6rem',
                bgcolor: alpha(theme.palette.background.paper, 0.3),
                border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                '& .MuiChip-label': { px: 0.8 }
              }}
            />
          ))}
          {template.required_variables?.length > 4 && (
            <Chip 
              label={`+${template.required_variables.length - 4} more`}
              size="small" 
              sx={{ 
                height: 18,
                fontSize: '0.6rem',
                bgcolor: alpha(theme.palette.background.paper, 0.15),
                '& .MuiChip-label': { px: 0.8 }
              }}
            />
          )}
        </Box>
      </CardContent>
      
      <Divider sx={{ opacity: 0.1 }} />
      
      <CardActions sx={{ p: 0, display: 'flex' }}>
        <Button 
          size="small" 
          onClick={() => handleSelectTemplate(template)}
          sx={{ 
            py: 1.25,
            px: 2,
            textTransform: 'none',
            fontWeight: 500,
            transition: 'all 0.2s ease',
            flexGrow: 1,
            borderRadius: 0,
            justifyContent: 'flex-start',
            '&:hover': {
              bgcolor: alpha(theme.palette.primary.main, 0.1),
            }
          }}
          startIcon={<PlayArrowIcon />}
        >
          Use Template
        </Button>
        
        <Tooltip title={copiedId === template.template_id ? "Copied!" : "Copy template ID"}>
          <IconButton 
            size="small" 
            onClick={(e) => {
              e.stopPropagation();
              handleCopyTemplateId(template.template_id);
            }}
            sx={{ 
              borderLeft: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
              borderRadius: 0,
              py: 1.25,
              px: 2,
              color: copiedId === template.template_id ? theme.palette.success.main : 'inherit'
            }}
          >
            {copiedId === template.template_id ? <CheckIcon fontSize="small" /> : <ContentCopyIcon fontSize="small" />}
          </IconButton>
        </Tooltip>
      </CardActions>
    </Card>
  );
  
  return (
    <Box>
      {/* Header Section */}
      <Fade in={true} timeout={800}>
        <Box sx={{ 
          mb: 4, 
          borderRadius: '0 0 24px 24px',
          position: 'relative',
          overflow: 'hidden'
        }}>
          <Box sx={{ 
            p: 4, 
            background: `linear-gradient(135deg, ${alpha('#3A72F8', 0.15)} 0%, ${alpha('#2DD4BF', 0.15)} 100%)`,
            borderRadius: '0 0 24px 24px',
            border: `1px solid ${alpha('#ffffff', 0.1)}`,
            backdropFilter: 'blur(5px)'
          }}>
            <Container maxWidth="xl" sx={{ px: { xs: 0, sm: 2 } }}>
              <Box sx={{ display: 'flex', flexDirection: { xs: 'column', md: 'row' }, justifyContent: 'space-between', alignItems: { xs: 'flex-start', md: 'center' }, gap: 2 }}>
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <LineStyleIcon sx={{ mr: 1.5, color: theme.palette.primary.main, fontSize: 32 }} />
                    <Typography variant="h4" fontWeight={600}>
                      Prompt Gallery
                    </Typography>
                  </Box>
                </Box>
                
                <Box sx={{ flex: 1, maxWidth: { xs: '100%', md: 400 }, mt: { xs: 2, md: 0 } }}>
                  <TextField
                    placeholder="Search templates by name, description, or variables..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    variant="outlined"
                    fullWidth
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon sx={{ color: alpha(theme.palette.text.primary, 0.4) }} />
                        </InputAdornment>
                      ),
                      sx: { 
                        borderRadius: 2,
                        bgcolor: alpha(theme.palette.background.paper, 0.1),
                        backdropFilter: 'blur(10px)',
                        pr: 1
                      }
                    }}
                    sx={{ 
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderColor: alpha('#ffffff', 0.2),
                        },
                        '&:hover fieldset': {
                          borderColor: alpha('#ffffff', 0.3),
                        },
                        '&.Mui-focused fieldset': {
                          borderColor: theme.palette.primary.main,
                        },
                      },
                    }}
                  />
                </Box>
              </Box>
            </Container>
          </Box>
        </Box>
      </Fade>
      
      <Container maxWidth="xl" sx={{ px: { xs: 2, sm: 4 } }}>
        {/* Navigation Tabs */}
        <Box sx={{ 
          mb: 4, 
          display: 'flex', 
          alignItems: 'center',
          flexWrap: 'wrap',
          columnGap: 4,
          rowGap: 2
        }}>
          <Tabs 
            value={activeTab} 
            onChange={(e, newValue) => {
              setActiveTab(newValue);
              // Reset category selection when switching to saved templates
              if (newValue === 1) setSelectedCategory('all');
            }}
            sx={{ 
              minHeight: 'auto',
              '& .MuiTabs-indicator': {
                backgroundColor: theme.palette.primary.main,
                height: 3,
                borderRadius: '3px 3px 0 0'
              },
              '& .MuiTab-root': {
                minHeight: 48
              }
            }}
          >
            <Tab 
              label="Browse Templates" 
              icon={<HomeIcon sx={{ mb: 0.5 }} />} 
              iconPosition="start"
              sx={{ 
                textTransform: 'none', 
                fontWeight: 500,
                fontSize: '0.9rem',
                px: 2
              }} 
            />
            <Tab 
              label={`Saved Templates`} 
              icon={<BookmarkIcon sx={{ mb: 0.5 }} />} 
              iconPosition="start" 
              sx={{ 
                textTransform: 'none', 
                fontWeight: 500,
                fontSize: '0.9rem',
                px: 2
              }} 
            />
          </Tabs>
          
          {activeTab === 0 && (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              <Chip
                label="All Categories"
                icon={getCategoryIcon('all')}
                onClick={() => setSelectedCategory('all')}
                color={selectedCategory === 'all' ? "primary" : "default"}
                variant={selectedCategory === 'all' ? "filled" : "outlined"}
                sx={{ 
                  borderRadius: 2,
                  height: 32,
                  '& .MuiChip-icon': {
                    color: selectedCategory === 'all' ? 'inherit' : theme.palette.text.secondary
                  }
                }}
              />
              
              {Object.keys(categories).map((category) => (
                <Chip
                  key={category}
                  label={category.replace(/_/g, ' ')}
                  icon={getCategoryIcon(category)}
                  onClick={() => setSelectedCategory(category)}
                  color={selectedCategory === category ? "primary" : "default"}
                  variant={selectedCategory === category ? "filled" : "outlined"}
                  sx={{ 
                    textTransform: 'capitalize',
                    borderRadius: 2,
                    height: 32,
                    '& .MuiChip-icon': {
                      color: selectedCategory === category ? 'inherit' : theme.palette.text.secondary
                    }
                  }}
                />
              ))}
            </Box>
          )}
          
          {activeTab === 1 && (
            <Badge 
              badgeContent={savedTemplates.length} 
              color="primary"
              sx={{ '& .MuiBadge-badge': { top: 0, right: -8 } }}
            >
              <Typography variant="body2" sx={{ fontWeight: 500, mr: 1 }}>
                Saved Templates
              </Typography>
            </Badge>
          )}
        </Box>
        
        {loading ? (
          <Grid container spacing={3}>
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <Grid item xs={12} sm={6} md={4} lg={3} key={item}>
                <Card sx={{ borderRadius: 2, height: '100%', background: alpha(theme.palette.background.paper, 0.3) }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                      <Skeleton variant="circular" width={32} height={32} sx={{ mr: 1.5 }} />
                      <Box>
                        <Skeleton variant="text" width={120} height={24} />
                        <Skeleton variant="text" width={80} height={20} />
                      </Box>
                    </Box>
                    <Skeleton variant="text" width="100%" height={20} />
                    <Skeleton variant="text" width="90%" height={20} />
                    <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
                      <Skeleton variant="rectangular" width={60} height={20} sx={{ borderRadius: 1 }} />
                      <Skeleton variant="rectangular" width={70} height={20} sx={{ borderRadius: 1 }} />
                    </Box>
                  </CardContent>
                  <Divider />
                  <CardActions>
                    <Skeleton variant="text" width="60%" height={36} />
                    <Skeleton variant="circular" width={36} height={36} sx={{ ml: 'auto' }} />
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : error ? (
          <Paper sx={{ p: 3, borderRadius: 3, bgcolor: alpha(theme.palette.background.paper, 0.3) }}>
            <Typography color="error">{error}</Typography>
          </Paper>
        ) : filteredTemplates.length === 0 ? (
          <Paper sx={{ 
            p: 5, 
            borderRadius: 3, 
            background: alpha(theme.palette.background.paper, 0.3),
            backdropFilter: 'blur(10px)',
            border: `1px dashed ${alpha(theme.palette.divider, 0.3)}`,
            textAlign: 'center' 
          }}>
            <Box sx={{ 
              width: 80,
              height: 80,
              borderRadius: '50%',
              background: `linear-gradient(135deg, ${alpha(theme.palette.background.paper, 0.3)} 0%, ${alpha(theme.palette.background.paper, 0.1)} 100%)`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              mx: 'auto',
              mb: 3,
              border: `1px solid ${alpha(theme.palette.divider, 0.2)}`
            }}>
              {activeTab === 1 ? (
                <BookmarkIcon sx={{ fontSize: 36, color: alpha(theme.palette.text.secondary, 0.7) }} />
              ) : (
                <LineStyleIcon sx={{ fontSize: 36, color: alpha(theme.palette.text.secondary, 0.7) }} />
              )}
            </Box>
            <Typography variant="h6" sx={{ mb: 1 }}>
              {activeTab === 1 ? 'No saved templates' : 'No templates found'}
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 450, mx: 'auto' }}>
              {searchQuery 
                ? "No templates match your search criteria. Try adjusting your search terms."
                : activeTab === 1 
                  ? "You haven't saved any templates yet. Browse the prompt template gallery and bookmark templates you want to save."
                  : "No templates available in this category. Please try another category."
              }
            </Typography>
          </Paper>
        ) : (
          <Box>
            {Object.entries(groupedTemplates).map(([subcategory, templates], index) => (
              <Fade key={subcategory} in={true} timeout={300 + (index * 100)}>
                <Box sx={{ mb: 5 }}>
                  <Box sx={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    mb: 2,
                    pb: 1,
                    borderBottom: `1px solid ${alpha(theme.palette.divider, 0.1)}`
                  }}>
                    <Box 
                      sx={{ 
                        width: 4, 
                        height: 20, 
                        background: getCategoryGradient(templates[0].category),
                        borderRadius: 4,
                        mr: 2 
                      }} 
                    />
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        textTransform: 'capitalize',
                        fontWeight: 600,
                        fontSize: '1.1rem'
                      }}
                    >
                      {subcategory.replace(/_/g, ' ')}
                    </Typography>
                    <Chip 
                      label={`${templates.length} template${templates.length !== 1 ? 's' : ''}`}
                      size="small"
                      sx={{ 
                        ml: 2,
                        bgcolor: alpha(theme.palette.background.paper, 0.2),
                        border: `1px solid ${alpha(theme.palette.divider, 0.1)}`,
                        fontSize: '0.7rem',
                        height: 20
                      }}
                    />
                  </Box>
                  
                  <Grid container spacing={3}>
                    {templates.map((template) => (
                      <Grid item xs={12} sm={6} md={4} lg={3} key={template.template_id}>
                        <Fade in={true} timeout={500}>
                          <Box>
                            <TemplateCard template={template} />
                          </Box>
                        </Fade>
                      </Grid>
                    ))}
                  </Grid>
                </Box>
              </Fade>
            ))}
          </Box>
        )}
      </Container>
    </Box>
  );
};

export default PromptLibraryPage;